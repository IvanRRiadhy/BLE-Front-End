import{bl as e,hP as a,hQ as s}from"./index-Dzx-6msi.js";const o=e("MuiBox",["root"]),r=a({defaultClassName:o.root,generateClassName:s.generate});export{r as B};
