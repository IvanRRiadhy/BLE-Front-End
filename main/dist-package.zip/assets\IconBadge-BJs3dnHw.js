import{c as e}from"./index-BUpSbRfy.js";const o=[["path",{d:"M17 17v-13l-5 3l-5 -3v13l5 3z",key:"svg-0"}]],a=e("outline","badge","Badge",o);export{a as I};
