import{H as t,j as e}from"./index-D3jHKZPM.js";const r=t(e.jsx("path",{d:"M15.41 7.41 14 6l-6 6 6 6 1.41-1.41L10.83 12z"}),"ChevronLeft");export{r as C};
