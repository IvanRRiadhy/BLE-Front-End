import{R as Wo,j as F,s as qo,r as tt,jL as Jl,jM as Zl,T as ra,B as tn,bT as Xl,bU as Bo,S as zo,ca as Ho,c4 as Ko,bf as Ql,w as ec,Z as tc,z as rc,jO as nc,jP as ac,jQ as oc,jR as ic,cH as sc,jN as na,ay as lc,jS as cc}from"./index-BUpSbRfy.js";import{C as uc}from"./Checkbox-kFOJ_-kI.js";import{A as fc,m as dc}from"./index-X9Ruv4gv.js";import{I as hc}from"./IconEyeOff-doAotHJP.js";import{I as vc}from"./IconEye-XOwMrEFb.js";import{F as pc}from"./FormGroup-B3V7IQMU.js";import{F as gc}from"./FormControlLabel-CLND3SaG.js";const Jo=qo("span")(({theme:Y})=>({borderRadius:3,width:19,height:19,marginLeft:"4px",boxShadow:Y.palette.mode==="dark"?`0 0 0 1px ${Y.palette.grey[200]}`:`inset 0 0 0 1px ${Y.palette.grey[300]}`,backgroundColor:"transparent",".Mui-focusVisible &":{outline:Y.palette.mode==="dark"?`0px auto ${Y.palette.grey[200]}`:`0px auto  ${Y.palette.grey[300]}`,outlineOffset:2},"input:hover ~ &":{backgroundColor:(Y.palette.mode==="dark",Y.palette.primary)},"input:disabled ~ &":{boxShadow:"none",background:Y.palette.grey[100]}})),mc=qo(Jo)({boxShadow:"none",width:19,height:19,"&:before":{display:"block",width:19,height:19,backgroundImage:`url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M12 5c-.28 0-.53.11-.71.29L7 9.59l-2.29-2.3a1.003 1.003 0 00-1.42 1.42l3 3c.18.18.43.29.71.29s.53-.11.71-.29l5-5A1.003 1.003 0 0012 5z' fill='%23fff'/%3E%3C/svg%3E")`,content:'""'}}),Zo=Wo.forwardRef((Y,St)=>F.jsx(uc,{disableRipple:!0,color:Y.color||"default",checkedIcon:F.jsx(mc,{sx:{backgroundColor:Y.color?`${Y.color}.main`:"primary.main"}}),icon:F.jsx(Jo,{}),inputProps:{"aria-label":"Checkbox demo"},ref:St,...Y}));Zo.displayName="CustomCheckbox";var Yo={},Go;function bc(){if(Go)return Yo;Go=1;const Y=!1;var St=Array.isArray,rn=Array.prototype.indexOf,Te=Array.prototype.includes,Ar=Array.from,Pt=Object.keys,Ot=Object.defineProperty,pt=Object.getOwnPropertyDescriptor,nn=Object.getOwnPropertyDescriptors,Tr=Object.prototype,Et=Array.prototype,Ir=Object.getPrototypeOf,nr=Object.isExtensible;const rt=()=>{};function ar(e){for(var t=0;t<e.length;t++)e[t]()}function $r(){var e,t,r=new Promise((n,a)=>{e=n,t=a});return{promise:r,resolve:e,reject:t}}const se=2,gt=4,Lt=8,Wt=1<<24,we=16,Le=32,qe=64,Je=128,be=512,le=1024,ce=2048,Ve=4096,V=8192,K=16384,ye=32768,ve=1<<25,J=65536,Mt=1<<17,Be=1<<18,nt=1<<19,Rr=1<<20,Ze=65536,Nt=1<<21,Ct=1<<22,at=1<<23,qt=Symbol("$state"),Xo=Symbol("legacy props"),Qo=Symbol(""),oa=Symbol("attributes"),an=Symbol("class"),on=Symbol("style"),sn=Symbol("text"),or=Symbol("form reset"),Pr=new class extends Error{name="StaleReactionError";message="The reaction that called `getAbortSignal()` was re-run or destroyed"},ir=!!globalThis.document?.contentType&&globalThis.document.contentType.includes("xml"),sr=3,lr=8;function ia(e){return e===this.v}function sa(e,t){return e!=e?t==t:e!==t||e!==null&&typeof e=="object"||typeof e=="function"}function ei(e){return!sa(e,this.v)}function ti(e){throw new Error("https://svelte.dev/e/lifecycle_outside_component")}function ri(){throw new Error("https://svelte.dev/e/async_derived_orphan")}function ni(e){throw new Error("https://svelte.dev/e/effect_in_teardown")}function ai(){throw new Error("https://svelte.dev/e/effect_in_unowned_derived")}function oi(e){throw new Error("https://svelte.dev/e/effect_orphan")}function ii(){throw new Error("https://svelte.dev/e/effect_update_depth_exceeded")}function si(){throw new Error("https://svelte.dev/e/hydration_failed")}function li(){throw new Error("https://svelte.dev/e/state_descriptors_fixed")}function ci(){throw new Error("https://svelte.dev/e/state_prototype_fixed")}function ui(){throw new Error("https://svelte.dev/e/state_unsafe_mutation")}function fi(){throw new Error("https://svelte.dev/e/svelte_boundary_reset_onerror")}let di=!1;const hi=1,vi=2,ln="[",la="[!",ca="[?",ua="]",Dt={},ue=Symbol("uninitialized"),fa="http://www.w3.org/1999/xhtml",pi="http://www.w3.org/2000/svg",gi="http://www.w3.org/1998/Math/MathML",mi="@attach";let Ie=null;function Jt(e){Ie=e}function mt(e,t=!1,r){Ie={p:Ie,i:!1,c:null,e:null,s:e,x:null,r:I,l:null}}function bt(e){var t=Ie,r=t.e;if(r!==null){t.e=null;for(var n of r)Ga(n)}return e!==void 0&&(t.x=e),t.i=!0,Ie=t.p,e??{}}function da(){return!0}let jt=[];function ha(){var e=jt;jt=[],ar(e)}function yt(e){if(jt.length===0&&!fr){var t=jt;queueMicrotask(()=>{t===jt&&ha()})}jt.push(e)}function bi(){for(;jt.length>0;)ha()}function yi(){console.warn("https://svelte.dev/e/derived_inert")}function cr(e){console.warn("https://svelte.dev/e/hydration_mismatch")}function wi(){console.warn("https://svelte.dev/e/select_multiple_invalid_value")}function _i(){console.warn("https://svelte.dev/e/svelte_boundary_reset_noop")}let R=!1;function ot(e){R=e}let M;function Ee(e){if(e===null)throw cr(),Dt;return M=e}function Ut(){return Ee(st(M))}function Z(e){if(R){if(st(M)!==null)throw cr(),Dt;M=e}}function cn(e=1){if(R){for(var t=e,r=M;t--;)r=st(r);M=r}}function un(e=!0){for(var t=0,r=M;;){if(r.nodeType===lr){var n=r.data;if(n===ua){if(t===0)return r;t-=1}else(n===ln||n===la||n[0]==="["&&!isNaN(Number(n.slice(1))))&&(t+=1)}var a=st(r);e&&r.remove(),r=a}}function va(e){if(!e||e.nodeType!==lr)throw cr(),Dt;return e.data}function wt(e){if(typeof e!="object"||e===null||qt in e)return e;const t=Ir(e);if(t!==Tr&&t!==Et)return e;var r=new Map,n=St(e),a=O(0),i=zt,s=l=>{if(zt===i)return l();var u=D,c=zt;ze(null),Va(i);var d=l();return ze(u),Va(c),d};return n&&r.set("length",O(e.length)),new Proxy(e,{defineProperty(l,u,c){(!("value"in c)||c.configurable===!1||c.enumerable===!1||c.writable===!1)&&li();var d=r.get(u);return d===void 0?s(()=>{var v=O(c.value);return r.set(u,v),v}):w(d,c.value,!0),!0},deleteProperty(l,u){var c=r.get(u);if(c===void 0){if(u in l){const d=s(()=>O(ue));r.set(u,d),hr(a)}}else w(c,ue),hr(a);return!0},get(l,u,c){if(u===qt)return e;var d=r.get(u),v=u in l;if(d===void 0&&(!v||pt(l,u)?.writable)&&(d=s(()=>{var m=wt(v?l[u]:ue),g=O(m);return g}),r.set(u,d)),d!==void 0){var h=o(d);return h===ue?void 0:h}return Reflect.get(l,u,c)},getOwnPropertyDescriptor(l,u){var c=Reflect.getOwnPropertyDescriptor(l,u);if(c&&"value"in c){var d=r.get(u);d&&(c.value=o(d))}else if(c===void 0){var v=r.get(u),h=v?.v;if(v!==void 0&&h!==ue)return{enumerable:!0,configurable:!0,value:h,writable:!0}}return c},has(l,u){if(u===qt)return!0;var c=r.get(u),d=c!==void 0&&c.v!==ue||Reflect.has(l,u);if(c!==void 0||I!==null&&(!d||pt(l,u)?.writable)){c===void 0&&(c=s(()=>{var h=d?wt(l[u]):ue,m=O(h);return m}),r.set(u,c));var v=o(c);if(v===ue)return!1}return d},set(l,u,c,d){var v=r.get(u),h=u in l;if(n&&u==="length")for(var m=c;m<v.v;m+=1){var g=r.get(m+"");g!==void 0?w(g,ue):m in l&&(g=s(()=>O(ue)),r.set(m+"",g))}if(v===void 0)(!h||pt(l,u)?.writable)&&(v=s(()=>O(void 0)),w(v,wt(c)),r.set(u,v));else{h=v.v!==ue;var x=s(()=>wt(c));w(v,x)}var T=Reflect.getOwnPropertyDescriptor(l,u);if(T?.set&&T.set.call(d,c),!h){if(n&&typeof u=="string"){var L=r.get("length"),me=Number(u);Number.isInteger(me)&&me>=L.v&&w(L,me+1)}hr(a)}return!0},ownKeys(l){o(a);var u=Reflect.ownKeys(l).filter(v=>{var h=r.get(v);return h===void 0||h.v!==ue});for(var[c,d]of r)d.v!==ue&&!(c in l)&&u.push(c);return u},setPrototypeOf(){ci()}})}function pa(e){try{if(e!==null&&typeof e=="object"&&qt in e)return e[qt]}catch{}return e}function xi(e,t){return Object.is(pa(e),pa(t))}var Ft,fn,ga,ma,ba;function dn(){if(Ft===void 0){Ft=window,fn=document,ga=/Firefox/.test(navigator.userAgent);var e=Element.prototype,t=Node.prototype,r=Text.prototype;ma=pt(t,"firstChild").get,ba=pt(t,"nextSibling").get,nr(e)&&(e[an]=void 0,e[oa]=null,e[on]=void 0,e.__e=void 0),nr(r)&&(r[sn]=void 0)}}function it(e=""){return document.createTextNode(e)}function Me(e){return ma.call(e)}function st(e){return ba.call(e)}function ne(e,t){if(!R)return Me(e);var r=Me(M);if(r===null)r=M.appendChild(it());else if(t&&r.nodeType!==sr){var n=it();return r?.before(n),Ee(n),n}return t&&Or(r),Ee(r),r}function Zt(e,t=!1){if(!R){var r=Me(e);return r instanceof Comment&&r.data===""?st(r):r}if(t){if(M?.nodeType!==sr){var n=it();return M?.before(n),Ee(n),n}Or(M)}return M}function ee(e,t=1,r=!1){let n=R?M:e;for(var a;t--;)a=n,n=st(n);if(!R)return n;if(r){if(n?.nodeType!==sr){var i=it();return n===null?a?.after(i):n.before(i),Ee(i),i}Or(n)}return Ee(n),n}function ki(e){e.textContent=""}function hn(e,t,r){return document.createElementNS(t??fa,e,void 0)}function Or(e){if(e.nodeValue.length<65536)return;let t=e.nextSibling;for(;t!==null&&t.nodeType===sr;)t.remove(),e.nodeValue+=t.nodeValue,t=e.nextSibling}function ya(e){var t=I;if(t===null)return D.f|=at,e;if((t.f&ye)===0&&(t.f&gt)===0)throw e;At(e,t)}function At(e,t){for(;t!==null;){if((t.f&Je)!==0){if((t.f&ye)===0)throw e;try{t.b.error(e);return}catch(r){e=r}}t=t.parent}throw e}const Si=-7169;function oe(e,t){e.f=e.f&Si|t}function vn(e){(e.f&be)!==0||e.deps===null?oe(e,le):oe(e,Ve)}function wa(e){if(e!==null)for(const t of e)(t.f&se)===0||(t.f&Ze)===0||(t.f^=Ze,wa(t.deps))}function _a(e,t,r){(e.f&ce)!==0?t.add(e):(e.f&Ve)!==0&&r.add(e),wa(e.deps),oe(e,le)}function xa(e,t,r){if(e==null)return t(void 0),rt;const n=gr(()=>e.subscribe(t,r));return n.unsubscribe?()=>n.unsubscribe():n}const Xt=[];function Ei(e,t=rt){let r=null;const n=new Set;function a(l){if(sa(e,l)&&(e=l,r)){const u=!Xt.length;for(const c of n)c[1](),Xt.push(c,e);if(u){for(let c=0;c<Xt.length;c+=2)Xt[c][0](Xt[c+1]);Xt.length=0}}}function i(l){a(l(e))}function s(l,u=rt){const c=[l,u];return n.add(c),n.size===1&&(r=t(a,i)||rt),l(e),()=>{n.delete(c),n.size===0&&r&&(r(),r=null)}}return{set:a,update:i,subscribe:s}}function ur(e){let t;return xa(e,r=>t=r)(),t}let pn=Symbol("unmounted");function ka(e,t,r){const n=r[t]??={store:null,source:La(void 0),unsubscribe:rt};if(n.store!==e&&!(pn in r))if(n.unsubscribe(),n.store=e??null,e==null)n.source.v=void 0,n.unsubscribe=rt;else{var a=!0;n.unsubscribe=xa(e,i=>{a?n.source.v=i:w(n.source,i)}),a=!1}return e&&pn in r?ur(e):o(n.source)}function Ci(){const e={};function t(){Vr(()=>{for(var r in e)e[r].unsubscribe();Ot(e,pn,{enumerable:!1,value:!0})})}return[e,t]}let gn=null,Qt=null,P=null,mn=null,Xe=null,bn=null,fr=!1,yn=!1,er=null,Lr=null;var Sa=0;let Ai=1;class _t{id=Ai++;#e=!1;linked=!0;#t=null;#r=null;async_deriveds=new Map;current=new Map;previous=new Map;unblocked=new Set;#l=new Set;#n=new Set;#i=new Set;#a=0;#o=new Map;#d=null;#s=[];#v=[];#h=new Set;#c=new Set;#u=new Map;#f=new Set;is_fork=!1;#m=!1;#_(){if(this.is_fork)return!0;for(const n of this.#o.keys()){for(var t=n,r=!1;t.parent!==null;){if(this.#u.has(t)){r=!0;break}t=t.parent}if(!r)return!0}return!1}skip_effect(t){this.#u.has(t)||this.#u.set(t,{d:[],m:[]}),this.#f.delete(t)}unskip_effect(t,r=n=>this.schedule(n)){var n=this.#u.get(t);if(n){this.#u.delete(t);for(var a of n.d)oe(a,ce),r(a);for(a of n.m)oe(a,Ve),r(a)}this.#f.add(t)}#g(){if(this.#e=!0,Sa++>1e3&&(this.#w(),Ti()),!this.#_()){for(const u of this.#h)this.#c.delete(u),oe(u,ce),this.schedule(u);for(const u of this.#c)oe(u,Ve),this.schedule(u)}const t=this.#s;this.#s=[],this.apply();var r=er=[],n=[],a=Lr=[];for(const u of t)try{this.#x(u,r,n)}catch(c){throw Ta(u),c}if(P=null,a.length>0){var i=_t.ensure();for(const u of a)i.schedule(u)}if(er=null,Lr=null,this.#_()){this.#p(n),this.#p(r);for(const[u,c]of this.#u)Aa(u,c);a.length>0&&P.#g();return}const s=this.#k();if(s){s.#b(this);return}this.#h.clear(),this.#c.clear();for(const u of this.#l)u(this);this.#l.clear(),mn=this,Ea(n),Ea(r),mn=null,this.#d?.resolve();var l=P;if(this.linked&&this.#a===0&&this.#w(),this.#s.length>0){l===null&&(l=this,this.#y());const u=l;u.#s.push(...this.#s.filter(c=>!u.#s.includes(c)))}l!==null&&l.#g()}#x(t,r,n){t.f^=le;for(var a=t.first;a!==null;){var i=a.f,s=(i&(Le|qe))!==0,l=s&&(i&le)!==0,u=l||(i&V)!==0||this.#u.has(a);if(!u&&a.fn!==null){s?a.f^=le:(i&gt)!==0?r.push(a):vr(a)&&((i&we)!==0&&this.#c.add(a),tr(a));var c=a.first;if(c!==null){a=c;continue}}for(;a!==null;){var d=a.next;if(d!==null){a=d;break}a=a.parent}}}#k(){for(var t=this.#t;t!==null;){if(!t.is_fork){for(const[r,[,n]]of this.current)if(t.current.has(r)&&!n)return t}t=t.#t}return null}#b(t){for(const[n,a]of t.current)!this.previous.has(n)&&t.previous.has(n)&&this.previous.set(n,t.previous.get(n)),this.current.set(n,a);for(const[n,a]of t.async_deriveds){const i=this.async_deriveds.get(n);i&&a.promise.then(i.resolve)}const r=n=>{var a=n.reactions;if(a!==null)for(const l of a){var i=l.f;if((i&se)!==0)r(l);else{var s=l;i&(Ct|we)&&!this.async_deriveds.has(s)&&(this.#c.delete(s),oe(s,ce),this.schedule(s))}}};for(const n of this.current.keys())r(n);this.oncommit(()=>t.discard()),t.#w(),P=this,this.#g()}#p(t){for(var r=0;r<t.length;r+=1)_a(t[r],this.#h,this.#c)}capture(t,r,n=!1){t.v!==ue&&!this.previous.has(t)&&this.previous.set(t,t.v),(t.f&at)===0&&(this.current.set(t,[r,n]),Xe?.set(t,r)),this.is_fork||(t.v=r)}activate(){P=this}deactivate(){P=null,Xe=null}flush(){try{yn=!0,P=this,this.#g()}finally{Sa=0,bn=null,er=null,Lr=null,yn=!1,P=null,Xe=null,Vt.clear()}}discard(){for(const t of this.#n)t(this);this.#n.clear(),this.#i.clear(),this.#w()}register_created_effect(t){this.#v.push(t)}#S(){this.#w();for(let d=gn;d!==null;d=d.#r){var t=d.id<this.id,r=[];for(const[v,[h,m]]of this.current){if(d.current.has(v)){var n=d.current.get(v)[0];if(t&&h!==n)d.current.set(v,[h,m]);else continue}r.push(v)}if(t)for(const[v,h]of this.async_deriveds){const m=d.async_deriveds.get(v);m&&h.promise.then(m.resolve)}if(d.#e){var a=[...d.current.keys()].filter(v=>!this.current.has(v));if(a.length===0)t&&d.discard();else if(r.length>0){if(t)for(const v of this.#f)d.unskip_effect(v,h=>{(h.f&(we|Ct))!==0?d.schedule(h):d.#p([h])});d.activate();var i=new Set,s=new Map;for(var l of r)Ca(l,a,i,s);s=new Map;var u=[...d.current.keys()].filter(v=>this.current.has(v)?this.current.get(v)[0]!==v.v:!0);if(u.length>0)for(const v of this.#v)(v.f&(K|V|Mt))===0&&wn(v,u,s)&&((v.f&(Ct|we))!==0?(oe(v,ce),d.schedule(v)):d.#h.add(v));if(d.#s.length>0){d.apply();for(var c of d.#s)d.#x(c,[],[]);d.#s=[]}d.deactivate()}}}}increment(t,r){if(this.#a+=1,t){let n=this.#o.get(r)??0;this.#o.set(r,n+1)}}decrement(t,r){if(this.#a-=1,t){let n=this.#o.get(r)??0;n===1?this.#o.delete(r):this.#o.set(r,n-1)}this.#m||(this.#m=!0,yt(()=>{this.#m=!1,this.linked&&this.flush()}))}transfer_effects(t,r){for(const n of t)this.#h.add(n);for(const n of r)this.#c.add(n);t.clear(),r.clear()}oncommit(t){this.#l.add(t)}ondiscard(t){this.#n.add(t)}on_fork_commit(t){this.#i.add(t)}run_fork_commit_callbacks(){for(const t of this.#i)t(this);this.#i.clear()}settled(){return(this.#d??=$r()).promise}static ensure(){if(P===null){const t=P=new _t;t.#y(),!yn&&!fr&&yt(()=>{t.#e||t.flush()})}return P}apply(){{Xe=null;return}}schedule(t){if(bn=t,t.b?.is_pending&&(t.f&(gt|Lt|Wt))!==0&&(t.f&ye)===0){t.b.defer_effect(t);return}for(var r=t;r.parent!==null;){r=r.parent;var n=r.f;if(er!==null&&r===I&&(D===null||(D.f&se)===0))return;if((n&(qe|Le))!==0){if((n&le)===0)return;r.f^=le}}this.#s.push(r)}#y(){Qt===null?gn=Qt=this:(Qt.#r=this,this.#t=Qt),Qt=this}#w(){var t=this.#t,r=this.#r;t===null?gn=r:t.#r=r,r===null?Qt=t:r.#t=t,this.linked=!1}}function W(e){var t=fr;fr=!0;try{for(var r;;){if(bi(),P===null)return r;P.flush()}}finally{fr=t}}function Ti(){try{ii()}catch(e){At(e,bn)}}let xt=null;function Ea(e){var t=e.length;if(t!==0){for(var r=0;r<t;){var n=e[r++];if((n.f&(K|V))===0&&vr(n)&&(xt=new Set,tr(n),n.deps===null&&n.first===null&&n.nodes===null&&n.teardown===null&&n.ac===null&&Za(n),xt?.size>0)){Vt.clear();for(const a of xt){if((a.f&(K|V))!==0)continue;const i=[a];let s=a.parent;for(;s!==null;)xt.has(s)&&(xt.delete(s),i.push(s)),s=s.parent;for(let l=i.length-1;l>=0;l--){const u=i[l];(u.f&(K|V))===0&&tr(u)}}xt.clear()}}xt=null}}function Ca(e,t,r,n){if(!r.has(e)&&(r.add(e),e.reactions!==null))for(const a of e.reactions){const i=a.f;(i&se)!==0?Ca(a,t,r,n):(i&(Ct|we))!==0&&(i&ce)===0&&wn(a,t,n)&&(oe(a,ce),_n(a))}}function wn(e,t,r){const n=r.get(e);if(n!==void 0)return n;if(e.deps!==null)for(const a of e.deps){if(Te.call(t,a))return!0;if((a.f&se)!==0&&wn(a,t,r))return r.set(a,!0),!0}return r.set(e,!1),!1}function _n(e){P.schedule(e)}function Aa(e,t){if(!((e.f&Le)!==0&&(e.f&le)!==0)){(e.f&ce)!==0?t.d.push(e):(e.f&Ve)!==0&&t.m.push(e),oe(e,le);for(var r=e.first;r!==null;)Aa(r,t),r=r.next}}function Ta(e){oe(e,le);for(var t=e.first;t!==null;)Ta(t),t=t.next}function Ii(e){let t=0,r=dr(0),n;return()=>{Sn()&&(o(r),Br(()=>(t===0&&(n=gr(()=>e(()=>hr(r)))),t+=1,()=>{yt(()=>{t-=1,t===0&&(n?.(),n=void 0,hr(r))})})))}}var $i=J|nt;function Ri(e,t,r,n){new Pi(e,t,r,n)}class Pi{parent;is_pending=!1;transform_error;#e;#t=R?M:null;#r;#l;#n;#i=null;#a=null;#o=null;#d=null;#s=0;#v=0;#h=!1;#c=new Set;#u=new Set;#f=null;#m=Ii(()=>(this.#f=dr(this.#s),()=>{this.#f=null}));constructor(t,r,n,a){this.#e=t,this.#r=r,this.#l=i=>{var s=I;s.b=this,s.f|=Je,n(i)},this.parent=I.b,this.transform_error=a??this.parent?.transform_error??(i=>i),this.#n=mr(()=>{if(R){const i=this.#t;Ut();const s=i.data===la;if(i.data.startsWith(ca)){const u=JSON.parse(i.data.slice(ca.length));this.#g(u)}else s?this.#x():this.#_()}else this.#k()},$i),R&&(this.#e=M)}#_(){try{this.#i=ct(()=>this.#l(this.#e))}catch(t){this.error(t)}}#g(t){const r=this.#r.failed;r&&(this.#o=ct(()=>{r(this.#e,()=>t,()=>()=>{})}))}#x(){const t=this.#r.pending;t&&(this.is_pending=!0,this.#a=ct(()=>t(this.#e)),yt(()=>{var r=this.#d=document.createDocumentFragment(),n=it();r.append(n),this.#i=this.#p(()=>ct(()=>this.#l(n))),this.#v===0&&(this.#e.before(r),this.#d=null,br(this.#a,()=>{this.#a=null}),this.#b(P))}))}#k(){try{if(this.is_pending=this.has_pending_snippet(),this.#v=0,this.#s=0,this.#i=ct(()=>{this.#l(this.#e)}),this.#v>0){var t=this.#d=document.createDocumentFragment();eo(this.#i,t);const r=this.#r.pending;this.#a=ct(()=>r(this.#e))}else this.#b(P)}catch(r){this.error(r)}}#b(t){this.is_pending=!1,t.transfer_effects(this.#c,this.#u)}defer_effect(t){_a(t,this.#c,this.#u)}is_rendered(){return!this.is_pending&&(!this.parent||this.parent.is_rendered())}has_pending_snippet(){return!!this.#r.pending}#p(t){var r=I,n=D,a=Ie;lt(this.#n),ze(this.#n),Jt(this.#n.ctx);try{return _t.ensure(),t()}catch(i){return ya(i),null}finally{lt(r),ze(n),Jt(a)}}#S(t,r){if(!this.has_pending_snippet()){this.parent&&this.parent.#S(t,r);return}this.#v+=t,this.#v===0&&(this.#b(r),this.#a&&br(this.#a,()=>{this.#a=null}),this.#d&&(this.#e.before(this.#d),this.#d=null))}update_pending_count(t,r){this.#S(t,r),this.#s+=t,!(!this.#f||this.#h)&&(this.#h=!0,yt(()=>{this.#h=!1,this.#f&&jr(this.#f,this.#s)}))}get_effect_pending(){return this.#m(),o(this.#f)}error(t){if(!this.#r.onerror&&!this.#r.failed)throw t;P?.is_fork?(this.#i&&P.skip_effect(this.#i),this.#a&&P.skip_effect(this.#a),this.#o&&P.skip_effect(this.#o),P.on_fork_commit(()=>{this.#y(t)})):this.#y(t)}#y(t){this.#i&&(_e(this.#i),this.#i=null),this.#a&&(_e(this.#a),this.#a=null),this.#o&&(_e(this.#o),this.#o=null),R&&(Ee(this.#t),cn(),Ee(un()));var r=this.#r.onerror;let n=this.#r.failed;var a=!1,i=!1;const s=()=>{if(a){_i();return}a=!0,i&&fi(),this.#o!==null&&br(this.#o,()=>{this.#o=null}),this.#p(()=>{this.#k()})},l=u=>{try{i=!0,r?.(u,s),i=!1}catch(c){At(c,this.#n&&this.#n.parent)}n&&(this.#o=this.#p(()=>{try{return ct(()=>{var c=I;c.b=this,c.f|=Je,n(this.#e,()=>u,()=>s)})}catch(c){return At(c,this.#n.parent),null}}))};yt(()=>{var u;try{u=this.transform_error(t)}catch(c){At(c,this.#n&&this.#n.parent);return}u!==null&&typeof u=="object"&&typeof u.then=="function"?u.then(l,c=>At(c,this.#n&&this.#n.parent)):l(u)})}}function Ia(e,t,r,n){const a=xn;var i=e.filter(h=>!h.settled);if(r.length===0&&i.length===0){n(t.map(a));return}var s=I,l=Oi(),u=i.length===1?i[0].promise:i.length>1?Promise.all(i.map(h=>h.promise)):null;function c(h){if((s.f&K)===0){l();try{n(h)}catch(m){At(m,s)}Mr()}}var d=$a();if(r.length===0){u.then(()=>c(t.map(a))).finally(d);return}function v(){Promise.all(r.map(h=>Li(h))).then(h=>c([...t.map(a),...h])).catch(h=>At(h,s)).finally(d)}u?u.then(()=>{l(),v(),Mr()}):v()}function Oi(){var e=I,t=D,r=Ie,n=P;return function(i=!0){lt(e),ze(t),Jt(r),i&&(e.f&K)===0&&(n?.activate(),n?.apply())}}function Mr(e=!0){lt(null),ze(null),Jt(null),e&&P?.deactivate()}function $a(){var e=I,t=e.b,r=P,n=t.is_rendered();return t.update_pending_count(1,r),r.increment(n,e),()=>{t.update_pending_count(-1,r),r.decrement(n,e)}}function xn(e){var t=se|ce;return I!==null&&(I.f|=nt),{ctx:Ie,deps:null,effects:null,equals:ia,f:t,fn:e,reactions:null,rv:0,v:ue,wv:0,parent:I,ac:null}}const Nr=Symbol("obsolete");function Li(e,t,r){let n=I;n===null&&ri();var a=void 0,i=dr(ue),s=!D,l=new Set;return Yi(()=>{var u=I,c=$r();a=c.promise;try{Promise.resolve(e()).then(c.resolve,m=>{m!==Pr&&c.reject(m)}).finally(Mr)}catch(m){c.reject(m),Mr()}var d=P;if(s){if((u.f&ye)!==0)var v=$a();if(n.b.is_rendered())d.async_deriveds.get(u)?.reject(Nr);else for(const m of l.values())m.reject(Nr);l.add(c),d.async_deriveds.set(u,c)}const h=(m,g=void 0)=>{v?.(),l.delete(c),g!==Nr&&(d.activate(),g?(i.f|=at,jr(i,g)):((i.f&at)!==0&&(i.f^=at),jr(i,m)),d.deactivate())};c.promise.then(h,m=>h(null,m||"unknown"))}),Vr(()=>{for(const u of l)u.reject(Nr)}),new Promise(u=>{function c(d){function v(){d===a?u(i):c(a)}d.then(v,v)}c(a)})}function Ce(e){const t=xn(e);return Ua(t),t}function Mi(e){var t=e.effects;if(t!==null){e.effects=null;for(var r=0;r<t.length;r+=1)_e(t[r])}}function kn(e){var t,r=I,n=e.parent;if(!kt&&n!==null&&e.v!==ue&&(n.f&(K|V))!==0)return yi(),e.v;lt(n);try{e.f&=~Ze,Mi(e),t=Ha(e)}finally{lt(r)}return t}function Ra(e){var t=kn(e);if(!e.equals(t)&&(e.wv=Ba(),(!P?.is_fork||e.deps===null)&&(P!==null?(P.capture(e,t,!0),mn?.capture(e,t,!0)):e.v=t,e.deps===null))){oe(e,le);return}kt||(Xe!==null?(Sn()||P?.is_fork)&&Xe.set(e,t):vn(e))}function Ni(e){if(e.effects!==null)for(const t of e.effects)(t.teardown||t.ac)&&(t.teardown?.(),t.ac?.abort(Pr),t.fn!==null&&(t.teardown=rt),t.ac=null,pr(t,0),Cn(t))}function Pa(e){if(e.effects!==null)for(const t of e.effects)t.teardown&&t.fn!==null&&tr(t)}let Dr=new Set;const Vt=new Map;let Oa=!1;function dr(e,t){var r={f:0,v:e,reactions:null,equals:ia,rv:0,wv:0};return r}function O(e,t){const r=dr(e);return Ua(r),r}function La(e,t=!1,r=!0){const n=dr(e);return t||(n.equals=ei),n}function w(e,t,r=!1){D!==null&&(!Qe||(D.f&Mt)!==0)&&da()&&(D.f&(se|we|Ct|Mt))!==0&&(He===null||!Te.call(He,e))&&ui();let n=r?wt(t):t;return jr(e,n,Lr)}function jr(e,t,r=null){if(!e.equals(t)){Vt.set(e,kt?t:e.v);var n=_t.ensure();if(n.capture(e,t),(e.f&se)!==0){const a=e;(e.f&ce)!==0&&kn(a),Xe===null&&vn(a)}e.wv=Ba(),Ma(e,ce,r),I!==null&&(I.f&le)!==0&&(I.f&(Le|qe))===0&&(Ke===null?Fi([e]):Ke.push(e)),!n.is_fork&&Dr.size>0&&!Oa&&Di()}return t}function Di(){Oa=!1;for(const e of Dr){(e.f&le)!==0&&oe(e,Ve);let t;try{t=vr(e)}catch{t=!0}t&&tr(e)}Dr.clear()}function hr(e){w(e,e.v+1)}function Ma(e,t,r){var n=e.reactions;if(n!==null)for(var a=n.length,i=0;i<a;i++){var s=n[i],l=s.f,u=(l&ce)===0;if(u&&oe(s,t),(l&Mt)!==0)Dr.add(s);else if((l&se)!==0){var c=s;Xe?.delete(c),(l&Ze)===0&&(l&be&&(I===null||(I.f&Nt)===0)&&(s.f|=Ze),Ma(c,Ve,r))}else if(u){var d=s;(l&we)!==0&&xt!==null&&xt.add(d),r!==null?r.push(d):_n(d)}}}function ji(e,t){if(t){const r=document.body;e.autofocus=!0,yt(()=>{document.activeElement===r&&e.focus()})}}let Na=!1;function Da(){Na||(Na=!0,document.addEventListener("reset",e=>{Promise.resolve().then(()=>{if(!e.defaultPrevented)for(const t of e.target.elements)t[or]?.()})},{capture:!0}))}function Ur(e){var t=D,r=I;ze(null),lt(null);try{return e()}finally{ze(t),lt(r)}}function Ui(e,t,r,n=r){e.addEventListener(t,()=>Ur(r));const a=e[or];a?e[or]=()=>{a(),n(!0)}:e[or]=()=>n(!0),Da()}let Fr=!1,kt=!1;function ja(e){kt=e}let D=null,Qe=!1;function ze(e){D=e}let I=null;function lt(e){I=e}let He=null;function Ua(e){D!==null&&(He===null?He=[e]:He.push(e))}let $e=null,Ne=0,Ke=null;function Fi(e){Ke=e}let Fa=1,Bt=0,zt=Bt;function Va(e){zt=e}function Ba(){return++Fa}function vr(e){var t=e.f;if((t&ce)!==0)return!0;if(t&se&&(e.f&=~Ze),(t&Ve)!==0){for(var r=e.deps,n=r.length,a=0;a<n;a++){var i=r[a];if(vr(i)&&Ra(i),i.wv>e.wv)return!0}(t&be)!==0&&Xe===null&&oe(e,le)}return!1}function za(e,t,r=!0){var n=e.reactions;if(n!==null&&!(He!==null&&Te.call(He,e)))for(var a=0;a<n.length;a++){var i=n[a];(i.f&se)!==0?za(i,t,!1):t===i&&(r?oe(i,ce):(i.f&le)!==0&&oe(i,Ve),_n(i))}}function Ha(e){var t=$e,r=Ne,n=Ke,a=D,i=He,s=Ie,l=Qe,u=zt,c=e.f;$e=null,Ne=0,Ke=null,D=(c&(Le|qe))===0?e:null,He=null,Jt(e.ctx),Qe=!1,zt=++Bt,e.ac!==null&&(Ur(()=>{e.ac.abort(Pr)}),e.ac=null);try{e.f|=Nt;var d=e.fn,v=d();e.f|=ye;var h=e.deps,m=P?.is_fork;if($e!==null){var g;if(m||pr(e,Ne),h!==null&&Ne>0)for(h.length=Ne+$e.length,g=0;g<$e.length;g++)h[Ne+g]=$e[g];else e.deps=h=$e;if(Sn()&&(e.f&be)!==0)for(g=Ne;g<h.length;g++)(h[g].reactions??=[]).push(e)}else!m&&h!==null&&Ne<h.length&&(pr(e,Ne),h.length=Ne);if(da()&&Ke!==null&&!Qe&&h!==null&&(e.f&(se|Ve|ce))===0)for(g=0;g<Ke.length;g++)za(Ke[g],e);if(a!==null&&a!==e){if(Bt++,a.deps!==null)for(let x=0;x<r;x+=1)a.deps[x].rv=Bt;if(t!==null)for(const x of t)x.rv=Bt;Ke!==null&&(n===null?n=Ke:n.push(...Ke))}return(e.f&at)!==0&&(e.f^=at),v}catch(x){return ya(x)}finally{e.f^=Nt,$e=t,Ne=r,Ke=n,D=a,He=i,Jt(s),Qe=l,zt=u}}function Vi(e,t){let r=t.reactions;if(r!==null){var n=rn.call(r,e);if(n!==-1){var a=r.length-1;a===0?r=t.reactions=null:(r[n]=r[a],r.pop())}}if(r===null&&(t.f&se)!==0&&($e===null||!Te.call($e,t))){var i=t;(i.f&be)!==0&&(i.f^=be,i.f&=~Ze),i.v!==ue&&vn(i),Ni(i),pr(i,0)}}function pr(e,t){var r=e.deps;if(r!==null)for(var n=t;n<r.length;n++)Vi(e,r[n])}function tr(e){var t=e.f;if((t&K)===0){oe(e,le);var r=I,n=Fr;I=e,Fr=!0;try{(t&(we|Wt))!==0?Gi(e):Cn(e),qa(e);var a=Ha(e);e.teardown=typeof a=="function"?a:null,e.wv=Fa;var i;Y&&di&&(e.f&ce)!==0&&e.deps}finally{Fr=n,I=r}}}async function Ht(){await Promise.resolve(),W()}function o(e){var t=e.f,r=(t&se)!==0;if(D!==null&&!Qe){var n=I!==null&&(I.f&K)!==0;if(!n&&(He===null||!Te.call(He,e))){var a=D.deps;if((D.f&Nt)!==0)e.rv<Bt&&(e.rv=Bt,$e===null&&a!==null&&a[Ne]===e?Ne++:$e===null?$e=[e]:$e.push(e));else{(D.deps??=[]).push(e);var i=e.reactions;i===null?e.reactions=[D]:Te.call(i,D)||i.push(D)}}}if(kt&&Vt.has(e))return Vt.get(e);if(r){var s=e;if(kt){var l=s.v;return((s.f&le)===0&&s.reactions!==null||Ya(s))&&(l=kn(s)),Vt.set(s,l),l}var u=(s.f&be)===0&&!Qe&&D!==null&&(Fr||(D.f&be)!==0),c=(s.f&ye)===0;vr(s)&&(u&&(s.f|=be),Ra(s)),u&&!c&&(Pa(s),Ka(s))}if(Xe?.has(e))return Xe.get(e);if((e.f&at)!==0)throw e.v;return e.v}function Ka(e){if(e.f|=be,e.deps!==null)for(const t of e.deps)(t.reactions??=[]).push(e),(t.f&se)!==0&&(t.f&be)===0&&(Pa(t),Ka(t))}function Ya(e){if(e.v===ue)return!0;if(e.deps===null)return!1;for(const t of e.deps)if(Vt.has(t)||(t.f&se)!==0&&Ya(t))return!0;return!1}function gr(e){var t=Qe;try{return Qe=!0,e()}finally{Qe=t}}function Bi(e){I===null&&(D===null&&oi(),ai()),kt&&ni()}function zi(e,t){var r=t.last;r===null?t.last=t.first=e:(r.next=e,e.prev=r,t.last=e)}function et(e,t){var r=I;r!==null&&(r.f&V)!==0&&(e|=V);var n={ctx:Ie,deps:null,nodes:null,f:e|ce|be,first:null,fn:t,last:null,next:null,parent:r,b:r&&r.b,prev:null,teardown:null,wv:0,ac:null};P?.register_created_effect(n);var a=n;if((e&gt)!==0)er!==null?er.push(n):_t.ensure().schedule(n);else if(t!==null){try{tr(n)}catch(s){throw _e(n),s}a.deps===null&&a.teardown===null&&a.nodes===null&&a.first===a.last&&(a.f&nt)===0&&(a=a.first,(e&we)!==0&&(e&J)!==0&&a!==null&&(a.f|=J))}if(a!==null&&(a.parent=r,r!==null&&zi(a,r),D!==null&&(D.f&se)!==0&&(e&qe)===0)){var i=D;(i.effects??=[]).push(a)}return n}function Sn(){return D!==null&&!Qe}function Vr(e){const t=et(Lt,null);return oe(t,le),t.teardown=e,t}function Re(e){Bi();var t=I.f,r=!D&&(t&Le)!==0&&(t&ye)===0;if(r){var n=Ie;(n.e??=[]).push(e)}else return Ga(e)}function Ga(e){return et(gt|Rr,e)}function Hi(e){_t.ensure();const t=et(qe|nt,e);return()=>{_e(t)}}function Ki(e){_t.ensure();const t=et(qe|nt,e);return(r={})=>new Promise(n=>{r.outro?br(t,()=>{_e(t),n(void 0)}):(_e(t),n(void 0))})}function En(e){return et(gt,e)}function Yi(e){return et(Ct|nt,e)}function Br(e,t=0){return et(Lt|t,e)}function ke(e,t=[],r=[],n=[]){Ia(n,t,r,a=>{et(Lt,()=>e(...a.map(o)))})}function mr(e,t=0){var r=et(we|t,e);return r}function Wa(e,t=0){var r=et(Wt|t,e);return r}function ct(e){return et(Le|nt,e)}function qa(e){var t=e.teardown;if(t!==null){const r=kt,n=D;ja(!0),ze(null);try{t.call(null)}finally{ja(r),ze(n)}}}function Cn(e,t=!1){var r=e.first;for(e.first=e.last=null;r!==null;){const a=r.ac;a!==null&&Ur(()=>{a.abort(Pr)});var n=r.next;(r.f&qe)!==0?r.parent=null:_e(r,t),r=n}}function Gi(e){for(var t=e.first;t!==null;){var r=t.next;(t.f&Le)===0&&_e(t),t=r}}function _e(e,t=!0){var r=!1;(t||(e.f&Be)!==0)&&e.nodes!==null&&e.nodes.end!==null&&(Ja(e.nodes.start,e.nodes.end),r=!0),oe(e,ve),Cn(e,t&&!r),pr(e,0);var n=e.nodes&&e.nodes.t;if(n!==null)for(const i of n)i.stop();qa(e),e.f^=ve,e.f|=K;var a=e.parent;a!==null&&a.first!==null&&Za(e),e.next=e.prev=e.teardown=e.ctx=e.deps=e.fn=e.nodes=e.ac=e.b=null}function Ja(e,t){for(;e!==null;){var r=e===t?null:st(e);e.remove(),e=r}}function Za(e){var t=e.parent,r=e.prev,n=e.next;r!==null&&(r.next=n),n!==null&&(n.prev=r),t!==null&&(t.first===e&&(t.first=n),t.last===e&&(t.last=r))}function br(e,t,r=!0){var n=[];Xa(e,n,!0);var a=()=>{r&&_e(e),t&&t()},i=n.length;if(i>0){var s=()=>--i||a();for(var l of n)l.out(s)}else a()}function Xa(e,t,r){if((e.f&V)===0){e.f^=V;var n=e.nodes&&e.nodes.t;if(n!==null)for(const l of n)(l.is_global||r)&&t.push(l);for(var a=e.first;a!==null;){var i=a.next;if((a.f&qe)===0){var s=(a.f&J)!==0||(a.f&Le)!==0&&(e.f&we)!==0;Xa(a,t,s?r:!1)}a=i}}}function Wi(e){Qa(e,!0)}function Qa(e,t){if((e.f&V)!==0){e.f^=V,(e.f&le)===0&&(oe(e,ce),_t.ensure().schedule(e));for(var r=e.first;r!==null;){var n=r.next,a=(r.f&J)!==0||(r.f&Le)!==0;Qa(r,a?t:!1),r=n}var i=e.nodes&&e.nodes.t;if(i!==null)for(const s of i)(s.is_global||t)&&s.in()}}function eo(e,t){if(e.nodes)for(var r=e.nodes.start,n=e.nodes.end;r!==null;){var a=r===n?null:st(r);t.append(r),r=a}}function to(e){const t={get:r=>ur(t.store)[r],set:(r,n)=>{typeof r=="string"?Object.assign(ur(t.store),{[r]:n}):Object.assign(ur(t.store),r),t.store.set(ur(t.store))},store:Ei(e)};return t}globalThis.$altcha=globalThis.$altcha||{algorithms:new Map,defaults:to({}),i18n:to({}),instances:new Set,plugins:new Set};const qi={ariaLinkLabel:"Altcha (official website)",cancel:"Cancel",enterCode:"Enter code",enterCodeAria:"Enter code you hear. Press Space to play audio.",enterCodeFromImage:"To proceed, please enter the code from the image below.",error:"Verification failed. Try again later.",expired:"Verification expired. Try again.",footer:'Protected by <a href="https://altcha.org/" tabindex="-1" target="_blank" aria-label="Altcha (official website)">ALTCHA</a>',getAudioChallenge:"Get an audio challenge",label:"I'm not a robot",loading:"Loading...",reload:"Reload",verify:"Verify",verificationRequired:"Verification required!",verified:"Verified",verifying:"Verifying...",waitAlert:"Verifying... please wait."};globalThis.$altcha.i18n.set("en",qi);const Ji="5";typeof window<"u"&&((window.__svelte??={}).v??=new Set).add(Ji);const yr=Symbol("events"),ro=new Set,An=new Set;function no(e,t,r,n={}){function a(i){if(n.capture||Tn.call(t,i),!i.cancelBubble)return Ur(()=>r?.call(this,i))}return e.startsWith("pointer")||e.startsWith("touch")||e==="wheel"?yt(()=>{t.addEventListener(e,a,n)}):t.addEventListener(e,a,n),a}function pe(e,t,r,n,a){var i={capture:n,passive:a},s=no(e,t,r,i);(t===document.body||t===window||t===document||t instanceof HTMLMediaElement)&&Vr(()=>{t.removeEventListener(e,s,i)})}function zr(e,t,r){(t[yr]??={})[e]=r}function Hr(e){for(var t=0;t<e.length;t++)ro.add(e[t]);for(var r of An)r(e)}let ao=null;function Tn(e){var t=this,r=t.ownerDocument,n=e.type,a=e.composedPath?.()||[],i=a[0]||e.target;ao=e;var s=0,l=ao===e&&e[yr];if(l){var u=a.indexOf(l);if(u!==-1&&(t===document||t===window)){e[yr]=t;return}var c=a.indexOf(t);if(c===-1)return;u<=c&&(s=u)}if(i=a[s]||e.target,i!==t){Ot(e,"currentTarget",{configurable:!0,get(){return i||r}});var d=D,v=I;ze(null),lt(null);try{for(var h,m=[];i!==null;){var g=i.assignedSlot||i.parentNode||i.host||null;try{var x=i[yr]?.[n];x!=null&&(!i.disabled||e.target===i)&&x.call(i,e)}catch(T){h?m.push(T):h=T}if(e.cancelBubble||g===t||g===null)break;i=g}if(h){for(let T of m)queueMicrotask(()=>{throw T});throw h}}finally{e[yr]=t,delete e.currentTarget,ze(d),lt(v)}}}const Zi=globalThis?.window?.trustedTypes&&globalThis.window.trustedTypes.createPolicy("svelte-trusted-html",{createHTML:e=>e});function Xi(e){return Zi?.createHTML(e)??e}function oo(e){var t=hn("template");return t.innerHTML=Xi(e.replaceAll("<!>","<!---->")),t.content}function De(e,t){var r=I;r.nodes===null&&(r.nodes={start:e,end:t,a:null,t:null})}function te(e,t){var r=(t&hi)!==0,n=(t&vi)!==0,a,i=!e.startsWith("<!>");return()=>{if(R)return De(M,null),M;a===void 0&&(a=oo(i?e:"<!>"+e),r||(a=Me(a)));var s=n||ga?document.importNode(a,!0):a.cloneNode(!0);if(r){var l=Me(s),u=s.lastChild;De(l,u)}else De(s,s);return s}}function Qi(e,t,r="svg"){var n=!e.startsWith("<!>"),a=`<${r}>${n?e:"<!>"+e}</${r}>`,i;return()=>{if(R)return De(M,null),M;if(!i){var s=oo(a),l=Me(s);i=Me(l)}var u=i.cloneNode(!0);return De(u,u),u}}function In(e,t){return Qi(e,t,"svg")}function Kr(e=""){if(!R){var t=it(e+"");return De(t,t),t}var r=M;return r.nodeType!==sr?(r.before(r=it()),Ee(r)):Or(r),De(r,r),r}function io(){if(R)return De(M,null),M;var e=document.createDocumentFragment(),t=document.createComment(""),r=it();return e.append(t,r),De(t,r),e}function N(e,t){if(R){var r=I;((r.f&ye)===0||r.nodes.end===null)&&(r.nodes.end=M),Ut();return}e!==null&&e.before(t)}function es(e){return e.endsWith("capture")&&e!=="gotpointercapture"&&e!=="lostpointercapture"}const ts=["beforeinput","click","change","dblclick","contextmenu","focusin","focusout","input","keydown","keyup","mousedown","mousemove","mouseout","mouseover","mouseup","pointerdown","pointermove","pointerout","pointerover","pointerup","touchend","touchmove","touchstart"];function rs(e){return ts.includes(e)}const ns={formnovalidate:"formNoValidate",ismap:"isMap",nomodule:"noModule",playsinline:"playsInline",readonly:"readOnly",defaultvalue:"defaultValue",defaultchecked:"defaultChecked",srcobject:"srcObject",novalidate:"noValidate",allowfullscreen:"allowFullscreen",disablepictureinpicture:"disablePictureInPicture",disableremoteplayback:"disableRemotePlayback"};function as(e){return e=e.toLowerCase(),ns[e]??e}const os=["touchstart","touchmove"];function is(e){return os.includes(e)}function ut(e,t){var r=t==null?"":typeof t=="object"?`${t}`:t;r!==(e[sn]??=e.nodeValue)&&(e[sn]=r,e.nodeValue=`${r}`)}function so(e,t){return lo(e,t)}function ss(e,t){dn(),t.intro=t.intro??!1;const r=t.target,n=R,a=M;try{for(var i=Me(r);i&&(i.nodeType!==lr||i.data!==ln);)i=st(i);if(!i)throw Dt;ot(!0),Ee(i);const s=lo(e,{...t,anchor:i});return ot(!1),s}catch(s){if(s instanceof Error&&s.message.split(`
`).some(l=>l.startsWith("https://svelte.dev/e/")))throw s;return s!==Dt&&console.warn("Failed to hydrate: ",s),t.recover===!1&&si(),dn(),ki(r),ot(!1),so(e,t)}finally{ot(n),Ee(a)}}const Yr=new Map;function lo(e,{target:t,anchor:r,props:n={},events:a,context:i,intro:s=!0,transformError:l}){dn();var u=void 0,c=Ki(()=>{var d=r??t.appendChild(it());Ri(d,{pending:()=>{}},m=>{mt({});var g=Ie;if(i&&(g.c=i),a&&(n.$$events=a),R&&De(m,null),u=e(m,n)||{},R&&(I.nodes.end=M,M===null||M.nodeType!==lr||M.data!==ua))throw cr(),Dt;bt()},l);var v=new Set,h=m=>{for(var g=0;g<m.length;g++){var x=m[g];if(!v.has(x)){v.add(x);var T=is(x);for(const fe of[t,document]){var L=Yr.get(fe);L===void 0&&(L=new Map,Yr.set(fe,L));var me=L.get(x);me===void 0?(fe.addEventListener(x,Tn,{passive:T}),L.set(x,1)):L.set(x,me+1)}}}};return h(Ar(ro)),An.add(h),()=>{for(var m of v)for(const T of[t,document]){var g=Yr.get(T),x=g.get(m);--x==0?(T.removeEventListener(m,Tn),g.delete(m),g.size===0&&Yr.delete(T)):g.set(m,x)}An.delete(h),d!==r&&d.parentNode?.removeChild(d)}});return $n.set(u,c),u}let $n=new WeakMap;function ls(e,t){const r=$n.get(e);return r?($n.delete(e),r(t)):Promise.resolve()}class Gr{anchor;#e=new Map;#t=new Map;#r=new Map;#l=new Set;#n=!0;constructor(t,r=!0){this.anchor=t,this.#n=r}#i=t=>{if(this.#e.has(t)){var r=this.#e.get(t),n=this.#t.get(r);if(n)Wi(n),this.#l.delete(r);else{var a=this.#r.get(r);a&&(this.#t.set(r,a.effect),this.#r.delete(r),a.fragment.lastChild.remove(),this.anchor.before(a.fragment),n=a.effect)}for(const[i,s]of this.#e){if(this.#e.delete(i),i===t)break;const l=this.#r.get(s);l&&(_e(l.effect),this.#r.delete(s))}for(const[i,s]of this.#t){if(i===r||this.#l.has(i))continue;const l=()=>{if(Array.from(this.#e.values()).includes(i)){var c=document.createDocumentFragment();eo(s,c),c.append(it()),this.#r.set(i,{effect:s,fragment:c})}else _e(s);this.#l.delete(i),this.#t.delete(i)};this.#n||!n?(this.#l.add(i),br(s,l,!1)):l()}}};#a=t=>{this.#e.delete(t);const r=Array.from(this.#e.values());for(const[n,a]of this.#r)r.includes(n)||(_e(a.effect),this.#r.delete(n))};ensure(t,r){var n=P;r&&!this.#t.has(t)&&!this.#r.has(t)&&this.#t.set(t,ct(()=>r(this.anchor))),this.#e.set(n,t),R&&(this.anchor=M),this.#i(n)}}function cs(e,t,...r){var n=new Gr(e);mr(()=>{const a=t()??null;n.ensure(a,a&&(i=>a(i,...r)))},J)}function Rn(e){Ie===null&&ti(),Re(()=>{const t=gr(e);if(typeof t=="function")return t})}function ge(e,t,r=!1){var n;R&&(n=M,Ut());var a=new Gr(e),i=r?J:0;function s(l,u){if(R){var c=va(n);if(l!==parseInt(c.substring(1))){var d=un();Ee(d),a.anchor=d,ot(!1),a.ensure(l,u),ot(!0);return}}a.ensure(l,u)}mr(()=>{var l=!1;t((u,c=0)=>{l=!0,s(c,u)}),l||s(-1,null)},i)}const us=Symbol("NaN");function fs(e,t,r){R&&Ut();var n=new Gr(e);mr(()=>{var a=t();a!==a&&(a=us),n.ensure(a,r)})}function co(e,t,r=!1,n=!1,a=!1,i=!1){var s=e,l="";if(r){var u=e;R&&(s=Ee(Me(u)))}ke(()=>{var c=I;if(l===(l=t()??"")){R&&Ut();return}if(r&&!R){c.nodes=null,u.innerHTML=l,l!==""&&De(Me(u),u.lastChild);return}if(c.nodes!==null&&(Ja(c.nodes.start,c.nodes.end),c.nodes=null),l!==""){if(R){M.data;for(var d=Ut(),v=d;d!==null&&(d.nodeType!==lr||d.data!=="");)v=d,d=st(d);if(d===null)throw cr(),Dt;De(M,v),s=Ee(d);return}var h=n?pi:a?gi:void 0,m=hn(n?"svg":a?"math":"template",h);m.innerHTML=l;var g=n||a?m:m.content;if(De(Me(g),g.lastChild),n||a)for(;Me(g);)s.before(Me(g));else s.before(g)}})}function ds(e,t,r){var n;R&&(n=M,Ut());var a=new Gr(e);mr(()=>{var i=t()??null;if(R){var s=va(n),l=s===ln,u=i!==null;if(l!==u){var c=un();Ee(c),a.anchor=c,ot(!1),a.ensure(i,i&&(d=>r(d,i))),ot(!0);return}}a.ensure(i,i&&(d=>r(d,i)))},J)}function hs(e,t){var r=void 0,n;Wa(()=>{r!==(r=t())&&(n&&(_e(n),n=null),r&&(n=ct(()=>{En(()=>r(e))})))})}function uo(e){var t,r,n="";if(typeof e=="string"||typeof e=="number")n+=e;else if(typeof e=="object")if(Array.isArray(e)){var a=e.length;for(t=0;t<a;t++)e[t]&&(r=uo(e[t]))&&(n&&(n+=" "),n+=r)}else for(r in e)e[r]&&(n&&(n+=" "),n+=r);return n}function vs(){for(var e,t,r=0,n="",a=arguments.length;r<a;r++)(e=arguments[r])&&(t=uo(e))&&(n&&(n+=" "),n+=t);return n}function ps(e){return typeof e=="object"?vs(e):e??""}const fo=[...` 	
\r\f \v\uFEFF`];function gs(e,t,r){var n=e==null?"":""+e;if(r){for(var a of Object.keys(r))if(r[a])n=n?n+" "+a:a;else if(n.length)for(var i=a.length,s=0;(s=n.indexOf(a,s))>=0;){var l=s+i;(s===0||fo.includes(n[s-1]))&&(l===n.length||fo.includes(n[l]))?n=(s===0?"":n.substring(0,s))+n.substring(l+1):s=l}}return n===""?null:n}function ho(e,t=!1){var r=t?" !important;":";",n="";for(var a of Object.keys(e)){var i=e[a];i!=null&&i!==""&&(n+=" "+a+": "+i+r)}return n}function Pn(e){return e[0]!=="-"||e[1]!=="-"?e.toLowerCase():e}function ms(e,t){if(t){var r="",n,a;if(Array.isArray(t)?(n=t[0],a=t[1]):n=t,e){e=String(e).replaceAll(/\s*\/\*.*?\*\/\s*/g,"").trim();var i=!1,s=0,l=!1,u=[];n&&u.push(...Object.keys(n).map(Pn)),a&&u.push(...Object.keys(a).map(Pn));var c=0,d=-1;const x=e.length;for(var v=0;v<x;v++){var h=e[v];if(l?h==="/"&&e[v-1]==="*"&&(l=!1):i?i===h&&(i=!1):h==="/"&&e[v+1]==="*"?l=!0:h==='"'||h==="'"?i=h:h==="("?s++:h===")"&&s--,!l&&i===!1&&s===0){if(h===":"&&d===-1)d=v;else if(h===";"||v===x-1){if(d!==-1){var m=Pn(e.substring(c,d).trim());if(!u.includes(m)){h!==";"&&v++;var g=e.substring(c,v).trim();r+=" "+g+";"}}c=v+1,d=-1}}}}return n&&(r+=ho(n)),a&&(r+=ho(a,!0)),r=r.trim(),r===""?null:r}return e==null?null:String(e)}function bs(e,t,r,n,a,i){var s=e[an];if(R||s!==r||s===void 0){var l=gs(r,n,i);(!R||l!==e.getAttribute("class"))&&(l==null?e.removeAttribute("class"):t?e.className=l:e.setAttribute("class",l)),e[an]=r}else if(i&&a!==i)for(var u in i){var c=!!i[u];(a==null||c!==!!a[u])&&e.classList.toggle(u,c)}return i}function On(e,t={},r,n){for(var a in r){var i=r[a];t[a]!==i&&(r[a]==null?e.style.removeProperty(a):e.style.setProperty(a,i,n))}}function ys(e,t,r,n){var a=e[on];if(R||a!==t){var i=ms(t,n);(!R||i!==e.getAttribute("style"))&&(i==null?e.removeAttribute("style"):e.style.cssText=i),e[on]=t}else n&&(Array.isArray(n)?(On(e,r?.[0],n[0]),On(e,r?.[1],n[1],"important")):On(e,r,n));return n}function Ln(e,t,r=!1){if(e.multiple){if(t==null)return;if(!St(t))return wi();for(var n of e.options)n.selected=t.includes(vo(n));return}for(n of e.options){var a=vo(n);if(xi(a,t)){n.selected=!0;return}}(!r||t!==void 0)&&(e.selectedIndex=-1)}function ws(e){var t=new MutationObserver(()=>{Ln(e,e.__value)});t.observe(e,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value"]}),Vr(()=>{t.disconnect()})}function vo(e){return"__value"in e?e.__value:e.value}const wr=Symbol("class"),_r=Symbol("style"),po=Symbol("is custom element"),go=Symbol("is html"),_s=ir?"link":"LINK",xs=ir?"input":"INPUT",ks=ir?"option":"OPTION",Ss=ir?"select":"SELECT",Es=ir?"progress":"PROGRESS";function Mn(e){if(R){var t=!1,r=()=>{if(!t){if(t=!0,e.hasAttribute("value")){var n=e.value;z(e,"value",null),e.value=n}if(e.hasAttribute("checked")){var a=e.checked;z(e,"checked",null),e.checked=a}}};e[or]=r,yt(r),Da()}}function Cs(e,t){var r=Nn(e);r.value===(r.value=t??void 0)||e.value===t&&(t!==0||e.nodeName!==Es)||(e.value=t??"")}function As(e,t){t?e.hasAttribute("selected")||e.setAttribute("selected",""):e.removeAttribute("selected")}function z(e,t,r,n){var a=Nn(e);R&&(a[t]=e.getAttribute(t),t==="src"||t==="srcset"||t==="href"&&e.nodeName===_s)||a[t]!==(a[t]=r)&&(t==="loading"&&(e[Qo]=r),r==null?e.removeAttribute(t):typeof r!="string"&&bo(e).includes(t)?e[t]=r:e.setAttribute(t,r))}function Ts(e,t,r,n,a=!1,i=!1){if(R&&a&&e.nodeName===xs){var s=e,l=s.type==="checkbox"?"defaultChecked":"defaultValue";l in r||Mn(s)}var u=Nn(e),c=u[po],d=!u[go];let v=R&&c;v&&ot(!1);var h=t||{},m=e.nodeName===ks;for(var g in t)g in r||(r[g]=null);r.class?r.class=ps(r.class):r[wr]&&(r.class=null),r[_r]&&(r.style??=null);var x=bo(e);for(const U in r){let E=r[U];if(m&&U==="value"&&E==null){e.value=e.__value="",h[U]=E;continue}if(U==="class"){var T=e.namespaceURI==="http://www.w3.org/1999/xhtml";bs(e,T,E,n,t?.[wr],r[wr]),h[U]=E,h[wr]=r[wr];continue}if(U==="style"){ys(e,E,t?.[_r],r[_r]),h[U]=E,h[_r]=r[_r];continue}var L=h[U];if(!(E===L&&!(E===void 0&&e.hasAttribute(U)))){h[U]=E;var me=U[0]+U[1];if(me!=="$$")if(me==="on"){const X={},Ae="$$"+U;let $=U.slice(2);var fe=rs($);if(es($)&&($=$.slice(0,-7),X.capture=!0),!fe&&L){if(E!=null)continue;e.removeEventListener($,h[Ae],X),h[Ae]=null}if(fe)zr($,e,E),Hr([$]);else if(E!=null){let de=function(ft){h[U].call(this,ft)};h[Ae]=no($,e,de,X)}}else if(U==="style")z(e,U,E);else if(U==="autofocus")ji(e,!!E);else if(!c&&(U==="__value"||U==="value"&&E!=null))e.value=e.__value=E;else if(U==="selected"&&m)As(e,E);else{var j=U;d||(j=as(j));var Se=j==="defaultValue"||j==="defaultChecked";if(E==null&&!c&&!Se)if(u[U]=null,j==="value"||j==="checked"){let X=e;const Ae=t===void 0;if(j==="value"){let $=X.defaultValue;X.removeAttribute(j),X.defaultValue=$,X.value=X.__value=Ae?$:null}else{let $=X.defaultChecked;X.removeAttribute(j),X.defaultChecked=$,X.checked=Ae?$:!1}}else e.removeAttribute(U);else Se||x.includes(j)&&(c||typeof E!="string")?(e[j]=E,j in u&&(u[j]=ue)):typeof E!="function"&&z(e,j,E)}}}return v&&ot(!0),h}function Wr(e,t,r=[],n=[],a=[],i,s=!1,l=!1){Ia(a,r,n,u=>{var c=void 0,d={},v=e.nodeName===Ss,h=!1;if(Wa(()=>{var g=t(...u.map(o)),x=Ts(e,c,g,i,s,l);h&&v&&"value"in g&&Ln(e,g.value);for(let L of Object.getOwnPropertySymbols(d))g[L]||_e(d[L]);for(let L of Object.getOwnPropertySymbols(g)){var T=g[L];L.description===mi&&(!c||T!==c[L])&&(d[L]&&_e(d[L]),d[L]=ct(()=>hs(e,()=>T))),x[L]=T}c=x}),v){var m=e;En(()=>{Ln(m,c.value,!0),ws(m)})}h=!0})}function Nn(e){return e[oa]??={[po]:e.nodeName.includes("-"),[go]:e.namespaceURI===fa}}var mo=new Map;function bo(e){var t=e.getAttribute("is")||e.nodeName,r=mo.get(t);if(r)return r;mo.set(t,r=[]);for(var n,a=e,i=Element.prototype;i!==a;){n=nn(a);for(var s in n)n[s].set&&s!=="innerHTML"&&s!=="textContent"&&s!=="innerText"&&r.push(s);a=Ir(a)}return r}function Is(e,t,r=t){var n=new WeakSet;Ui(e,"input",async a=>{var i=a?e.defaultValue:e.value;if(i=Dn(e)?jn(i):i,r(i),P!==null&&n.add(P),await Ht(),i!==(i=t())){var s=e.selectionStart,l=e.selectionEnd,u=e.value.length;if(e.value=i??"",l!==null){var c=e.value.length;s===l&&l===u&&c>u?(e.selectionStart=c,e.selectionEnd=c):(e.selectionStart=s,e.selectionEnd=Math.min(l,c))}}}),(R&&e.defaultValue!==e.value||gr(t)==null&&e.value)&&(r(Dn(e)?jn(e.value):e.value),P!==null&&n.add(P)),Br(()=>{var a=t();if(e===document.activeElement){var i=P;if(n.has(i))return}Dn(e)&&a===jn(e.value)||e.type==="date"&&!a&&!e.value||a!==e.value&&(e.value=a??"")})}function Dn(e){var t=e.type;return t==="number"||t==="range"}function jn(e){return e===""?null:+e}function Un(e,t){return e===t||e?.[qt]===t}function Tt(e={},t,r,n){var a=Ie.r,i=I;return En(()=>{var s,l;return Br(()=>{s=l,l=[],gr(()=>{Un(r(...l),e)||(t(e,...l),s&&Un(r(...s),e)&&t(null,...s))})}),()=>{let u=i;for(;u!==a&&u.parent!==null&&u.parent.f&ve;)u=u.parent;const c=()=>{l&&Un(r(...l),e)&&t(null,...l)},d=u.teardown;u.teardown=()=>{c(),d?.()}}}),e}const $s={get(e,t){if(!e.exclude.includes(t))return e.props[t]},set(e,t){return!1},getOwnPropertyDescriptor(e,t){if(!e.exclude.includes(t)&&t in e.props)return{enumerable:!0,configurable:!0,value:e.props[t]}},has(e,t){return e.exclude.includes(t)?!1:t in e.props},ownKeys(e){return Reflect.ownKeys(e.props).filter(t=>!e.exclude.includes(t))}};function qr(e,t,r){return new Proxy({props:e,exclude:t},$s)}function re(e,t,r,n){var a=n,i=!0,s=()=>(i&&(i=!1,a=n),a),l;l=e[t],l===void 0&&n!==void 0&&(l=s());var u;u=()=>{var h=e[t];return h===void 0?s():(i=!0,h)};var c=!1,d=xn(()=>(c=!1,u())),v=I;return(function(h,m){if(arguments.length>0){const g=m?o(d):h;return w(d,g),c=!0,a!==void 0&&(a=g),h}return kt&&c||(v.f&K)!==0?d.v:o(d)})}function Rs(e){return new Ps(e)}class Ps{#e;#t;constructor(t){var r=new Map,n=(i,s)=>{var l=La(s,!1,!1);return r.set(i,l),l};const a=new Proxy({...t.props||{},$$events:{}},{get(i,s){return o(r.get(s)??n(s,Reflect.get(i,s)))},has(i,s){return s===Xo?!0:(o(r.get(s)??n(s,Reflect.get(i,s))),Reflect.has(i,s))},set(i,s,l){return w(r.get(s)??n(s,l),l),Reflect.set(i,s,l)}});this.#t=(t.hydrate?ss:so)(t.component,{target:t.target,anchor:t.anchor,props:a,context:t.context,intro:t.intro??!1,recover:t.recover,transformError:t.transformError}),(!t?.props?.$$host||t.sync===!1)&&W(),this.#e=a.$$events;for(const i of Object.keys(this.#t))i==="$set"||i==="$destroy"||i==="$on"||Ot(this,i,{get(){return this.#t[i]},set(s){this.#t[i]=s},enumerable:!0});this.#t.$set=i=>{Object.assign(a,i)},this.#t.$destroy=()=>{ls(this.#t)}}$set(t){this.#t.$set(t)}$on(t,r){this.#e[t]=this.#e[t]||[];const n=(...a)=>r.call(this,...a);return this.#e[t].push(n),()=>{this.#e[t]=this.#e[t].filter(a=>a!==n)}}$destroy(){this.#t.$destroy()}}let yo=class{};typeof HTMLElement=="function"&&(yo=class extends HTMLElement{$$ctor;$$s;$$c;$$cn=!1;$$d={};$$r=!1;$$p_d={};$$l={};$$l_u=new Map;$$me;$$shadowRoot=null;constructor(e,t,r){super(),this.$$ctor=e,this.$$s=t,r&&(this.$$shadowRoot=this.attachShadow(r))}addEventListener(e,t,r){if(this.$$l[e]=this.$$l[e]||[],this.$$l[e].push(t),this.$$c){const n=this.$$c.$on(e,t);this.$$l_u.set(t,n)}super.addEventListener(e,t,r)}removeEventListener(e,t,r){if(super.removeEventListener(e,t,r),this.$$c){const n=this.$$l_u.get(t);n&&(n(),this.$$l_u.delete(t))}}async connectedCallback(){if(this.$$cn=!0,!this.$$c){let e=function(n){return a=>{const i=hn("slot");n!=="default"&&(i.name=n),N(a,i)}};if(await Promise.resolve(),!this.$$cn||this.$$c)return;const t={},r=Os(this);for(const n of this.$$s)n in r&&(n==="default"&&!this.$$d.children?(this.$$d.children=e(n),t.default=!0):t[n]=e(n));for(const n of this.attributes){const a=this.$$g_p(n.name);a in this.$$d||(this.$$d[a]=Jr(a,n.value,this.$$p_d,"toProp"))}for(const n in this.$$p_d)!(n in this.$$d)&&this[n]!==void 0&&(this.$$d[n]=this[n],delete this[n]);this.$$c=Rs({component:this.$$ctor,target:this.$$shadowRoot||this,props:{...this.$$d,$$slots:t,$$host:this}}),this.$$me=Hi(()=>{Br(()=>{this.$$r=!0;for(const n of Pt(this.$$c)){if(!this.$$p_d[n]?.reflect)continue;this.$$d[n]=this.$$c[n];const a=Jr(n,this.$$d[n],this.$$p_d,"toAttribute");a==null?this.removeAttribute(this.$$p_d[n].attribute||n):this.setAttribute(this.$$p_d[n].attribute||n,a)}this.$$r=!1})});for(const n in this.$$l)for(const a of this.$$l[n]){const i=this.$$c.$on(n,a);this.$$l_u.set(a,i)}this.$$l={}}}attributeChangedCallback(e,t,r){this.$$r||(e=this.$$g_p(e),this.$$d[e]=Jr(e,r,this.$$p_d,"toProp"),this.$$c?.$set({[e]:this.$$d[e]}))}disconnectedCallback(){this.$$cn=!1,Promise.resolve().then(()=>{!this.$$cn&&this.$$c&&(this.$$c.$destroy(),this.$$me(),this.$$c=void 0)})}$$g_p(e){return Pt(this.$$p_d).find(t=>this.$$p_d[t].attribute===e||!this.$$p_d[t].attribute&&t.toLowerCase()===e)||e}});function Jr(e,t,r,n){const a=r[e]?.type;if(t=a==="Boolean"&&typeof t!="boolean"?t!=null:t,!n||!r[e])return t;if(n==="toAttribute")switch(a){case"Object":case"Array":return t==null?null:JSON.stringify(t);case"Boolean":return t?"":null;case"Number":return t??null;default:return t}else switch(a){case"Object":case"Array":return t&&JSON.parse(t);case"Boolean":return t;case"Number":return t!=null?+t:t;default:return t}}function Os(e){const t={};return e.childNodes.forEach(r=>{t[r.slot||"default"]=!0}),t}function It(e,t,r,n,a,i){let s=class extends yo{constructor(){super(e,r,a),this.$$p_d=t}static get observedAttributes(){return Pt(t).map(l=>(t[l].attribute||l).toLowerCase())}};return Pt(t).forEach(l=>{Ot(s.prototype,l,{get(){return this.$$c&&l in this.$$c?this.$$c[l]:this.$$d[l]},set(u){u=Jr(l,u,t),this.$$d[l]=u;var c=this.$$c;if(c){var d=pt(c,l)?.get;d?c[l]=u:c.$set({[l]:u})}}})}),n.forEach(l=>{Ot(s.prototype,l,{get(){return this.$$c?.[l]}})}),e.element=s,s}var Ls=te('<div class="altcha-checkbox"><input/> <svg aria-hidden="true" width="12" height="9" viewBox="0 0 12 9"><polyline points="1 5 4 8 11 1"></polyline></svg> <div class="altcha-spinner altcha-checkbox-spinner" aria-hidden="true"></div></div>');function wo(e,t){mt(t,!0);let r=re(t,"loading"),n=qr(t,["$$slots","$$events","$$legacy","$$host","loading"]),a;function i(){a?.click()}var s={get loading(){return r()},set loading(d){r(d),W()}},l=Ls(),u=ne(l);Wr(u,()=>({type:"checkbox",...n}),void 0,void 0,void 0,void 0,!0),Tt(u,d=>a=d,()=>a);var c=ee(u,2);return cn(2),Z(l),ke(()=>z(l,"data-loading",r())),zr("click",c,i),N(e,l),bt(s)}Hr(["click"]),It(wo,{loading:{}},[],[],{mode:"open"});var Ms=te('<div class="altcha-checkbox-native"><input/> <div class="altcha-spinner altcha-checkbox-native-spinner"></div></div>');function _o(e,t){mt(t,!0);let r=re(t,"loading"),n=qr(t,["$$slots","$$events","$$legacy","$$host","loading"]);var a={get loading(){return r()},set loading(l){r(l),W()}},i=Ms(),s=ne(i);return Wr(s,()=>({type:"checkbox",...n}),void 0,void 0,void 0,void 0,!0),cn(2),Z(i),ke(()=>z(i,"data-loading",r())),N(e,i),bt(a)}It(_o,{loading:{}},[],[],{mode:"open"});var Ns=te('<div><a target="_blank" class="altcha-logo" aria-hidden="true" tabindex="-1"><svg width="22" height="22" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.33955 16.4279C5.88954 20.6586 12.1971 21.2105 16.4279 17.6604C18.4699 15.947 19.6548 13.5911 19.9352 11.1365L17.9886 10.4279C17.8738 12.5624 16.909 14.6459 15.1423 16.1284C11.7577 18.9684 6.71167 18.5269 3.87164 15.1423C1.03163 11.7577 1.4731 6.71166 4.8577 3.87164C8.24231 1.03162 13.2883 1.4731 16.1284 4.8577C16.9767 5.86872 17.5322 7.02798 17.804 8.2324L19.9522 9.01429C19.7622 7.07737 19.0059 5.17558 17.6604 3.57212C14.1104 -0.658624 7.80283 -1.21043 3.57212 2.33956C-0.658625 5.88958 -1.21046 12.1971 2.33955 16.4279Z" fill="currentColor"></path><path d="M3.57212 2.33956C1.65755 3.94607 0.496389 6.11731 0.12782 8.40523L2.04639 9.13961C2.26047 7.15832 3.21057 5.25375 4.8577 3.87164C8.24231 1.03162 13.2883 1.4731 16.1284 4.8577L13.8302 6.78606L19.9633 9.13364C19.7929 7.15555 19.0335 5.20847 17.6604 3.57212C14.1104 -0.658624 7.80283 -1.21043 3.57212 2.33956Z" fill="currentColor"></path><path d="M7 10H5C5 12.7614 7.23858 15 10 15C12.7614 15 15 12.7614 15 10H13C13 11.6569 11.6569 13 10 13C8.3431 13 7 11.6569 7 10Z" fill="currentColor"></path></svg></a></div>');function Fn(e,t){mt(t,!0);let r=re(t,"strings");const n="https://altcha.org";var a={get strings(){return r()},set strings(l){r(l),W()}},i=Ns(),s=ne(i);return z(s,"href",n),Z(i),ke(()=>z(s,"aria-label",r().ariaLinkLabel)),N(e,i),bt(a)}It(Fn,{strings:{}},[],[],{mode:"open"});var Ds=te('<div class="altcha-footer"><p></p> <!></div>');function Vn(e,t){mt(t,!0);let r=re(t,"logo"),n=re(t,"strings");var a={get logo(){return r()},set logo(c){r(c),W()},get strings(){return n()},set strings(c){n(c),W()}},i=Ds(),s=ne(i);co(s,()=>n().footer,!0),Z(s);var l=ee(s,2);{var u=c=>{Fn(c,{get strings(){return n()}})};ge(l,c=>{r()&&c(u)})}return Z(i),N(e,i),bt(a)}It(Vn,{logo:{},strings:{}},[],[],{mode:"open"});var js=te('<div class="altcha-switch"><input/>  <div class="altcha-switch-toggle"><div class="altcha-spinner altcha-switch-spinner"></div></div></div>');function xo(e,t){mt(t,!0);let r=re(t,"loading"),n=qr(t,["$$slots","$$events","$$legacy","$$host","loading"]),a;function i(){a?.click()}var s={get loading(){return r()},set loading(d){r(d),W()}},l=js(),u=ne(l);Wr(u,()=>({type:"checkbox",...n}),void 0,void 0,void 0,void 0,!0),Tt(u,d=>a=d,()=>a);var c=ee(u,2);return Z(l),ke(()=>z(l,"data-loading",r())),zr("click",c,i),N(e,l),bt(s)}Hr(["click"]),It(xo,{loading:{}},[],[],{mode:"open"});var xe=(e=>(e.ERROR="error",e.LOADING="loading",e.PLAYING="playing",e.PAUSED="paused",e.READY="ready",e))(xe||{}),B=(e=>(e.CODE="code",e.ERROR="error",e.VERIFIED="verified",e.VERIFYING="verifying",e.UNVERIFIED="unverified",e.EXPIRED="expired",e))(B||{}),Us=te('<div class="altcha-code-challenge-title"> </div>'),Fs=te('<div class="altcha-spinner"></div>'),Vs=In('<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12.8659 3.00017L22.3922 19.5002C22.6684 19.9785 22.5045 20.5901 22.0262 20.8662C21.8742 20.954 21.7017 21.0002 21.5262 21.0002H2.47363C1.92135 21.0002 1.47363 20.5525 1.47363 20.0002C1.47363 19.8246 1.51984 19.6522 1.60761 19.5002L11.1339 3.00017C11.41 2.52187 12.0216 2.358 12.4999 2.63414C12.6519 2.72191 12.7782 2.84815 12.8659 3.00017ZM10.9999 16.0002V18.0002H12.9999V16.0002H10.9999ZM10.9999 9.00017V14.0002H12.9999V9.00017H10.9999Z"></path></svg>'),Bs=In('<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M15 7C15 6.44772 15.4477 6 16 6C16.5523 6 17 6.44772 17 7V17C17 17.5523 16.5523 18 16 18C15.4477 18 15 17.5523 15 17V7ZM7 7C7 6.44772 7.44772 6 8 6C8.55228 6 9 6.44772 9 7V17C9 17.5523 8.55228 18 8 18C7.44772 18 7 17.5523 7 17V7Z"></path></svg>'),zs=In('<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M4 12H7C8.10457 12 9 12.8954 9 14V19C9 20.1046 8.10457 21 7 21H4C2.89543 21 2 20.1046 2 19V12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12V19C22 20.1046 21.1046 21 20 21H17C15.8954 21 15 20.1046 15 19V14C15 12.8954 15.8954 12 17 12H20C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12Z"></path></svg>'),Hs=te('<button type="button" class="altcha-button altcha-button-secondary"><!></button>'),Ks=te('<audio hidden="" autoplay=""></audio>'),Ys=te('<div class="altcha-code-challenge"><form data-code-challenge="true"><!> <div class="altcha-code-challenge-text"> </div> <img class="altcha-code-challenge-image" alt=""/> <div class="altcha-code-challenge-row"><input type="text" class="altcha-input" autocomplete="off" name="" required=""/> <!> <button type="button" class="altcha-button altcha-button-secondary"><svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2V4C16.4183 4 20 7.58172 20 12C20 16.4183 16.4183 20 12 20C7.58172 20 4 16.4183 4 12C4 9.25022 5.38734 6.82447 7.50024 5.38451L7.5 8H9.5V2L3.5 2V4L5.99918 3.99989C3.57075 5.82434 2 8.72873 2 12Z"></path></svg></button></div> <div class="altcha-code-challenge-buttons"><button type="submit" class="altcha-button"> </button> <button type="button" class="altcha-button altcha-button-secondary"> </button></div></form> <!></div>');function ko(e,t){mt(t,!0);let r=re(t,"audioUrl"),n=re(t,"codeChallenge"),a=re(t,"config"),i=re(t,"imageUrl"),s=re(t,"onCancel"),l=re(t,"onReload"),u=re(t,"onSubmit"),c=re(t,"strings"),d=O(void 0),v=O(void 0),h=O(void 0),m=O(!1),g=O(""),x=O(!1);Rn(()=>(a().disableAutoFocus||Ht().then(()=>{o(h)?.focus()}),()=>{o(v)&&(o(v).pause(),w(v,void 0))}));function T(){w(d,xe.PAUSED,!0)}function L(y){w(d,xe.ERROR,!0)}function me(){w(d,xe.READY,!0)}function fe(){w(d,xe.LOADING,!0)}function j(){w(d,xe.PLAYING,!0)}function Se(){w(d,xe.PAUSED,!0)}function U(y){y.code==="Space"?(y.preventDefault(),y.stopPropagation(),X()):y.code==="Escape"&&(y.preventDefault(),y.stopPropagation(),s()?.())}function E(y){y.preventDefault(),y.stopPropagation(),u()?.(o(g))}function X(){o(v)?o(d)===xe.LOADING||(o(v).paused?(r()&&o(v).src!==r()&&(o(v).src=r()),o(v).currentTime=0,o(v).play()):o(v).pause()):(w(x,!0),requestAnimationFrame(()=>{o(v)&&r()&&(o(v).src=r(),o(v).play())}))}var Ae={get audioUrl(){return r()},set audioUrl(y){r(y),W()},get codeChallenge(){return n()},set codeChallenge(y){n(y),W()},get config(){return a()},set config(y){a(y),W()},get imageUrl(){return i()},set imageUrl(y){i(y),W()},get onCancel(){return s()},set onCancel(y){s(y),W()},get onReload(){return l()},set onReload(y){l(y),W()},get onSubmit(){return u()},set onSubmit(y){u(y),W()},get strings(){return c()},set strings(y){c(y),W()}},$=Ys(),de=ne($),ft=ne(de);{var je=y=>{var ie=Us(),Gt=ne(ie,!0);Z(ie),ke(()=>ut(Gt,c().verificationRequired)),N(y,ie)};ge(ft,y=>{a().codeChallengeDisplay!=="standard"&&y(je)})}var Pe=ee(ft,2),ae=ne(Pe,!0);Z(Pe);var dt=ee(Pe,2),S=ee(dt,2),G=ne(S);Mn(G),G.disabled=o(m),Tt(G,y=>w(h,y),()=>o(h));var Ue=ee(G,2);{var b=y=>{var ie=Hs(),Gt=ne(ie);{var Yn=Oe=>{var ht=Fs();N(Oe,ht)},Er=Oe=>{var ht=Vs();N(Oe,ht)},Gn=Oe=>{var ht=Bs();N(Oe,ht)},Wn=Oe=>{var ht=zs();N(Oe,ht)};ge(Gt,Oe=>{o(d)===xe.LOADING?Oe(Yn):o(d)===xe.ERROR?Oe(Er,1):o(d)===xe.PLAYING?Oe(Gn,2):Oe(Wn,-1)})}Z(ie),ke(()=>{z(ie,"title",c().getAudioChallenge),ie.disabled=o(d)===xe.LOADING||o(d)===xe.ERROR,z(ie,"aria-label",o(d)===xe.LOADING?c().loading:c().getAudioChallenge)}),pe("click",ie,()=>X(),!0),N(y,ie)};ge(Ue,y=>{n().audio&&y(b)})}var Kt=ee(Ue,2);Z(S);var Zr=ee(S,2),Ye=ne(Zr),Kn=ne(Ye,!0);Z(Ye);var Yt=ee(Ye,2),xr=ne(Yt,!0);Z(Yt),Z(Zr),Z(de);var kr=ee(de,2);{var Sr=y=>{var ie=Ks();Tt(ie,Gt=>w(v,Gt),()=>o(v)),pe("error",ie,L),pe("loadstart",ie,fe),pe("canplay",ie,me),pe("pause",ie,Se),pe("playing",ie,j),pe("ended",ie,T),N(y,ie)};ge(kr,y=>{o(x)&&y(Sr)})}return Z($),ke(()=>{ut(ae,c().enterCodeFromImage),z(dt,"src",i()),z(G,"minlength",n().length||1),z(G,"maxlength",n().length),z(G,"placeholder",c().enterCode),z(G,"aria-label",o(d)===xe.LOADING?c().loading:o(d)===xe.PLAYING?"":c().enterCodeAria),z(G,"aria-live",o(d)?"assertive":"polite"),z(G,"aria-busy",o(d)===xe.LOADING),z(Kt,"title",c().reload),z(Kt,"aria-label",c().reload),z(Ye,"aria-label",c().verify),ut(Kn,c().verify),z(Yt,"aria-label",c().cancel),ut(xr,c().cancel)}),pe("submit",de,E,!0),zr("keydown",G,U),Is(G,()=>o(g),y=>w(g,y)),pe("click",Kt,()=>l()?.(),!0),pe("click",Yt,()=>s()?.(),!0),N(e,$),bt(Ae)}Hr(["keydown"]),It(ko,{audioUrl:{},codeChallenge:{},config:{},imageUrl:{},onCancel:{},onReload:{},onSubmit:{},strings:{}},[],[],{mode:"open"});var Gs=te('<div class="altcha-popover-backdrop" data-backdrop=""></div>'),Ws=te('<div class="altcha-popover-arrow"></div>'),qs=te('<div role="button" class="altcha-popover-close">&times;</div>'),Js=te('<!> <div><!> <!> <div class="altcha-popover-content"><!></div></div>',1);function Bn(e,t){mt(t,!0);let r=re(t,"anchor"),n=re(t,"children"),a=re(t,"display",7,"standard"),i=re(t,"backdrop",7,!1),s=re(t,"onClickOutside"),l=re(t,"onClickOutsideDelay",7,600),u=re(t,"onClose"),c=re(t,"placement",7,"auto"),d=re(t,"updateUISignal"),v=re(t,"variant",7,"neutral"),h=qr(t,["$$slots","$$events","$$legacy","$$host","anchor","children","display","backdrop","onClickOutside","onClickOutsideDelay","onClose","placement","updateUISignal","variant"]),m=O(void 0),g=O(void 0),x=O(!1),T=O(0);Re(()=>{c()!=="auto"&&w(x,c()==="top")}),Re(()=>{d()&&Se()}),Rn(()=>{const S=a()==="bottomsheet"||a()==="overlay";return S&&(o(g)&&document.body.append(o(g)),o(m)&&document.body.append(o(m))),Se(),Ht().then(()=>{w(T,Date.now(),!0)}),()=>{S&&(o(g)&&document.body.removeChild(o(g)),o(m)&&document.body.removeChild(o(m)))}});function L(){u()?.()}function me(S){const G=S.target;!o(m)?.contains(G)&&(!l()||o(T)+l()<Date.now())&&s()?.()}function fe(){Se()}function j(){Se()}function Se(){if(r()&&c()==="auto"&&o(m)){const S=r().getBoundingClientRect(),Ue=document.documentElement.clientHeight-(S.top+S.height)<o(m).clientHeight;o(x)!==Ue&&w(x,Ue)}}var U={get anchor(){return r()},set anchor(S){r(S),W()},get children(){return n()},set children(S){n(S),W()},get display(){return a()},set display(S="standard"){a(S),W()},get backdrop(){return i()},set backdrop(S=!1){i(S),W()},get onClickOutside(){return s()},set onClickOutside(S){s(S),W()},get onClickOutsideDelay(){return l()},set onClickOutsideDelay(S=600){l(S),W()},get onClose(){return u()},set onClose(S){u(S),W()},get placement(){return c()},set placement(S="auto"){c(S),W()},get updateUISignal(){return d()},set updateUISignal(S){d(S),W()},get variant(){return v()},set variant(S="neutral"){v(S),W()}},E=Js();pe("click",Ft,me,!0),pe("resize",Ft,fe),pe("scroll",Ft,j);var X=Zt(E);{var Ae=S=>{var G=Gs();Tt(G,Ue=>w(g,Ue),()=>o(g)),N(S,G)};ge(X,S=>{i()&&S(Ae)})}var $=ee(X,2);Wr($,()=>({...h,class:`altcha-popover ${(t.class||"")??""}`,"data-popover":!0,"data-variant":v(),"data-top":o(x),"data-display":a()}));var de=ne($);{var ft=S=>{var G=Ws();N(S,G)};ge(de,S=>{a()==="standard"&&S(ft)})}var je=ee(de,2);{var Pe=S=>{var G=qs();pe("click",G,L,!0),N(S,G)};ge(je,S=>{a()!=="standard"&&S(Pe)})}var ae=ee(je,2),dt=ne(ae);return cs(dt,()=>n()??rt),Z(ae),Z($),Tt($,S=>w(m,S),()=>o(m)),N(e,E),bt(U)}It(Bn,{anchor:{},children:{},display:{},backdrop:{},onClickOutside:{},onClickOutsideDelay:{},onClose:{},placement:{},updateUISignal:{},variant:{}},[],[],{mode:"open"});function Zs(e){return Array.from(new Uint8Array(e)).map(t=>t.toString(16).padStart(2,"0")).join("")}function Xs(e,t="altcha-css",r){if(typeof document<"u"&&document&&!document.getElementById(t)){const n=document.createElement("style");n.id=t,n.textContent=e;const a=document.currentScript?.nonce??document.querySelector('meta[name="csp-nonce"]')?.content;a&&(n.nonce=a),document.head.appendChild(n)}}async function So(e){const{challenge:t,concurrency:r=navigator.hardwareConcurrency,controller:n=new AbortController,createWorker:a,onOutOfMemory:i=h=>h>1?Math.floor(h/2):0,counterMode:s,timeout:l=9e4}=e,u=Math.min(16,Math.max(1,r)),c=[],d=()=>{for(const h of c)h.terminate()};for(let h=0;h<u;h++)c.push(await a(t.parameters.algorithm));let v=null;try{v=await Promise.race(c.map((h,m)=>(n.signal.addEventListener("abort",()=>{h.postMessage({type:"abort"})}),new Promise((g,x)=>{h.addEventListener("error",T=>{x(T)}),h.addEventListener("message",T=>{if(T.data){for(const L of c)L!==h&&L.postMessage({type:"abort"});if(T.data.error)return x(new Error(T.data.error))}g(T.data)}),h.postMessage({challenge:t,counterMode:s,counterStart:m,counterStep:u,timeout:l,type:"work"})}))))}catch(h){if(h instanceof Error&&!!h?.message?.includes("Out of memory")&&i){d();const g=i(u);if(g)return So({...e,challenge:t,controller:n,concurrency:g,createWorker:a})}throw h}finally{d()}return n.signal.aborted?null:v||null}class Qs{TAG_CODES={INPUT:1,TEXTAREA:2,SELECT:3,BUTTON:4,A:5,DETAILS:6,SUMMARY:7,IFRAME:8,VIDEO:9,AUDIO:10};maxSamples;sampleInterval;target;focusStartTime=0;focusInteraction=0;focusInteractionTimer=null;lastPointerSample=0;lastTouchSample=0;lastScrollSample=0;pendingPointer=null;pendingTouch=null;focus=[];pointer=[];scroll=[];touch=[];constructor(t={}){const{maxSamples:r=60,sampleInterval:n=50,target:a=window}=t;this.maxSamples=r,this.sampleInterval=n,this.target=a,this.attach()}destroy(){const t={capture:!0};this.target.removeEventListener("focusin",this.onFocus,t),this.target.removeEventListener("keydown",this.onInteraction,t),this.target.removeEventListener("pointerdown",this.onInteraction,t),this.target.removeEventListener("pointermove",this.onPointer,t),this.target.removeEventListener("scroll",this.onScroll,t),this.target.removeEventListener("touchmove",this.onTouchMove,t)}export(){return{focus:this.focus,maxTouchPoints:navigator.maxTouchPoints||0,pointer:this.pointer,scroll:this.scroll,time:Date.now(),touch:this.touch}}attach(){const t={passive:!0,capture:!0};this.target.addEventListener("focusin",this.onFocus,t),this.target.addEventListener("keydown",this.onInteraction,t),this.target.addEventListener("pointerdown",this.onInteraction,t),this.target.addEventListener("pointermove",this.onPointer,t),this.target.addEventListener("scroll",this.onScroll,t),this.target.addEventListener("touchmove",this.onTouchMove,t)}evict(t){t.length>this.maxSamples&&t.splice(0,t.length-this.maxSamples)}onFocus=t=>{if(this.focusInteraction===2)return;const r=t.target;if(!(r instanceof Element))return;const n=performance.now();this.focusStartTime===0&&(this.focusStartTime=n),this.focus.push([Math.round(n-this.focusStartTime),r.tabIndex,this.TAG_CODES[r.tagName]??0,this.focusInteraction?1:0]),this.evict(this.focus)};onInteraction=t=>{this.focusInteraction="keyCode"in t?1:2,this.focusInteractionTimer&&clearTimeout(this.focusInteractionTimer),this.focusInteractionTimer=setTimeout(()=>{this.focusInteraction=0},100)};onPointer=t=>{if(t.pointerType==="touch")return;const r=t.timeStamp||performance.now();this.pendingPointer=[Math.round(t.clientX),Math.round(t.clientY),Math.round(r)],r-this.lastPointerSample>=this.sampleInterval&&(this.pointer.push(this.pendingPointer),this.lastPointerSample=r,this.pendingPointer=null,this.evict(this.pointer))};onScroll=()=>{const t=performance.now();t-this.lastScrollSample<this.sampleInterval||(this.scroll.push([Math.round(window.scrollY),Math.round(t)]),this.lastScrollSample=t,this.evict(this.scroll))};onTouchMove=t=>{const r=t.timeStamp||performance.now(),n=t.touches[0];n&&(this.pendingTouch=[Math.round(n.clientX),Math.round(n.clientY),Math.round(r),Math.round(n.force*1e3)/1e3,Math.round(n.radiusX||0),Math.round(n.radiusY||0)],r-this.lastTouchSample>=this.sampleInterval&&(this.touch.push(this.pendingTouch),this.lastTouchSample=r,this.pendingTouch=null,this.evict(this.touch)))}}var el=te('<div class="altcha-overlay-backdrop" data-backdrop=""></div>'),tl=te('<div class="altcha-overlay-content"></div>'),rl=te('<div role="button" class="altcha-overlay-close">&times;</div> <!>',1),nl=te('<div class="altcha-floating-arrow"></div>'),al=te('<input type="hidden"/>'),ol=te('<div class="altcha-error">Secure context (HTTPS) required.</div>'),il=te('<div class="altcha-error"> </div>'),sl=te('<div class="altcha-error"> </div>'),ll=te("<!> <!>",1),cl=te('<!> <div class="altcha"><!> <div class="altcha-main"><div><div class="altcha-checkbox-wrap"><!> <label><!></label></div> <!></div> <!> <!> <!></div> <!></div>',1);function ul(e,t){mt(t,!0);const r=()=>ka(d,"$altchaDefaults",a),n=()=>ka(g,"$altchaI18nStore",a),[a,i]=Ci(),s='input[type="text"]:not([data-no-spamfilter]), textarea:not([data-no-spamfilter])',l='input[type="submit"], button[type="submit"], button:not([type="button"]):not([type="reset"])',u=["ar","fa","he","ur"],{isSecureContext:c}=globalThis,{store:d}=globalThis.$altcha.defaults,v=navigator.hardwareConcurrency||2,h=navigator.deviceMemory||0,m=h&&h<=4?Math.min(4,v):v,g=globalThis.$altcha.i18n.store,x=t.$$host,T=(f,p)=>{Ht().then(()=>{x?.dispatchEvent(new CustomEvent(f,{detail:p}))})};let L=null,me=O(wt(new URL(location.origin))),fe=O(!1),j=O(null),Se=O(null),U=O(null),E=O(wt(B.UNVERIFIED)),X=O(void 0),Ae=O(void 0),$=O(null),de=O(void 0),ft=O(null),je=O(null),Pe=O(null),ae=O(null),dt=O(wt([])),S=O(0),G=O(wt({})),Ue=O(!0);const b=Ce(()=>({fetch:(f,p)=>fetch(f,p),audioChallengeLanguage:"",auto:"off",barPlacement:"bottom",challenge:"",codeChallenge:null,codeChallengeDisplay:"standard",credentials:null,debug:!1,disableAutoFocus:!1,display:"standard",floatingAnchor:"",floatingOffset:8,floatingPersist:!1,floatingPlacement:"auto",hideFooter:!1,hideLogo:!1,humanInteractionSignature:!0,language:"",mockError:!1,minDuration:500,overlayContent:"",name:"altcha",popoverPlacement:"auto",retryOnOutOfMemoryError:!0,setCookie:null,serverVerificationFields:!1,serverVerificationTimeZone:!1,test:!1,timeout:9e4,type:"checkbox",validationMessage:"",verifyFunction:null,verifyUrl:"",workers:m,...r(),...o(G)})),Kt=Ce(()=>`altcha-checkbox-${t.id||Math.floor(Math.random()*1e12).toString(16)}`),Zr=Ce(()=>hl(o(b).type)),Ye=Ce(()=>o(b).auto),Kn=Ce(()=>o(E)===B.VERIFYING),Yt=Ce(()=>!o(b).hideFooter),xr=Ce(()=>!o(b).hideLogo&&o(b).display!=="bar"),kr=Ce(()=>vl(n(),[o(b).language,document.documentElement.lang,...navigator.languages])),Sr=Ce(()=>u.includes(o(kr).language)?"rtl":void 0),y=Ce(()=>({...o(kr).strings})),ie=Ce(()=>o(j)?.audio?.match(/^(https?:)?\//)?Xr(o(j).audio,o(me),{language:o(b).audioChallengeLanguage||o(kr).language}).toString():o(j)?.audio),Gt=Ce(()=>o(j)?.image?.match(/^(https?:)?\//)?Xr(o(j).image,o(me)):o(j)?.image);Re(()=>{Cr({auto:t.auto,challenge:t.challenge,display:t.display,language:t.language,name:t.name,type:t.type,workers:t.workers})}),Re(()=>{t.theme?x?.setAttribute("theme",t.theme):x?.removeAttribute("theme")}),Re(()=>{if(t.configuration)try{Cr(JSON.parse(t.configuration))}catch{q("unable to parse the `configuration` attribute (JSON expected)")}}),Re(()=>{o(U)!==o(b).display&&Qr(o(b).display)}),Re(()=>{o(fe)&&o(E)===B.VERIFYING&&w(fe,!1)}),Re(()=>{!o(fe)&&o(E)===B.VERIFIED&&w(fe,!0)}),Re(()=>{if(!o(fe)){const f=qn();f&&f.checked&&(f.checked=!1)}}),Re(()=>{o(E)===B.VERIFIED&&qn()?.setCustomValidity("")}),Re(()=>{if(o(Ye)==="onload"){const f=setTimeout(()=>{rr()},1);return()=>{f&&clearTimeout(f)}}}),Re(()=>{o(je)&&q("error:",o(je))}),Re(()=>{o(ae)&&o(b).setCookie&&Tl(o(ae),o(b).setCookie)}),Rn(()=>(q("mounted","3.2.2"),x&&globalThis.$altcha.instances.add(x),w($,o(de)?.closest("form"),!0),o($)?.addEventListener("reset",Ro),o($)?.addEventListener("submit",Po,{capture:!0}),o($)?.addEventListener("focusin",$o),Yn(),o(b).humanInteractionSignature&&(q("human interaction signature enabled"),L=new Qs),T("load"),c||q("secure context (HTTPS) required"),()=>{Gn(),x&&globalThis.$altcha.instances.delete(x),o(Pe)&&clearTimeout(o(Pe)),o($)?.removeEventListener("reset",Ro),o($)?.removeEventListener("submit",Po,{capture:!0}),o($)?.removeEventListener("focusin",$o),L?.destroy()}));function Yn(){w(dt,[...globalThis.$altcha.plugins].map(f=>new f(x)),!0),q("activating plugins",o(dt).map(f=>f.constructor.name));for(const f of o(dt))f.activate()}async function Er(f,...p){let _;for(const k of o(dt))_=await k[f].call(k,...p);return _}function Gn(){for(const f of o(dt))f.destroy()}function Wn(f){const[p,_]=f.salt.split("?"),k={};if(_)try{Object.assign(k,Object.fromEntries(new URLSearchParams(_).entries()))}catch{}const A={codeChallenge:f.codeChallenge,parameters:{algorithm:f.algorithm,cost:1,data:k,expiresAt:k?.expires?parseInt(k.expires,10):void 0,keyLength:f.algorithm==="SHA-512"?64:f.algorithm==="SHA-384"?48:32,nonce:Zs(new TextEncoder().encode(f.salt)),keyPrefix:f.challenge,salt:""},signature:f.signature};return Object.defineProperties(A,{_originalSalt:{enumerable:!1,value:f.salt,writable:!1},_version:{enumerable:!1,value:1,writable:!1}}),A}function Oe(f,p){return{algorithm:f.parameters.algorithm,challenge:f.parameters.keyPrefix,number:p.counter,salt:"_originalSalt"in f?f._originalSalt:f.parameters.nonce,signature:f.signature,took:p.time||0}}async function ht(f){await new Promise(p=>setTimeout(p,f))}async function Io(f=o(b).challenge,p){const _=await Er("onFetchChallenge",f);let k=null;if(_!==void 0)return _;if(typeof f=="string")if(f.startsWith("{")){q("parsing JSON challenge");try{k=JSON.parse(f)}catch{throw new Error("Unable to parse JSON challenge.")}}else{q("fetching challenge from",p?.method||"GET",f),w(me,new URL(f,location.origin),!0);const A=await o(b).fetch(f,{credentials:o(b).credentials||void 0,...p});await Lo(A);const C=A.headers.get("x-altcha-config");C&&El(C);const H=await A.json();if(H&&"his"in H&&H.his){if(q("requested HIS"),!L)throw new Error("Server requested HIS data but collector is disabled.");return Io(Xr(H.his.url,o(me)),{body:JSON.stringify({his:L.export()}),headers:{"content-type":"application/json"},method:"POST"})}H&&"hisResult"in H&&H.hisResult&&q("HIS result",H.hisResult),k=H}else if(f&&typeof f=="object")try{k=JSON.parse(JSON.stringify(f))}catch{throw new Error("Unable to parse JSON challenge.")}if(fl(k)&&(k=Wn(k)),!dl(k))throw new Error("Challenge validation failed.");return k}function fl(f){return typeof f=="object"&&"challenge"in f}function dl(f){return!!f&&typeof f=="object"&&"parameters"in f&&!!f.parameters&&typeof f.parameters=="object"&&"algorithm"in f.parameters&&"nonce"in f.parameters&&"salt"in f.parameters&&"keyPrefix"in f.parameters}function qn(){return document.getElementById(o(Kt))}function hl(f){switch(f){case"checkbox":return wo;case"switch":return xo;default:return _o}}function vl(f,p){const _=Object.keys(f).map(A=>A.toLowerCase());let k=p.reduce((A,C)=>(C=C.toLowerCase(),A||(f[C]?C:null)||_.find(H=>C.split("-")[0]===H.split("-")[0])||null),null);return f[k||""]||(k="en"),{language:k,strings:f[k]}}function pl(f){switch(f){case"bar":return o(b).barPlacement||"bottom";case"floating":return o(b).floatingPlacement||"auto";default:return}}function gl(f){return[...o($)?.querySelectorAll(s)||[]].reduce((_,k)=>{const A=k.name,C=k.value;return A&&C&&(_[A]=/\n/.test(C)?C.replace(new RegExp("(?<!\\r)\\n","g"),`\r
`):C),_},{})}function ml(){try{return Intl.DateTimeFormat().resolvedOptions().timeZone}catch{}}function Xr(f,p,_){const k=new URL(f,p);if(k.search||(k.search=p.search),_)for(const A in _)_[A]!==void 0&&_[A]!==null&&k.searchParams.set(A,_[A]);return k.toString()}function bl(f){!o(fe)&&f.currentTarget.checked?(f.preventDefault(),f.currentTarget.checked=!1,o(E)!==B.VERIFYING&&rr()):f.currentTarget.checked||(f.preventDefault(),Ge())}function yl(f){o(E)===B.VERIFYING?f.currentTarget.setCustomValidity(o(y).waitAlert):o(b).validationMessage&&f.currentTarget.setCustomValidity(o(b).validationMessage)}function wl(){Qr(o(b).display),Ge()}function _l(){en()}function xl(f){const p=f.target;o(b).display==="floating"&&p&&!x?.contains(p)&&!p.hasAttribute("data-backdrop")&&!p.closest("[data-popover]")&&o(E)!==B.VERIFIED&&!o(b).floatingPersist&&Jn()}function $o(f){o(Ye)==="onfocus"&&o(E)===B.UNVERIFIED&&rr()}function Ro(){Qr(o(b).display),Ge()}function Po(f){f.target?.getAttribute("data-code-challenge")!=="true"&&o(Ye)==="onsubmit"&&o(E)===B.UNVERIFIED&&(f.preventDefault(),f.stopPropagation(),w(ft,f.submitter,!0),Zn(),rr().then(_=>{_&&!o(j)&&Ht().then(()=>{Oo(o(ft))})}))}function kl(f){f.persisted&&(Qr(o(b).display),Ge())}function Sl(){en()}function El(f){try{const p=JSON.parse(f);p&&typeof p=="object"&&Cr({serverVerificationFields:p?.sentinel?.fields,serverVerificationTimeZone:p?.sentinel?.timeZone,verifyUrl:p.verifyurl,...p})}catch(p){q("unable to configure from x-altcha-config header",p)}}function Cl(f=20){if(!o(de))return;const p=o(b).floatingPlacement;if(!o(Ae)&&(w(Ae,(o(b).floatingAnchor instanceof HTMLElement?o(b).floatingAnchor:o(b).floatingAnchor?document.querySelector(o(b).floatingAnchor):o($)?.querySelector(l))||o($),!0),!o(Ae))){q("unable to find floating anchor element");return}const _=parseInt(o(b).floatingOffset,10)||12,k=o(Ae).getBoundingClientRect(),A=o(de).getBoundingClientRect(),C=document.documentElement.clientHeight,H=document.documentElement.clientWidth,Fe=!p||p==="auto"?k.bottom+A.height+_+f>C:p==="top",Q=Math.max(f,Math.min(H-f-A.width,k.left+k.width/2-A.width/2));if(o(de).style.setProperty("--altcha-floating-left",`${Q}px`),o(de).style.setProperty("--altcha-floating-top",Fe?`${k.top-(A.height+_)}px`:`${k.bottom+_}px`),o(de).setAttribute("data-floating-position",Fe?"top":"bottom"),o(X)){const he=o(X).getBoundingClientRect();o(X).style.left=k.left-Q+k.width/2-he.width/2+"px"}}async function Al(f,p){const _=await Er("onRequestServerVerification",f,p);if(_!==void 0)return _;if(q("requesting server verification from",o(b).verifyUrl),!o(b).verifyUrl)throw new Error("Parameter verifyUrl must be set for server verification.");const k=await o(b).fetch(Xr(o(b).verifyUrl,o(me)),{body:JSON.stringify({code:p,fields:o(b).serverVerificationFields?gl():void 0,payload:f,timeZone:o(b).serverVerificationTimeZone?ml():void 0}),credentials:o(b).credentials||void 0,headers:{"Content-Type":"application/json"},method:"POST"});await Lo(k);const A=await k.json();return A&&typeof A=="object"&&"payload"in A&&A.payload&&T("serververification",A),A}function Oo(f){o($)&&"requestSubmit"in o($)?o($).requestSubmit(f):o($)?.reportValidity()&&(f?f.click():o($).submit())}function Tl(f,p={}){const{domain:_,name:k=o(b).name,maxAge:A,path:C,sameSite:H,secure:Fe}=p;let Q=`${encodeURIComponent(k)}=${encodeURIComponent(f)}`;_&&(Q+=`; Domain=${_}`),A!=null&&(Q+=`; Max-Age=${A}`),C&&(Q+=`; Path=${C}`),H&&(Q+=`; SameSite=${H}`),Fe&&(Q+="; Secure"),document.cookie=Q}function Qr(f){switch(f){case"bar":case"floating":case"overlay":Jn(),(!o(Ye)||o(Ye)==="off")&&(o(G).auto="onsubmit");break;case"standard":Zn()}o(U)!==f&&w(U,f,!0)}function Il(f){o(Pe)&&clearTimeout(o(Pe));const p=()=>{o(E)!==B.UNVERIFIED?(w(fe,!1),We(B.EXPIRED)):Ge(),T("expired")},_=f*1e3-Date.now();_>=1?w(Pe,setTimeout(p,_),!0):p()}async function Lo(f){if(f.status>=400){if(f.headers.get("content-type")?.includes("/json")){let _;try{_=await f.json()}catch{}if(_&&"error"in _)throw new Error(`Server responded with ${f.status} - ${_.error}`)}throw new Error(`Server responded with ${f.status}.`)}const p=f.headers.get("content-type");if(!p||!p.includes("/json"))throw new Error(`Server responded with invalid content-type. Expected application/json, received ${p}.`)}async function Mo(f){if(!o(ae)){We(B.ERROR,"Cannot verify code challenge without PoW payload.");return}We(B.VERIFYING);let p=null;if(o(b).verifyUrl)p=await Al(o(ae),f);else if(o(b).verifyFunction)p=await o(b).verifyFunction(o(ae),f);else{We(B.ERROR,"Parameter verifyUrl is required for code challenge verification.");return}p?.payload&&(w(ae,p.payload,!0),q("server payload",o(ae))),p?.verified===!0?(q("verified"),We(B.VERIFIED),T("verified",{payload:o(ae)}),o(Ye)==="onsubmit"&&Ht().then(()=>{Oo(o(ft))})):We(B.ERROR,p?.reason||"Verification failed."),o(b).disableAutoFocus||qn()?.focus()}function Cr(f){Object.assign(o(G),{...Object.fromEntries(Object.entries(f).filter(([p,_])=>_!==void 0))})}function $l(){return{...o(b)}}function Rl(){return o(E)}function Jn(){w(Ue,!1)}function q(...f){(o(b).debug||f.some(p=>p instanceof Error))&&console[f[0]instanceof Error?"error":"log"]("ALTCHA",`[name=${o(b).name}]`,...f)}function Ge(f=B.UNVERIFIED,p=null){w(fe,!1),w(je,p,!0),w(ae,null),o(Se)&&o(Se).abort(),o(Pe)&&(clearTimeout(o(Pe)),w(Pe,null)),We(f)}function We(f,p=null){w(E,f,!0),w(je,p,!0),T("statechange",{payload:o(ae),state:o(E)})}function Zn(){w(Ue,!0),Ht().then(()=>{en()})}function en(){if(o(b).display==="floating")return Cl();w(S,o(S)+1)}async function rr(f={}){const{concurrency:p=Math.max(1,o(b).workers),controller:_=new AbortController,minDuration:k=o(b).minDuration}=f,A=performance.now();let C=null,H=null,Fe=!1;const Q=await Er("onVerify",f);if(Q!==void 0)return Q;Ge(B.VERIFYING),w(Se,_,!0);try{if(!c)throw new Error("Secure context (HTTPS) required.");if(o(b).mockError)throw new Error("Mock error.");if(o(b).test)return q("running test mode with null challenge"),await ht(Math.max(0,k-(performance.now()-A))),o(Se)?.signal.aborted?(Ge(),null):(w(ae,btoa(JSON.stringify({challenge:null,solution:null,test:!0})),!0),q("verified"),We(B.VERIFIED),T("verified",{payload:o(ae)}),{payload:o(ae)});if(C=await Io(),!C)throw new Error("Failed to fetch challenge.");q("challenge",C),"configuration"in C&&(q("re-configuring from challenge",C.configuration),Cr(C.configuration)),C.parameters.expiresAt&&Il(C.parameters.expiresAt),Fe="_version"in C&&C._version===1;const he=globalThis.$altcha.algorithms.get(C.parameters.algorithm);if(!he)throw new Error(`Unsupported algorithm ${C.parameters.algorithm}.`);if(H=await So({challenge:C,concurrency:p,controller:_,createWorker:he,counterMode:Fe?"string":"uint32",onOutOfMemory:$t=>{if(q("out of memory error received"),T("outofmemory"),o(b).retryOnOutOfMemoryError&&$t>1){const Rt=Math.floor($t/2);return q(`retrying with ${Rt} workers...`),Rt}},timeout:o(b).timeout}),o(Se)?.signal.aborted)return Ge(),null;if(!H)throw new Error("Failed to find solution.");q("solution",H),await ht(Math.max(0,k-(performance.now()-A))),w(j,C.codeChallenge||o(b).codeChallenge||null,!0),Fe?w(ae,btoa(JSON.stringify(Oe(C,H))),!0):w(ae,btoa(JSON.stringify({challenge:{parameters:C.parameters,signature:C.signature},solution:H})),!0),o(j)?(q("requesting code verification"),We(B.CODE),T("codechallenge",{codeChallenge:o(j)})):o(b).verifyUrl?await Mo():(q("verified"),We(B.VERIFIED),T("verified",{payload:o(ae)}))}catch(he){return q("verification failed",he),We(B.ERROR,String(he)),null}finally{w(Se,null)}return{challenge:C,payload:o(ae),solution:H}}var Pl={configure:Cr,getConfiguration:$l,getState:Rl,hide:Jn,log:q,reset:Ge,setState:We,show:Zn,updateUI:en,verify:rr},No=cl();pe("scroll",fn,_l),pe("click",fn,xl),pe("pageshow",Ft,kl),pe("resize",Ft,Sl);var Do=Zt(No);{var Ol=f=>{var p=el();N(f,p)};ge(Do,f=>{o(b).display==="overlay"&&o(Ue)&&f(Ol)})}var vt=ee(Do,2),jo=ne(vt);{var Ll=f=>{var p=rl(),_=Zt(p),k=ee(_,2);{var A=C=>{var H=tl();co(H,()=>document.querySelector(o(b).overlayContent)?.innerHTML,!0),Z(H),N(C,H)};ge(k,C=>{o(b).overlayContent&&C(A)})}pe("click",_,wl,!0),N(f,p)};ge(jo,f=>{o(b).display==="overlay"&&o(Ue)&&f(Ll)})}var Xn=ee(jo,2),Qn=ne(Xn),ea=ne(Qn),Uo=ne(ea);{let f=Ce(()=>o(b).display==="standard"&&o(Ye)!=="onsubmit"||o(E)===B.VERIFYING);ds(Uo,()=>o(Zr),(p,_)=>{_(p,{get id(){return o(Kt)},name:"",get required(){return o(f)},get loading(){return o(Kn)},get checked(){return o(fe)},onchange:bl,oninvalid:yl})})}var ta=ee(Uo,2),Ml=ne(ta);{var Nl=f=>{var p=Kr();ke(()=>ut(p,o(y).verificationRequired)),N(f,p)},Dl=f=>{var p=Kr();ke(()=>ut(p,o(y).verifying)),N(f,p)},jl=f=>{var p=Kr();ke(()=>ut(p,o(y).verified)),N(f,p)},Ul=f=>{var p=Kr();ke(()=>ut(p,o(y).label)),N(f,p)};ge(Ml,f=>{o(E)===B.CODE&&o(j)?f(Nl):o(E)===B.VERIFYING?f(Dl,1):o(E)===B.VERIFIED?f(jl,2):f(Ul,-1)})}Z(ta),Z(ea);var Fl=ee(ea,2);{var Vl=f=>{Fn(f,{get strings(){return o(y)}})};ge(Fl,f=>{o(xr)&&f(Vl)})}Z(Qn);var Fo=ee(Qn,2);{var Bl=f=>{{let p=Ce(()=>o(b).display==="bar"&&o(xr));Vn(f,{get logo(){return o(p)},get strings(){return o(y)}})}};ge(Fo,f=>{o(Yt)&&f(Bl)})}var Vo=ee(Fo,2);{var zl=f=>{var p=nl();Tt(p,_=>w(X,_),()=>o(X)),N(f,p)};ge(Vo,f=>{o(b).display==="floating"&&f(zl)})}var Hl=ee(Vo,2);{var Kl=f=>{var p=al();Mn(p),ke(()=>{z(p,"name",o(b).name),Cs(p,o(ae))}),N(f,p)};ge(Hl,f=>{o(b).setCookie||f(Kl)})}Z(Xn);var Yl=ee(Xn,2);{var Gl=f=>{Bn(f,{get anchor(){return o(de)},onClickOutside:()=>{c&&Ge()},get placement(){return o(b).popoverPlacement},role:"alert",variant:"error",get dir(){return o(Sr)},get updateUISignal(){return o(S)},children:(p,_)=>{var k=io(),A=Zt(k);{var C=Q=>{var he=ol();N(Q,he)},H=Q=>{var he=il(),$t=ne(he,!0);Z(he),ke(()=>ut($t,o(y).expired)),N(Q,he)},Fe=Q=>{var he=sl(),$t=ne(he,!0);Z(he),ke(()=>{z(he,"title",o(je)),ut($t,o(y).error)}),N(Q,he)};ge(A,Q=>{!o(je)&&!c?Q(C):!o(je)&&o(E)===B.EXPIRED?Q(H,1):Q(Fe,-1)})}N(p,k)},$$slots:{default:!0}})},Wl=f=>{var p=io(),_=Zt(p);fs(_,()=>o(j),k=>{{let A=Ce(()=>o(b).codeChallengeDisplay!=="standard");Bn(k,{get anchor(){return o(de)},get backdrop(){return o(A)},get display(){return o(b).codeChallengeDisplay},onClose:()=>{Ge()},get placement(){return o(b).popoverPlacement},role:"dialog",get"aria-label"(){return o(y).verificationRequired},get dir(){return o(Sr)},get updateUISignal(){return o(S)},children:(C,H)=>{var Fe=ll(),Q=Zt(Fe);ko(Q,{get audioUrl(){return o(ie)},get imageUrl(){return o(Gt)},onCancel:()=>Ge(),onReload:()=>rr(),onSubmit:Rt=>Mo(Rt),get codeChallenge(){return o(j)},get config(){return o(b)},get strings(){return o(y)}});var he=ee(Q,2);{var $t=Rt=>{Vn(Rt,{get logo(){return o(xr)},get strings(){return o(y)}})};ge(he,Rt=>{o(Yt)&&o(b).codeChallengeDisplay!=="standard"&&Rt($t)})}N(C,Fe)},$$slots:{default:!0}})}}),N(f,p)};ge(Yl,f=>{o(je)||o(E)===B.EXPIRED||!c?f(Gl):o(j)&&o(E)===B.CODE&&f(Wl,1)})}Z(vt),Tt(vt,f=>w(de,f),()=>o(de)),ke(f=>{z(vt,"data-state",o(E)),z(vt,"data-display",o(b).display||void 0),z(vt,"data-placement",f),z(vt,"data-visible",o(Ue)||void 0),z(vt,"dir",o(Sr)),z(ta,"for",o(Kt)),vt.dir=vt.dir},[()=>pl(o(b).display)]),N(e,No);var ql=bt(Pl);return i(),ql}typeof window<"u"&&window.customElements&&!customElements.get("altcha-widget")&&customElements.define("altcha-widget",It(ul,{auto:{type:"String"},challenge:{type:"String"},configuration:{type:"String"},display:{type:"String"},language:{type:"String"},name:{type:"String"},theme:{type:"String"},type:{type:"String"},workers:{type:"Number"}},[],["configure","getConfiguration","getState","hide","log","reset","setState","show","updateUI","verify"]));const Eo=`(function() {
  "use strict";
  function bufferStartsWith(buffer, prefix) {
    if (prefix.length > buffer.length) {
      return false;
    }
    for (let i = 0; i < prefix.length; i++) {
      if (buffer[i] !== prefix[i]) {
        return false;
      }
    }
    return true;
  }
  function bufferToHex(buffer) {
    return Array.from(new Uint8Array(buffer)).map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  function concatBuffers(a, b) {
    const out = new Uint8Array(a.length + b.length);
    out.set(a, 0);
    out.set(b, a.length);
    return out;
  }
  function hexToBuffer(hex) {
    if (hex.length % 2 !== 0) {
      throw new Error(\`Hex string must have an even length. Got: \${hex}\`);
    }
    const buffer = new ArrayBuffer(hex.length / 2);
    const view = new DataView(buffer);
    for (let i = 0; i < hex.length; i += 2) {
      const byteString = hex.substring(i, i + 2);
      const byteValue = parseInt(byteString, 16);
      view.setUint8(i / 2, byteValue);
    }
    return new Uint8Array(buffer);
  }
  async function delay(ms) {
    await new Promise((resolve) => setTimeout(resolve, ms));
  }
  function timeDuration(start) {
    return Math.floor((performance.now() - start) * 10) / 10;
  }
  class PasswordBuffer {
    constructor(nonce, mode = "uint32") {
      this.nonce = nonce;
      this.mode = mode;
      this.buffer = new Uint8Array(this.nonce.length + this.COUNTER_BYTES);
      this.buffer.set(this.nonce, 0);
      this.dataView = new DataView(this.buffer.buffer);
    }
    nonce;
    mode;
    COUNTER_BYTES = 4;
    buffer;
    dataView;
    encoder = new TextEncoder();
    /**
     * Appends the counter to the nonce buffer.
     * In 'string' mode, encodes the counter as a UTF-8 string.
     * In 'uint32' mode, writes the counter as a big-endian 32-bit integer.
     */
    setCounter(n) {
      if (this.mode === "string") {
        return concatBuffers(this.nonce, this.encoder.encode(n.toString()));
      }
      this.dataView.setUint32(this.nonce.length, n, false);
      return this.buffer;
    }
  }
  async function solveChallenge(options) {
    const {
      challenge,
      controller,
      counterMode = "uint32",
      counterStart = 0,
      counterStep = 1,
      deriveKey: deriveKey2,
      timeout = 9e4
    } = options;
    const { nonce, keyPrefix, salt } = challenge.parameters;
    const nonceBuf = hexToBuffer(nonce);
    const saltBuf = hexToBuffer(salt);
    const keyPrefixBuf = keyPrefix.length % 2 === 0 ? hexToBuffer(keyPrefix) : null;
    const password = new PasswordBuffer(nonceBuf, counterMode);
    const start = performance.now();
    let counter = counterStart;
    let iterations = 0;
    let derivedKeyHex = "";
    let lastYield = start;
    while (true) {
      if (controller?.signal.aborted || timeout && iterations % 10 === 0 && performance.now() - start > timeout) {
        return null;
      }
      const { derivedKey } = await deriveKey2(
        challenge.parameters,
        saltBuf,
        password.setCounter(counter)
      );
      if (iterations % 10 === 0 && performance.now() - lastYield > 200) {
        await delay(0);
        lastYield = performance.now();
      }
      if (keyPrefixBuf ? bufferStartsWith(derivedKey, keyPrefixBuf) : bufferToHex(derivedKey).startsWith(keyPrefix)) {
        derivedKeyHex = bufferToHex(derivedKey);
        break;
      }
      counter = counter + counterStep;
      iterations = iterations + 1;
    }
    return {
      counter,
      derivedKey: derivedKeyHex,
      time: timeDuration(start)
    };
  }
  function handler(options) {
    const { deriveKey: deriveKey2 } = options;
    let controller = void 0;
    self.onmessage = async (message) => {
      const { challenge, counterMode, counterStart, counterStep, timeout, type } = message.data;
      if (type === "abort") {
        controller?.abort();
      } else if (type === "work") {
        controller = new AbortController();
        let solution;
        try {
          solution = await solveChallenge({
            challenge,
            controller,
            counterStart,
            counterStep,
            deriveKey: deriveKey2,
            counterMode,
            timeout
          });
        } catch (err) {
          return self.postMessage({ error: err });
        }
        self.postMessage(solution);
      }
    };
  }
  function getDigest(algorithm) {
    switch (algorithm) {
      case "PBKDF2/SHA-512":
        return "SHA-512";
      case "PBKDF2/SHA-384":
        return "SHA-384";
      case "PBKDF2/SHA-256":
      default:
        return "SHA-256";
    }
  }
  async function deriveKey(parameters, salt, password) {
    const { algorithm, cost, keyLength = 32 } = parameters;
    const passwordKey = await crypto.subtle.importKey(
      "raw",
      password,
      { name: "PBKDF2" },
      false,
      ["deriveKey"]
    );
    const derivedKey = await crypto.subtle.deriveKey(
      {
        name: "PBKDF2",
        salt,
        iterations: cost,
        hash: getDigest(algorithm)
      },
      passwordKey,
      { name: "AES-GCM", length: keyLength * 8 },
      true,
      ["encrypt"]
    );
    return {
      derivedKey: new Uint8Array(await crypto.subtle.exportKey("raw", derivedKey))
    };
  }
  handler({
    deriveKey
  });
})();
`,Co=typeof self<"u"&&self.Blob&&new Blob(["(self.URL || self.webkitURL).revokeObjectURL(self.location.href);",Eo],{type:"text/javascript;charset=utf-8"});function zn(e){let t;try{if(t=Co&&(self.URL||self.webkitURL).createObjectURL(Co),!t)throw"";const r=new Worker(t,{name:e?.name});return r.addEventListener("error",()=>{(self.URL||self.webkitURL).revokeObjectURL(t)}),r}catch{return new Worker("data:text/javascript;charset=utf-8,"+encodeURIComponent(Eo),{name:e?.name})}}const Ao=`(function() {
  "use strict";
  function bufferStartsWith(buffer, prefix) {
    if (prefix.length > buffer.length) {
      return false;
    }
    for (let i = 0; i < prefix.length; i++) {
      if (buffer[i] !== prefix[i]) {
        return false;
      }
    }
    return true;
  }
  function bufferToHex(buffer) {
    return Array.from(new Uint8Array(buffer)).map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  function concatBuffers(a, b) {
    const out = new Uint8Array(a.length + b.length);
    out.set(a, 0);
    out.set(b, a.length);
    return out;
  }
  function hexToBuffer(hex) {
    if (hex.length % 2 !== 0) {
      throw new Error(\`Hex string must have an even length. Got: \${hex}\`);
    }
    const buffer = new ArrayBuffer(hex.length / 2);
    const view = new DataView(buffer);
    for (let i = 0; i < hex.length; i += 2) {
      const byteString = hex.substring(i, i + 2);
      const byteValue = parseInt(byteString, 16);
      view.setUint8(i / 2, byteValue);
    }
    return new Uint8Array(buffer);
  }
  async function delay(ms) {
    await new Promise((resolve) => setTimeout(resolve, ms));
  }
  function timeDuration(start) {
    return Math.floor((performance.now() - start) * 10) / 10;
  }
  class PasswordBuffer {
    constructor(nonce, mode = "uint32") {
      this.nonce = nonce;
      this.mode = mode;
      this.buffer = new Uint8Array(this.nonce.length + this.COUNTER_BYTES);
      this.buffer.set(this.nonce, 0);
      this.dataView = new DataView(this.buffer.buffer);
    }
    nonce;
    mode;
    COUNTER_BYTES = 4;
    buffer;
    dataView;
    encoder = new TextEncoder();
    /**
     * Appends the counter to the nonce buffer.
     * In 'string' mode, encodes the counter as a UTF-8 string.
     * In 'uint32' mode, writes the counter as a big-endian 32-bit integer.
     */
    setCounter(n) {
      if (this.mode === "string") {
        return concatBuffers(this.nonce, this.encoder.encode(n.toString()));
      }
      this.dataView.setUint32(this.nonce.length, n, false);
      return this.buffer;
    }
  }
  async function solveChallenge(options) {
    const {
      challenge,
      controller,
      counterMode = "uint32",
      counterStart = 0,
      counterStep = 1,
      deriveKey: deriveKey2,
      timeout = 9e4
    } = options;
    const { nonce, keyPrefix, salt } = challenge.parameters;
    const nonceBuf = hexToBuffer(nonce);
    const saltBuf = hexToBuffer(salt);
    const keyPrefixBuf = keyPrefix.length % 2 === 0 ? hexToBuffer(keyPrefix) : null;
    const password = new PasswordBuffer(nonceBuf, counterMode);
    const start = performance.now();
    let counter = counterStart;
    let iterations = 0;
    let derivedKeyHex = "";
    let lastYield = start;
    while (true) {
      if (controller?.signal.aborted || timeout && iterations % 10 === 0 && performance.now() - start > timeout) {
        return null;
      }
      const { derivedKey } = await deriveKey2(
        challenge.parameters,
        saltBuf,
        password.setCounter(counter)
      );
      if (iterations % 10 === 0 && performance.now() - lastYield > 200) {
        await delay(0);
        lastYield = performance.now();
      }
      if (keyPrefixBuf ? bufferStartsWith(derivedKey, keyPrefixBuf) : bufferToHex(derivedKey).startsWith(keyPrefix)) {
        derivedKeyHex = bufferToHex(derivedKey);
        break;
      }
      counter = counter + counterStep;
      iterations = iterations + 1;
    }
    return {
      counter,
      derivedKey: derivedKeyHex,
      time: timeDuration(start)
    };
  }
  function handler(options) {
    const { deriveKey: deriveKey2 } = options;
    let controller = void 0;
    self.onmessage = async (message) => {
      const { challenge, counterMode, counterStart, counterStep, timeout, type } = message.data;
      if (type === "abort") {
        controller?.abort();
      } else if (type === "work") {
        controller = new AbortController();
        let solution;
        try {
          solution = await solveChallenge({
            challenge,
            controller,
            counterStart,
            counterStep,
            deriveKey: deriveKey2,
            counterMode,
            timeout
          });
        } catch (err) {
          return self.postMessage({ error: err });
        }
        self.postMessage(solution);
      }
    };
  }
  async function deriveKey(parameters, salt, password) {
    const { algorithm, keyLength = 32 } = parameters;
    const iterations = Math.max(1, parameters.cost);
    let data = void 0;
    let derivedKey = void 0;
    for (let i = 0; i < iterations; i++) {
      if (i === 0) {
        data = concatBuffers(salt, password);
      } else {
        data = derivedKey;
      }
      derivedKey = new Uint8Array(
        (await crypto.subtle.digest(algorithm, data)).slice(0, keyLength)
      );
    }
    return {
      parameters: {},
      derivedKey
    };
  }
  handler({
    deriveKey
  });
})();
`,To=typeof self<"u"&&self.Blob&&new Blob(["(self.URL || self.webkitURL).revokeObjectURL(self.location.href);",Ao],{type:"text/javascript;charset=utf-8"});function Hn(e){let t;try{if(t=To&&(self.URL||self.webkitURL).createObjectURL(To),!t)throw"";const r=new Worker(t,{name:e?.name});return r.addEventListener("error",()=>{(self.URL||self.webkitURL).revokeObjectURL(t)}),r}catch{return new Worker("data:text/javascript;charset=utf-8,"+encodeURIComponent(Ao),{name:e?.name})}}return Xs(`:root {
  --altcha-border-color: var(--altcha-color-neutral);
  --altcha-border-width: 1px;
  --altcha-border-radius: 6px;
  --altcha-color-base: light-dark(oklch(100% 0.00011 271.152), oklch(20.904% 0.00002 271.152));
  --altcha-color-base-content: light-dark(
  	oklch(20.904% 0.00002 271.152),
  	oklch(100% 0.00011 271.152)
  );
  --altcha-color-error: oklch(51.284% 0.20527 28.678);
  --altcha-color-error-content: oklch(100% 0.00011 271.152);
  --altcha-color-neutral: light-dark(oklch(83.591% 0.0001 271.152), oklch(46.04% 0.00005 271.152));
  --altcha-color-neutral-content: light-dark(
  	oklch(46.76% 0.00005 271.152),
  	oklch(100% 0.00011 271.152)
  );
  --altcha-color-primary: oklch(40.279% 0.2449 268.131);
  --altcha-color-primary-content: oklch(100% 0.00011 271.152);
  --altcha-color-success: oklch(55.748% 0.18968 142.511);
  --altcha-color-success-content: oklch(100% 0.00011 271.152);
  --altcha-checkbox-border-color: light-dark(
  	oklch(66.494% 0.00233 15.434),
  	oklch(51.028% 0.00006 271.152)
  );
  --altcha-checkbox-border-radius: 5px;
  --altcha-checkbox-border-width: var(--altcha-border-width);
  --altcha-checkbox-outline: 2px solid var(--altcha-checkbox-outline-color);
  --altcha-checkbox-outline-color: -webkit-focus-ring-color;
  --altcha-checkbox-outline-offset: 2px;
  --altcha-checkbox-size: 22px;
  --altcha-checkbox-transition-duration: var(--altcha-transition-duration);
  --altcha-input-background-color: var(--altcha-color-base);
  --altcha-input-border-radius: 3px;
  --altcha-input-border-width: 1px;
  --altcha-input-color: var(--altcha-color-base-content);
  --altcha-max-width: 320px;
  --altcha-padding: 0.75rem;
  --altcha-popover-arrow-size: 6px;
  --altcha-popover-color: var(--altcha-border-color);
  --altcha-shadow: drop-shadow(3px 3px 6px oklch(0% 0 0 / 0.2));
  --altcha-spinner-color: var(--altcha-color-base-content);
  --altcha-switch-background-color: var(--altcha-color-neutral);
  --altcha-switch-border-radius: calc(infinity * 1px);
  --altcha-switch-height: var(--altcha-checkbox-size);
  --altcha-switch-padding: 0.25rem;
  --altcha-switch-width: calc(var(--altcha-checkbox-size) * 1.75);
  --altcha-switch-toggle-border-radius: 100%;
  --altcha-switch-toggle-color: var(--altcha-color-neutral-content);
  --altcha-switch-toggle-size: calc(
  	var(--altcha-switch-height) - calc(var(--altcha-switch-padding) * 2)
  );
  --altcha-transition-duration: 0.6s;
  --altcha-z-index: 99999999;
  --altcha-z-index-popover: 999999999;
}

@supports (-moz-appearance: none) {
  :root {
    --altcha-checkbox-outline-color: var(--altcha-color-primary);
  }
}
.altcha {
  all: revert-layer;
  display: none;
  font-family: inherit;
  font-size: inherit;
  position: relative;
}
.altcha[data-visible] {
  display: block;
}
.altcha-popover, .altcha-popover * {
  all: revert-layer;
  box-sizing: border-box;
  font-family: inherit;
  font-size: inherit;
  line-height: 1.25;
}
.altcha * {
  all: revert-layer;
  box-sizing: border-box;
  font-family: inherit;
  font-size: inherit;
  line-height: 1.25;
}
.altcha a, .altcha-popover a {
  color: currentColor;
  text-decoration: none;
}
.altcha a:hover, .altcha-popover a:hover {
  color: currentColor;
}
.altcha-main {
  align-items: start;
  background-color: var(--altcha-color-base);
  border: var(--altcha-border-width, 1px) solid var(--altcha-border-color);
  border-radius: var(--altcha-border-radius, 0);
  color: var(--altcha-color-base-content);
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  justify-content: space-between;
  padding: var(--altcha-padding);
  max-width: var(--altcha-max-width, 100%);
}
.altcha-main > * {
  display: flex;
  width: 100%;
}
.altcha-main > *:first-child {
  flex-grow: 1;
}
.altcha-checkbox-wrap {
  align-items: center;
  display: flex;
  flex-direction: row;
  flex-grow: 1;
  gap: 0.5rem;
}
.altcha-checkbox-wrap > * {
  display: flex;
}
.altcha-logo {
  opacity: 0.7;
}
.altcha-footer {
  align-items: center;
  display: flex;
  flex-grow: 1;
  gap: 0.5rem;
  justify-content: flex-end;
  font-size: 0.7rem;
  opacity: 0.7;
}
.altcha-footer p {
  margin: 0;
  padding: 0;
}
.altcha-error {
  font-size: 0.85rem;
}
.altcha-button {
  align-items: center;
  background: var(--altcha-color-primary);
  border: var(--altcha-input-border-width) solid var(--altcha-color-primary);
  border-radius: var(--altcha-input-border-radius);
  color: var(--altcha-color-primary-content);
  cursor: pointer;
  display: flex;
  font-size: 0.9rem;
  gap: 0.5rem;
  padding: 0.35rem;
}
.altcha-button:focus {
  border-color: var(--altcha-color-primary);
  outline: var(--altcha-checkbox-outline);
  outline-offset: var(--altcha-checkbox-outline-offset);
}
.altcha-button > .altcha-spinner, .altcha-button > svg {
  height: 20px;
  width: 20px;
}
.altcha-button-secondary {
  background: transparent;
  border-color: var(--altcha-color-neutral);
  color: var(--altcha-color-neutral-content);
}
.altcha-input {
  background: var(--altcha-input-background-color);
  border: var(--altcha-input-border-width) solid var(--altcha-color-neutral);
  border-radius: var(--altcha-input-border-radius);
  color: var(--altcha-input-color);
  flex-grow: 1;
  font-size: 1rem;
  min-width: 0;
  padding: 0.25rem;
  width: auto;
}
.altcha-input:focus {
  border-color: var(--altcha-color-primary);
  outline: var(--altcha-checkbox-outline);
  outline-offset: var(--altcha-checkbox-outline-offset);
}
.altcha-spinner {
  animation: altcha-rotate 0.6s linear infinite;
  border-radius: 100%;
  border: var(--altcha-checkbox-border-width) solid var(--altcha-spinner-color);
  border-bottom-color: transparent;
  border-right-color: transparent;
  opacity: 0.7;
}
.altcha-popover {
  background-color: var(--altcha-color-base);
  border: var(--altcha-border-width) solid var(--altcha-border-color);
  border-radius: var(--altcha-border-radius);
  color: var(--altcha-color-base-content);
  filter: var(--altcha-shadow);
  position: absolute;
  left: calc(var(--altcha-padding) / 2);
  max-width: calc(var(--altcha-max-width) - var(--altcha-padding));
  top: calc(var(--altcha-padding) + var(--altcha-checkbox-size) + var(--altcha-popover-arrow-size));
  z-index: var(--altcha-z-index-popover);
}
.altcha-popover-arrow {
  border: var(--altcha-popover-arrow-size) solid transparent;
  border-bottom-color: var(--altcha-popover-color);
  content: "";
  height: 0;
  left: calc(var(--altcha-checkbox-size) / 2);
  position: absolute;
  top: calc(var(--altcha-popover-arrow-size) * -2);
  width: 0;
}
.altcha-popover-content {
  max-height: 100dvh;
  overflow: auto;
  padding: var(--altcha-padding);
}
.altcha-popover[data-top=true][data-display=standard] {
  bottom: calc(100% - (var(--altcha-padding) - var(--altcha-popover-arrow-size)));
  top: auto;
}
.altcha-popover[data-top=true][data-display=standard] .altcha-popover-arrow {
  border-bottom-color: transparent;
  border-top-color: var(--altcha-popover-color);
  bottom: calc(var(--altcha-popover-arrow-size) * -2);
  top: auto;
}
.altcha-popover[data-variant=error] {
  --altcha-popover-color: var(--altcha-color-error);
  background-color: var(--altcha-color-error);
  border-color: var(--altcha-color-error);
  color: var(--altcha-color-error-content);
}
.altcha-popover[data-variant=error] .altcha-popover-content {
  padding: calc(var(--altcha-padding) / 1.5) var(--altcha-padding);
}
.altcha-popover[data-display=overlay] {
  animation: altcha-overlay-slidein 0.5s forwards;
  left: 50%;
  position: fixed;
  top: 45%;
  transform: translate(-50%, -50%);
  width: var(--altcha-max-width);
  z-index: var(--altcha-z-index);
}
.altcha-popover[data-display=bottomsheet] {
  animation: altcha-bottomsheet-slideup 0.5s forwards;
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
  border-bottom: 0;
  bottom: -100%;
  left: 50%;
  position: fixed;
  top: auto;
  transform: translate(-50%, 0);
  width: var(--altcha-max-width);
  z-index: var(--altcha-z-index);
}
.altcha-popover[data-display=bottomsheet] .altcha-popover-content {
  padding-bottom: calc(var(--altcha-padding) * 2);
}
.altcha-popover-backdrop {
  background: var(--altcha-color-base-content);
  bottom: 0;
  left: 0;
  opacity: 0.1;
  position: fixed;
  right: 0;
  top: 0;
  transition: opacity 0.5s;
  z-index: var(--altcha-z-index);
}
.altcha-popover-close {
  color: var(--altcha-color-base-content);
  cursor: pointer;
  display: inline-block;
  font-size: 1rem;
  height: 1.25rem;
  line-height: 0.95;
  position: absolute;
  right: 0;
  text-align: center;
  text-shadow: 0 0 1px var(--altcha-color-base);
  top: -1.5rem;
  width: 1.25rem;
  z-index: var(--altcha-z-index);
}
[dir=rtl] .altcha-popover {
  left: auto;
  right: calc(var(--altcha-padding) / 2);
}
[dir=rtl] .altcha-popover-arrow {
  left: auto;
  right: calc(var(--altcha-checkbox-size) / 2);
}
[dir=rtl] .altcha-popover-close {
  left: 0;
  right: auto;
}
.altcha-popover[data-display=bottomsheet] .altcha-footer, .altcha-popover[data-display=overlay] .altcha-footer {
  align-items: center;
  justify-content: center;
  padding-top: 1rem;
  gap: 0.5rem;
}
.altcha-popover[data-display=bottomsheet] .altcha-footer svg, .altcha-popover[data-display=overlay] .altcha-footer svg {
  height: 18px;
  width: 18px;
  vertical-align: middle;
}
.altcha-code-challenge > form {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}
.altcha-code-challenge-title {
  font-weight: 600;
}
.altcha-code-challenge-text {
  font-size: 0.85rem;
}
.altcha-code-challenge-image {
  background: white;
  border: var(--altcha-input-border-width) solid var(--altcha-color-neutral);
  border-radius: var(--altcha-input-border-radius);
  object-fit: contain;
  height: 50px;
}
.altcha-code-challenge-row {
  display: flex;
  gap: 0.5rem;
}
.altcha-code-challenge-buttons {
  align-items: center;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  margin-top: var(--altcha-padding);
  justify-content: space-between;
}
.altcha-code-challenge-buttons button {
  justify-content: center;
  width: 100%;
}
.altcha-checkbox {
  cursor: pointer;
  height: var(--altcha-checkbox-size);
  position: relative;
  width: var(--altcha-checkbox-size);
}
.altcha-checkbox input {
  appearance: none;
  background: var(--altcha-input-background-color);
  border: var(--altcha-checkbox-border-width, 2px) solid var(--altcha-checkbox-border-color);
  border-radius: var(--altcha-checkbox-border-radius);
  cursor: pointer;
  height: var(--altcha-checkbox-size);
  left: 0;
  margin: 0;
  padding: 0;
  position: absolute;
  top: 0;
  width: var(--altcha-checkbox-size);
}
@supports (hanging-punctuation: first) and (font: -apple-system-body) and (-webkit-appearance: none) {
  .altcha-checkbox input {
    /* Safari-only: fixes focus outline */
  }
  .altcha-checkbox input:focus {
    outline-width: 2px;
    outline-style: solid;
  }
}
.altcha-checkbox input:before {
  border-radius: var(--altcha-checkbox-border-radius);
  content: "";
  width: 100%;
  height: 100%;
  background: var(--altcha-color-neutral);
  display: block;
  transform: scale(0);
}
.altcha-checkbox input:checked {
  background-color: var(--altcha-color-success);
  border-color: var(--altcha-color-success);
}
.altcha-checkbox input:checked::before {
  background-color: var(--altcha-color-success);
  opacity: 0;
  transform: scale(2.2);
  transition: all var(--altcha-checkbox-transition-duration) ease;
  transition-delay: 0.1s;
}
.altcha-checkbox svg {
  --altcha-radio-svg-size: calc(var(--altcha-checkbox-size) * 0.5);
  --altcha-radio-svg-offset: calc(var(--altcha-checkbox-size) * 0.25);
  fill: none;
  left: var(--altcha-radio-svg-offset);
  height: var(--altcha-radio-svg-size);
  opacity: 0;
  position: absolute;
  stroke: currentColor;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 16px;
  stroke-dashoffset: 16px;
  top: var(--altcha-radio-svg-offset);
  transform: translate3d(0, 0, 0);
  width: var(--altcha-radio-svg-size);
}
.altcha-checkbox input:checked + svg {
  color: var(--altcha-color-success-content);
  opacity: 1;
  stroke-dashoffset: 0;
  transition: all var(--altcha-checkbox-transition-duration) ease;
  transition-delay: 0.1s;
}
.altcha-checkbox-spinner {
  display: none;
  left: 0;
  height: var(--altcha-checkbox-size);
  position: absolute;
  top: 0;
  width: var(--altcha-checkbox-size);
}
.altcha-checkbox[data-loading=true] input {
  appearance: none;
  opacity: 0;
  pointer-events: none;
}
.altcha-checkbox[data-loading=true] .altcha-checkbox-spinner {
  display: block;
}
.altcha-checkbox-native {
  height: var(--altcha-checkbox-size);
  position: relative;
  width: var(--altcha-checkbox-size);
}
.altcha-checkbox-native input {
  height: var(--altcha-checkbox-size);
  margin: 0;
  width: var(--altcha-checkbox-size);
}
.altcha-checkbox-native-spinner {
  display: none;
  left: 0;
  height: var(--altcha-checkbox-size);
  position: absolute;
  top: 0;
  width: var(--altcha-checkbox-size);
}
.altcha-checkbox-native[data-loading=true] input {
  appearance: none;
  opacity: 0;
  pointer-events: none;
}
.altcha-checkbox-native[data-loading=true] .altcha-checkbox-native-spinner {
  display: block;
}
.altcha-switch {
  align-items: center;
  border-radius: var(--altcha-switch-border-radius);
  background-color: var(--altcha-switch-background-color);
  display: flex;
  height: var(--altcha-switch-height);
  padding: var(--altcha-switch-padding);
  position: relative;
  width: var(--altcha-switch-width);
}
.altcha-switch:focus-within {
  outline: var(--altcha-checkbox-outline);
  outline-offset: var(--altcha-checkbox-outline-offset);
}
.altcha-switch input {
  appearance: none;
  cursor: pointer;
  height: 100%;
  left: 0;
  opacity: 0;
  position: absolute;
  top: 0;
  width: 100%;
}
.altcha-switch-toggle {
  align-items: center;
  background-color: var(--altcha-switch-toggle-color);
  border-radius: var(--altcha-switch-toggle-border-radius);
  cursor: pointer;
  display: flex;
  height: var(--altcha-switch-toggle-size);
  justify-content: center;
  left: var(--altcha-switch-padding);
  position: absolute;
  transition: width 150ms ease-out, left 150ms ease-out;
  width: var(--altcha-switch-toggle-size);
}
.altcha-switch-spinner {
  display: none;
  height: var(--altcha-switch-toggle-size);
  width: var(--altcha-switch-toggle-size);
}
.altcha-switch[data-loading=true] {
  pointer-events: none;
}
.altcha-switch[data-loading=true] .altcha-switch-spinner {
  display: block;
}
.altcha-switch[data-loading=true] .altcha-switch-toggle {
  background-color: transparent;
  left: calc(50% - var(--altcha-switch-toggle-size) / 2);
}
[data-state=verified] .altcha-switch {
  --altcha-switch-background-color: var(--altcha-color-success);
}
[data-state=verified] .altcha-switch-toggle {
  background-color: var(--altcha-color-success-content);
  left: calc(100% - var(--altcha-switch-height) + var(--altcha-switch-padding));
}
[dir=rtl] .altcha-switch-toggle {
  left: calc(100% - var(--altcha-switch-height) + var(--altcha-switch-padding));
}
[dir=rtl][data-state=verified] .altcha-switch-toggle {
  left: var(--altcha-switch-padding);
}
.altcha-floating-arrow {
  border: 6px solid transparent;
  border-bottom-color: var(--altcha-border-color);
  content: "";
  height: 0;
  left: 12px;
  position: absolute;
  top: -12px;
  width: 0;
}
.altcha-overlay-backdrop {
  bottom: 0;
  left: 0;
  position: fixed;
  right: 0;
  top: 0;
  transition: opacity var(--altcha-transition-duration);
  z-index: var(--altcha-z-index);
}
.altcha-overlay-close {
  display: inline-block;
  color: currentColor;
  cursor: pointer;
  font-size: 1rem;
  height: 1rem;
  line-height: 0.85;
  position: absolute;
  right: 0;
  text-align: center;
  text-shadow: 0 0 1px var(--altcha-color-base);
  top: -1.5rem;
  width: 1rem;
  z-index: var(--altcha-z-index);
}
.altcha[data-display=overlay] {
  animation: altcha-overlay-slidein var(--altcha-transition-duration) forwards;
  filter: var(--altcha-shadow);
  left: 50%;
  opacity: 0;
  position: fixed;
  top: 45%;
  transform: translate(-50%, -50%);
  z-index: var(--altcha-z-index);
}
.altcha[data-display=overlay] .altcha-main {
  width: var(--altcha-max-width);
}
.altcha[data-display=floating] {
  display: none;
  filter: var(--altcha-shadow);
  left: var(--altcha-floating-left, -100%);
  position: fixed;
  top: var(--altcha-floating-top, -100%);
  z-index: var(--altcha-z-index);
}
.altcha[data-display=floating] .altcha-main {
  width: var(--altcha-max-width);
}
.altcha[data-display=floating][data-floating-position=top] .altcha-floating-arrow {
  border-bottom-color: transparent;
  border-top-color: var(--altcha-border-color);
  bottom: -12px;
  top: auto;
}
.altcha[data-display=floating][data-visible] {
  display: flex;
}
.altcha[data-display=bar] {
  bottom: -100%;
  filter: var(--altcha-shadow);
  left: 0;
  position: fixed;
  right: 0;
  transition: bottom var(--altcha-transition-duration), top var(--altcha-transition-duration);
  z-index: var(--altcha-z-index);
}
.altcha[data-display=bar] .altcha-main {
  align-items: center;
  border-radius: 0;
  border-width: var(--altcha-border-width) 0 0 0;
  flex-direction: row;
  max-width: 100% !important;
}
.altcha[data-display=bar] .altcha-main > * {
  width: auto;
}
.altcha[data-display=bar][data-placement=top] {
  bottom: auto;
  top: -100%;
}
.altcha[data-display=bar][data-placement=top] .altcha-main {
  border-width: 0 0 var(--altcha-border-width) 0;
}
.altcha[data-display=bar][data-placement=bottom]:not([data-state=unverified]) {
  bottom: 0;
}
.altcha[data-display=bar][data-placement=top]:not([data-state=unverified]) {
  top: 0;
}
.altcha[data-display=invisible] {
  display: none;
}

@keyframes altcha-rotate {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
@keyframes altcha-bottomsheet-slideup {
  100% {
    bottom: 0;
  }
}
@keyframes altcha-overlay-slidein {
  100% {
    opacity: 1;
    top: 50%;
  }
}`),$altcha.algorithms.set("SHA-256",()=>new Hn),$altcha.algorithms.set("SHA-384",()=>new Hn),$altcha.algorithms.set("SHA-512",()=>new Hn),$altcha.algorithms.set("PBKDF2/SHA-256",()=>new zn),$altcha.algorithms.set("PBKDF2/SHA-384",()=>new zn),$altcha.algorithms.set("PBKDF2/SHA-512",()=>new zn),Yo}bc();typeof window<"u"&&window.$altcha?.algorithms&&window.$altcha.algorithms.set("SHA-256",()=>new Worker("/assets/altcha-worker.js"));const yc=dc(Wo.forwardRef((Y,St)=>F.jsx("form",{ref:St,...Y}))),wc="/api/Auth/login",_c="/api/Auth/login",xc={enter:Y=>({x:Y>0?40:-40,opacity:0}),center:{x:0,opacity:1},exit:Y=>({x:Y>0?-40:40,opacity:0})},kc={palette:{mode:"light"},shape:{borderRadius:7},shadows:oc,typography:ac},aa=Zl(nc.merge({},kc,ic));aa.components=cc(aa);const Oc=({title:Y,subtitle:St,subtext:rn})=>{const[Te,Ar]=tt.useState("admin"),[Pt,Ot]=tt.useState(1),[pt,nn]=tt.useState(!1),[Tr,Et]=tt.useState(""),[Ir,nr]=tt.useState(!1),[rt,ar]=tt.useState({username:"",password:""}),[$r,se]=tt.useState({username:"",password:""}),[gt,Lt]=tt.useState(!0),Wt=tt.useRef(null),we=tt.useRef(null),Le=V=>{const K=V.detail;nr(K?.state==="verified")},qe=V=>{if(we.current&&we.current.removeEventListener("statechange",Le),we.current=V,V){V.addEventListener("statechange",Le),typeof window<"u"&&window.$altcha?.algorithms&&window.$altcha.algorithms.set("SHA-256",()=>new Worker("/assets/altcha-worker.js"));try{const K=lc();V.configure?.({challenge:`${K.API_BASE_URL}/api/Auth/altcha-challenge`,fetch:async(ye,ve)=>{const J=new Headers(ve?.headers||{});return K.API_KEY&&!J.has("X-BIOPEOPLETRACKING-API-KEY")&&J.set("X-BIOPEOPLETRACKING-API-KEY",K.API_KEY),fetch(ye,{...ve,headers:J})}})}catch{}}};tt.useEffect(()=>{const V=localStorage.getItem("rememberedAdminUsername"),K=localStorage.getItem("rememberedVisitorUsername"),ye=localStorage.getItem("rememberMePreference"),ve=localStorage.getItem("rememberedLoginMode");V&&ar(J=>({...J,username:V})),K&&se(J=>({...J,username:K})),ye!==null&&Lt(ye==="true"),ve&&(ve==="admin"||ve==="visitor")&&Ar(ve)},[]);const Je=Te==="admin",be=Je?rt:$r,le=(V,K)=>{Ot(Te==="admin"&&K==="visitor"?1:-1),Ar(K),Et(""),nr(!1)},ce=(V,K)=>ye=>{Et(""),V==="admin"?ar(ve=>({...ve,[K]:ye.target.value})):se(ve=>({...ve,[K]:ye.target.value}))},Ve=async V=>{V.preventDefault(),Et("");const K=we.current?.value||we.current?.querySelector?.('input[name="altcha"]')?.value||"";if(!K){Et("Please complete the CAPTCHA verification before signing in.");return}const ye=Je?wc:_c;try{const ve=await sc.post(ye,{...be,altchaPayload:K}),J=ve?.data?.collection?.data??ve?.data;if(J?.token){localStorage.setItem("token",J.token);const Be=na(J.token),nt=Be["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"],Rr=Be["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"],Ze=Be["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"],Nt=Be.ApplicationId;if(nt&&localStorage.setItem("username",nt),Rr&&localStorage.setItem("email",Rr),Ze&&localStorage.setItem("levelPriority",Ze.trim()),Nt&&Ze.trim()!=="System"&&localStorage.setItem("applicationId",Nt),Be.fullName&&localStorage.setItem("fullName",Be.fullName),Be.groupName&&localStorage.setItem("groupName",Be.groupName),Be.accessibleBuildings){const Ct=Be.accessibleBuildings.split(",").map(at=>at.trim()).filter(Boolean);localStorage.setItem("accessibleBuildings",JSON.stringify(Ct))}gt?(Je?localStorage.setItem("rememberedAdminUsername",be.username):localStorage.setItem("rememberedVisitorUsername",be.username),localStorage.setItem("rememberMePreference","true"),localStorage.setItem("rememberedLoginMode",Te)):(localStorage.removeItem("rememberedAdminUsername"),localStorage.removeItem("rememberedVisitorUsername"),localStorage.removeItem("rememberedLoginMode"),localStorage.setItem("rememberMePreference","false"))}J?.refreshToken&&localStorage.setItem("refreshToken",J.refreshToken),localStorage.setItem("response",JSON.stringify(J)),localStorage.setItem("welcomePopupShown","false");const Mt=na(J.token)["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"];if(Je&&Mt==="Primary"){Et("You do not have permission to login as Admin");return}setTimeout(()=>{window.location.href=Je?"/dashboards/newmainmenu":Mt==="Primary"?"/security-view/dashboard":"/my-visit",console.log("decoded",na(J.token))},300)}catch{Et("Invalid username or password. Please try again."),Je?ar({username:"",password:""}):se({username:"",password:""}),requestAnimationFrame(()=>{Wt.current?.focus()})}};return F.jsxs(Jl,{theme:aa,children:[Y&&F.jsx(ra,{fontWeight:700,variant:"h3",mb:1,children:Y}),rn,F.jsx(tn,{mt:3,children:F.jsxs(Xl,{value:Te,onChange:le,variant:"fullWidth",sx:{mb:2,"& .MuiTab-root":{textTransform:"none",fontWeight:600}},children:[F.jsx(Bo,{value:"admin",label:"Admin"}),F.jsx(Bo,{value:"visitor",label:"Security"})]})}),Tr&&F.jsx(ra,{variant:"body2",color:"error",textAlign:"center",sx:{backgroundColor:"#ffebee",border:"1px solid #ffcdd2",borderRadius:1,p:1,mb:2},children:Tr}),F.jsx(fc,{mode:"wait",custom:Pt,children:F.jsx(yc,{onSubmit:Ve,custom:Pt,variants:xc,initial:"enter",animate:"center",exit:"exit",transition:{duration:.25,ease:"easeOut"},children:F.jsxs(zo,{spacing:2,children:[F.jsxs(tn,{children:[F.jsx(Ho,{htmlFor:"username",children:"Username"}),F.jsx(Ko,{id:"username",fullWidth:!0,inputRef:Wt,value:be.username,onChange:ce(Te,"username")})]}),F.jsxs(tn,{children:[F.jsx(Ho,{htmlFor:"password",children:"Password"}),F.jsx(Ko,{id:"password",type:pt?"text":"password",fullWidth:!0,value:be.password,onChange:ce(Te,"password"),InputProps:{endAdornment:F.jsx(Ql,{position:"end",children:F.jsx(ec,{onClick:()=>nn(V=>!V),children:pt?F.jsx(hc,{size:20}):F.jsx(vc,{size:20})})})}})]}),F.jsxs(zo,{direction:"row",justifyContent:"space-between",alignItems:"center",children:[F.jsx(pc,{children:F.jsx(gc,{control:F.jsx(Zo,{checked:gt,onChange:V=>Lt(V.target.checked)}),label:"Remember this Device"})}),F.jsx(ra,{component:tc,to:"/auth/forgot-password",fontWeight:500,sx:{textDecoration:"none",color:"primary.main"},children:"Forgot Password ?"})]}),F.jsx(tn,{sx:{"& altcha-widget":{width:"100%","--altcha-border-radius":"8px","--altcha-border-color":"rgba(0,0,0,0.23)","--altcha-color-base":"#ffffff","--altcha-color-base-content":"#333333",fontSize:"0.875rem"}},children:F.jsx("altcha-widget",{ref:qe,challenge:"/api/Auth/altcha-challenge",challengeurl:"/api/Auth/altcha-challenge",hidefooter:!0,style:{width:"100%"}})}),F.jsx(rc,{type:"submit",fullWidth:!0,size:"large",variant:"contained",disabled:!Ir,children:Je?"Sign In as Admin":"Sign In as Visitor"})]})},Te)}),St]})};export{Oc as A};
