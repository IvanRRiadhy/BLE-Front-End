import{H as o,j as t}from"./index-D3jHKZPM.js";const s=o(t.jsx("path",{d:"M10 6 8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"}),"ChevronRight");export{s as C};
