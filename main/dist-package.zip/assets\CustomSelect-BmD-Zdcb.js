import{s as t,j as e,ao as o}from"./index-Dzx-6msi.js";const m=t(s=>e.jsx(o,{...s}))(({})=>({}));export{m as C};
