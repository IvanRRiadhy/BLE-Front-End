import{R as Go,j as V,s as Wo,r as rt,jL as ql,jM as Jl,T as ra,B as tn,bT as Zl,bU as Vo,S as Bo,ca as zo,c4 as Ho,bf as Xl,w as Ql,Z as ec,z as tc,jO as rc,jP as nc,jQ as ac,jR as oc,cH as ic,jN as sc,ay as lc,jS as cc}from"./index-D3jHKZPM.js";import{C as uc}from"./Checkbox-B2Xn4qz2.js";import{A as fc,m as dc}from"./index-DOffYeFw.js";import{I as hc}from"./IconEyeOff-DJ_7mqDy.js";import{I as vc}from"./IconEye-DtO4lR-I.js";import{F as pc}from"./FormGroup-7Q8CSrKu.js";import{F as gc}from"./FormControlLabel-G1XqrZsA.js";const qo=Wo("span")(({theme:Y})=>({borderRadius:3,width:19,height:19,marginLeft:"4px",boxShadow:Y.palette.mode==="dark"?`0 0 0 1px ${Y.palette.grey[200]}`:`inset 0 0 0 1px ${Y.palette.grey[300]}`,backgroundColor:"transparent",".Mui-focusVisible &":{outline:Y.palette.mode==="dark"?`0px auto ${Y.palette.grey[200]}`:`0px auto  ${Y.palette.grey[300]}`,outlineOffset:2},"input:hover ~ &":{backgroundColor:(Y.palette.mode==="dark",Y.palette.primary)},"input:disabled ~ &":{boxShadow:"none",background:Y.palette.grey[100]}})),mc=Wo(qo)({boxShadow:"none",width:19,height:19,"&:before":{display:"block",width:19,height:19,backgroundImage:`url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M12 5c-.28 0-.53.11-.71.29L7 9.59l-2.29-2.3a1.003 1.003 0 00-1.42 1.42l3 3c.18.18.43.29.71.29s.53-.11.71-.29l5-5A1.003 1.003 0 0012 5z' fill='%23fff'/%3E%3C/svg%3E")`,content:'""'}}),Jo=Go.forwardRef((Y,Ct)=>V.jsx(uc,{disableRipple:!0,color:Y.color||"default",checkedIcon:V.jsx(mc,{sx:{backgroundColor:Y.color?`${Y.color}.main`:"primary.main"}}),icon:V.jsx(qo,{}),inputProps:{"aria-label":"Checkbox demo"},ref:Ct,...Y}));Jo.displayName="CustomCheckbox";var Ko={},Yo;function bc(){if(Yo)return Ko;Yo=1;const Y=!1;var Ct=Array.isArray,rn=Array.prototype.indexOf,Ae=Array.prototype.includes,Ar=Array.from,Ot=Object.keys,Lt=Object.defineProperty,pt=Object.getOwnPropertyDescriptor,nn=Object.getOwnPropertyDescriptors,Tr=Object.prototype,gt=Array.prototype,Ir=Object.getPrototypeOf,rr=Object.isExtensible;const nt=()=>{};function nr(e){for(var t=0;t<e.length;t++)e[t]()}function $r(){var e,t,r=new Promise((n,a)=>{e=n,t=a});return{promise:r,resolve:e,reject:t}}const ce=2,mt=4,Mt=8,Wt=1<<24,ye=16,Ne=32,Te=64,ar=128,ue=512,Z=1024,fe=2048,De=4096,Ie=8192,O=16384,W=32768,je=1<<25,K=65536,ie=1<<17,$e=1<<18,at=1<<19,Rr=1<<20,Xe=65536,Nt=1<<21,bt=1<<22,Ke=1<<23,At=Symbol("$state"),Zo=Symbol("legacy props"),Xo=Symbol(""),aa=Symbol("attributes"),an=Symbol("class"),on=Symbol("style"),sn=Symbol("text"),or=Symbol("form reset"),Pr=new class extends Error{name="StaleReactionError";message="The reaction that called `getAbortSignal()` was re-run or destroyed"},ir=!!globalThis.document?.contentType&&globalThis.document.contentType.includes("xml"),sr=3,lr=8;function oa(e){return e===this.v}function ia(e,t){return e!=e?t==t:e!==t||e!==null&&typeof e=="object"||typeof e=="function"}function Qo(e){return!ia(e,this.v)}function ei(e){throw new Error("https://svelte.dev/e/lifecycle_outside_component")}function ti(){throw new Error("https://svelte.dev/e/async_derived_orphan")}function ri(e){throw new Error("https://svelte.dev/e/effect_in_teardown")}function ni(){throw new Error("https://svelte.dev/e/effect_in_unowned_derived")}function ai(e){throw new Error("https://svelte.dev/e/effect_orphan")}function oi(){throw new Error("https://svelte.dev/e/effect_update_depth_exceeded")}function ii(){throw new Error("https://svelte.dev/e/hydration_failed")}function si(){throw new Error("https://svelte.dev/e/state_descriptors_fixed")}function li(){throw new Error("https://svelte.dev/e/state_prototype_fixed")}function ci(){throw new Error("https://svelte.dev/e/state_unsafe_mutation")}function ui(){throw new Error("https://svelte.dev/e/svelte_boundary_reset_onerror")}let fi=!1;const di=1,hi=2,ln="[",sa="[!",la="[?",ca="]",Dt={},de=Symbol("uninitialized"),ua="http://www.w3.org/1999/xhtml",vi="http://www.w3.org/2000/svg",pi="http://www.w3.org/1998/Math/MathML",gi="@attach";let Re=null;function qt(e){Re=e}function yt(e,t=!1,r){Re={p:Re,i:!1,c:null,e:null,s:e,x:null,r:I,l:null}}function wt(e){var t=Re,r=t.e;if(r!==null){t.e=null;for(var n of r)Ya(n)}return e!==void 0&&(t.x=e),t.i=!0,Re=t.p,e??{}}function fa(){return!0}let jt=[];function da(){var e=jt;jt=[],nr(e)}function _t(e){if(jt.length===0&&!fr){var t=jt;queueMicrotask(()=>{t===jt&&da()})}jt.push(e)}function mi(){for(;jt.length>0;)da()}function bi(){console.warn("https://svelte.dev/e/derived_inert")}function cr(e){console.warn("https://svelte.dev/e/hydration_mismatch")}function yi(){console.warn("https://svelte.dev/e/select_multiple_invalid_value")}function wi(){console.warn("https://svelte.dev/e/svelte_boundary_reset_noop")}let R=!1;function ot(e){R=e}let N;function Se(e){if(e===null)throw cr(),Dt;return N=e}function Ut(){return Se(st(N))}function X(e){if(R){if(st(N)!==null)throw cr(),Dt;N=e}}function cn(e=1){if(R){for(var t=e,r=N;t--;)r=st(r);N=r}}function un(e=!0){for(var t=0,r=N;;){if(r.nodeType===lr){var n=r.data;if(n===ca){if(t===0)return r;t-=1}else(n===ln||n===sa||n[0]==="["&&!isNaN(Number(n.slice(1))))&&(t+=1)}var a=st(r);e&&r.remove(),r=a}}function ha(e){if(!e||e.nodeType!==lr)throw cr(),Dt;return e.data}function xt(e){if(typeof e!="object"||e===null||At in e)return e;const t=Ir(e);if(t!==Tr&&t!==gt)return e;var r=new Map,n=Ct(e),a=L(0),i=zt,s=l=>{if(zt===i)return l();var u=j,c=zt;Ye(null),Fa(i);var d=l();return Ye(u),Fa(c),d};return n&&r.set("length",L(e.length)),new Proxy(e,{defineProperty(l,u,c){(!("value"in c)||c.configurable===!1||c.enumerable===!1||c.writable===!1)&&si();var d=r.get(u);return d===void 0?s(()=>{var v=L(c.value);return r.set(u,v),v}):w(d,c.value,!0),!0},deleteProperty(l,u){var c=r.get(u);if(c===void 0){if(u in l){const d=s(()=>L(de));r.set(u,d),hr(a)}}else w(c,de),hr(a);return!0},get(l,u,c){if(u===At)return e;var d=r.get(u),v=u in l;if(d===void 0&&(!v||pt(l,u)?.writable)&&(d=s(()=>{var m=xt(v?l[u]:de),g=L(m);return g}),r.set(u,d)),d!==void 0){var h=o(d);return h===de?void 0:h}return Reflect.get(l,u,c)},getOwnPropertyDescriptor(l,u){var c=Reflect.getOwnPropertyDescriptor(l,u);if(c&&"value"in c){var d=r.get(u);d&&(c.value=o(d))}else if(c===void 0){var v=r.get(u),h=v?.v;if(v!==void 0&&h!==de)return{enumerable:!0,configurable:!0,value:h,writable:!0}}return c},has(l,u){if(u===At)return!0;var c=r.get(u),d=c!==void 0&&c.v!==de||Reflect.has(l,u);if(c!==void 0||I!==null&&(!d||pt(l,u)?.writable)){c===void 0&&(c=s(()=>{var h=d?xt(l[u]):de,m=L(h);return m}),r.set(u,c));var v=o(c);if(v===de)return!1}return d},set(l,u,c,d){var v=r.get(u),h=u in l;if(n&&u==="length")for(var m=c;m<v.v;m+=1){var g=r.get(m+"");g!==void 0?w(g,de):m in l&&(g=s(()=>L(de)),r.set(m+"",g))}if(v===void 0)(!h||pt(l,u)?.writable)&&(v=s(()=>L(void 0)),w(v,xt(c)),r.set(u,v));else{h=v.v!==de;var x=s(()=>xt(c));w(v,x)}var T=Reflect.getOwnPropertyDescriptor(l,u);if(T?.set&&T.set.call(d,c),!h){if(n&&typeof u=="string"){var M=r.get("length"),be=Number(u);Number.isInteger(be)&&be>=M.v&&w(M,be+1)}hr(a)}return!0},ownKeys(l){o(a);var u=Reflect.ownKeys(l).filter(v=>{var h=r.get(v);return h===void 0||h.v!==de});for(var[c,d]of r)d.v!==de&&!(c in l)&&u.push(c);return u},setPrototypeOf(){li()}})}function va(e){try{if(e!==null&&typeof e=="object"&&At in e)return e[At]}catch{}return e}function _i(e,t){return Object.is(va(e),va(t))}var Ft,fn,pa,ga,ma;function dn(){if(Ft===void 0){Ft=window,fn=document,pa=/Firefox/.test(navigator.userAgent);var e=Element.prototype,t=Node.prototype,r=Text.prototype;ga=pt(t,"firstChild").get,ma=pt(t,"nextSibling").get,rr(e)&&(e[an]=void 0,e[aa]=null,e[on]=void 0,e.__e=void 0),rr(r)&&(r[sn]=void 0)}}function it(e=""){return document.createTextNode(e)}function Ue(e){return ga.call(e)}function st(e){return ma.call(e)}function ae(e,t){if(!R)return Ue(e);var r=Ue(N);if(r===null)r=N.appendChild(it());else if(t&&r.nodeType!==sr){var n=it();return r?.before(n),Se(n),n}return t&&Or(r),Se(r),r}function Jt(e,t=!1){if(!R){var r=Ue(e);return r instanceof Comment&&r.data===""?st(r):r}if(t){if(N?.nodeType!==sr){var n=it();return N?.before(n),Se(n),n}Or(N)}return N}function te(e,t=1,r=!1){let n=R?N:e;for(var a;t--;)a=n,n=st(n);if(!R)return n;if(r){if(n?.nodeType!==sr){var i=it();return n===null?a?.after(i):n.before(i),Se(i),i}Or(n)}return Se(n),n}function xi(e){e.textContent=""}function hn(e,t,r){return document.createElementNS(t??ua,e,void 0)}function Or(e){if(e.nodeValue.length<65536)return;let t=e.nextSibling;for(;t!==null&&t.nodeType===sr;)t.remove(),e.nodeValue+=t.nodeValue,t=e.nextSibling}function ba(e){var t=I;if(t===null)return j.f|=Ke,e;if((t.f&W)===0&&(t.f&mt)===0)throw e;Tt(e,t)}function Tt(e,t){for(;t!==null;){if((t.f&ar)!==0){if((t.f&W)===0)throw e;try{t.b.error(e);return}catch(r){e=r}}t=t.parent}throw e}const ki=-7169;function se(e,t){e.f=e.f&ki|t}function vn(e){(e.f&ue)!==0||e.deps===null?se(e,Z):se(e,De)}function ya(e){if(e!==null)for(const t of e)(t.f&ce)===0||(t.f&Xe)===0||(t.f^=Xe,ya(t.deps))}function wa(e,t,r){(e.f&fe)!==0?t.add(e):(e.f&De)!==0&&r.add(e),ya(e.deps),se(e,Z)}function _a(e,t,r){if(e==null)return t(void 0),nt;const n=gr(()=>e.subscribe(t,r));return n.unsubscribe?()=>n.unsubscribe():n}const Zt=[];function Si(e,t=nt){let r=null;const n=new Set;function a(l){if(ia(e,l)&&(e=l,r)){const u=!Zt.length;for(const c of n)c[1](),Zt.push(c,e);if(u){for(let c=0;c<Zt.length;c+=2)Zt[c][0](Zt[c+1]);Zt.length=0}}}function i(l){a(l(e))}function s(l,u=nt){const c=[l,u];return n.add(c),n.size===1&&(r=t(a,i)||nt),l(e),()=>{n.delete(c),n.size===0&&r&&(r(),r=null)}}return{set:a,update:i,subscribe:s}}function ur(e){let t;return _a(e,r=>t=r)(),t}let pn=Symbol("unmounted");function xa(e,t,r){const n=r[t]??={store:null,source:Oa(void 0),unsubscribe:nt};if(n.store!==e&&!(pn in r))if(n.unsubscribe(),n.store=e??null,e==null)n.source.v=void 0,n.unsubscribe=nt;else{var a=!0;n.unsubscribe=_a(e,i=>{a?n.source.v=i:w(n.source,i)}),a=!1}return e&&pn in r?ur(e):o(n.source)}function Ei(){const e={};function t(){Vr(()=>{for(var r in e)e[r].unsubscribe();Lt(e,pn,{enumerable:!1,value:!0})})}return[e,t]}let gn=null,Xt=null,P=null,mn=null,Qe=null,bn=null,fr=!1,yn=!1,Qt=null,Lr=null;var ka=0;let Ci=1;class kt{id=Ci++;#e=!1;linked=!0;#t=null;#r=null;async_deriveds=new Map;current=new Map;previous=new Map;unblocked=new Set;#l=new Set;#n=new Set;#i=new Set;#a=0;#o=new Map;#d=null;#s=[];#v=[];#h=new Set;#c=new Set;#u=new Map;#f=new Set;is_fork=!1;#m=!1;#_(){if(this.is_fork)return!0;for(const n of this.#o.keys()){for(var t=n,r=!1;t.parent!==null;){if(this.#u.has(t)){r=!0;break}t=t.parent}if(!r)return!0}return!1}skip_effect(t){this.#u.has(t)||this.#u.set(t,{d:[],m:[]}),this.#f.delete(t)}unskip_effect(t,r=n=>this.schedule(n)){var n=this.#u.get(t);if(n){this.#u.delete(t);for(var a of n.d)se(a,fe),r(a);for(a of n.m)se(a,De),r(a)}this.#f.add(t)}#g(){if(this.#e=!0,ka++>1e3&&(this.#w(),Ai()),!this.#_()){for(const u of this.#h)this.#c.delete(u),se(u,fe),this.schedule(u);for(const u of this.#c)se(u,De),this.schedule(u)}const t=this.#s;this.#s=[],this.apply();var r=Qt=[],n=[],a=Lr=[];for(const u of t)try{this.#x(u,r,n)}catch(c){throw Aa(u),c}if(P=null,a.length>0){var i=kt.ensure();for(const u of a)i.schedule(u)}if(Qt=null,Lr=null,this.#_()){this.#p(n),this.#p(r);for(const[u,c]of this.#u)Ca(u,c);a.length>0&&P.#g();return}const s=this.#k();if(s){s.#b(this);return}this.#h.clear(),this.#c.clear();for(const u of this.#l)u(this);this.#l.clear(),mn=this,Sa(n),Sa(r),mn=null,this.#d?.resolve();var l=P;if(this.linked&&this.#a===0&&this.#w(),this.#s.length>0){l===null&&(l=this,this.#y());const u=l;u.#s.push(...this.#s.filter(c=>!u.#s.includes(c)))}l!==null&&l.#g()}#x(t,r,n){t.f^=Z;for(var a=t.first;a!==null;){var i=a.f,s=(i&(Ne|Te))!==0,l=s&&(i&Z)!==0,u=l||(i&Ie)!==0||this.#u.has(a);if(!u&&a.fn!==null){s?a.f^=Z:(i&mt)!==0?r.push(a):vr(a)&&((i&ye)!==0&&this.#c.add(a),er(a));var c=a.first;if(c!==null){a=c;continue}}for(;a!==null;){var d=a.next;if(d!==null){a=d;break}a=a.parent}}}#k(){for(var t=this.#t;t!==null;){if(!t.is_fork){for(const[r,[,n]]of this.current)if(t.current.has(r)&&!n)return t}t=t.#t}return null}#b(t){for(const[n,a]of t.current)!this.previous.has(n)&&t.previous.has(n)&&this.previous.set(n,t.previous.get(n)),this.current.set(n,a);for(const[n,a]of t.async_deriveds){const i=this.async_deriveds.get(n);i&&a.promise.then(i.resolve)}const r=n=>{var a=n.reactions;if(a!==null)for(const l of a){var i=l.f;if((i&ce)!==0)r(l);else{var s=l;i&(bt|ye)&&!this.async_deriveds.has(s)&&(this.#c.delete(s),se(s,fe),this.schedule(s))}}};for(const n of this.current.keys())r(n);this.oncommit(()=>t.discard()),t.#w(),P=this,this.#g()}#p(t){for(var r=0;r<t.length;r+=1)wa(t[r],this.#h,this.#c)}capture(t,r,n=!1){t.v!==de&&!this.previous.has(t)&&this.previous.set(t,t.v),(t.f&Ke)===0&&(this.current.set(t,[r,n]),Qe?.set(t,r)),this.is_fork||(t.v=r)}activate(){P=this}deactivate(){P=null,Qe=null}flush(){try{yn=!0,P=this,this.#g()}finally{ka=0,bn=null,Qt=null,Lr=null,yn=!1,P=null,Qe=null,Vt.clear()}}discard(){for(const t of this.#n)t(this);this.#n.clear(),this.#i.clear(),this.#w()}register_created_effect(t){this.#v.push(t)}#S(){this.#w();for(let d=gn;d!==null;d=d.#r){var t=d.id<this.id,r=[];for(const[v,[h,m]]of this.current){if(d.current.has(v)){var n=d.current.get(v)[0];if(t&&h!==n)d.current.set(v,[h,m]);else continue}r.push(v)}if(t)for(const[v,h]of this.async_deriveds){const m=d.async_deriveds.get(v);m&&h.promise.then(m.resolve)}if(d.#e){var a=[...d.current.keys()].filter(v=>!this.current.has(v));if(a.length===0)t&&d.discard();else if(r.length>0){if(t)for(const v of this.#f)d.unskip_effect(v,h=>{(h.f&(ye|bt))!==0?d.schedule(h):d.#p([h])});d.activate();var i=new Set,s=new Map;for(var l of r)Ea(l,a,i,s);s=new Map;var u=[...d.current.keys()].filter(v=>this.current.has(v)?this.current.get(v)[0]!==v.v:!0);if(u.length>0)for(const v of this.#v)(v.f&(O|Ie|ie))===0&&wn(v,u,s)&&((v.f&(bt|ye))!==0?(se(v,fe),d.schedule(v)):d.#h.add(v));if(d.#s.length>0){d.apply();for(var c of d.#s)d.#x(c,[],[]);d.#s=[]}d.deactivate()}}}}increment(t,r){if(this.#a+=1,t){let n=this.#o.get(r)??0;this.#o.set(r,n+1)}}decrement(t,r){if(this.#a-=1,t){let n=this.#o.get(r)??0;n===1?this.#o.delete(r):this.#o.set(r,n-1)}this.#m||(this.#m=!0,_t(()=>{this.#m=!1,this.linked&&this.flush()}))}transfer_effects(t,r){for(const n of t)this.#h.add(n);for(const n of r)this.#c.add(n);t.clear(),r.clear()}oncommit(t){this.#l.add(t)}ondiscard(t){this.#n.add(t)}on_fork_commit(t){this.#i.add(t)}run_fork_commit_callbacks(){for(const t of this.#i)t(this);this.#i.clear()}settled(){return(this.#d??=$r()).promise}static ensure(){if(P===null){const t=P=new kt;t.#y(),!yn&&!fr&&_t(()=>{t.#e||t.flush()})}return P}apply(){{Qe=null;return}}schedule(t){if(bn=t,t.b?.is_pending&&(t.f&(mt|Mt|Wt))!==0&&(t.f&W)===0){t.b.defer_effect(t);return}for(var r=t;r.parent!==null;){r=r.parent;var n=r.f;if(Qt!==null&&r===I&&(j===null||(j.f&ce)===0))return;if((n&(Te|Ne))!==0){if((n&Z)===0)return;r.f^=Z}}this.#s.push(r)}#y(){Xt===null?gn=Xt=this:(Xt.#r=this,this.#t=Xt),Xt=this}#w(){var t=this.#t,r=this.#r;t===null?gn=r:t.#r=r,r===null?Xt=t:r.#t=t,this.linked=!1}}function q(e){var t=fr;fr=!0;try{for(var r;;){if(mi(),P===null)return r;P.flush()}}finally{fr=t}}function Ai(){try{oi()}catch(e){Tt(e,bn)}}let St=null;function Sa(e){var t=e.length;if(t!==0){for(var r=0;r<t;){var n=e[r++];if((n.f&(O|Ie))===0&&vr(n)&&(St=new Set,er(n),n.deps===null&&n.first===null&&n.nodes===null&&n.teardown===null&&n.ac===null&&Ja(n),St?.size>0)){Vt.clear();for(const a of St){if((a.f&(O|Ie))!==0)continue;const i=[a];let s=a.parent;for(;s!==null;)St.has(s)&&(St.delete(s),i.push(s)),s=s.parent;for(let l=i.length-1;l>=0;l--){const u=i[l];(u.f&(O|Ie))===0&&er(u)}}St.clear()}}St=null}}function Ea(e,t,r,n){if(!r.has(e)&&(r.add(e),e.reactions!==null))for(const a of e.reactions){const i=a.f;(i&ce)!==0?Ea(a,t,r,n):(i&(bt|ye))!==0&&(i&fe)===0&&wn(a,t,n)&&(se(a,fe),_n(a))}}function wn(e,t,r){const n=r.get(e);if(n!==void 0)return n;if(e.deps!==null)for(const a of e.deps){if(Ae.call(t,a))return!0;if((a.f&ce)!==0&&wn(a,t,r))return r.set(a,!0),!0}return r.set(e,!1),!1}function _n(e){P.schedule(e)}function Ca(e,t){if(!((e.f&Ne)!==0&&(e.f&Z)!==0)){(e.f&fe)!==0?t.d.push(e):(e.f&De)!==0&&t.m.push(e),se(e,Z);for(var r=e.first;r!==null;)Ca(r,t),r=r.next}}function Aa(e){se(e,Z);for(var t=e.first;t!==null;)Aa(t),t=t.next}function Ti(e){let t=0,r=dr(0),n;return()=>{Sn()&&(o(r),Br(()=>(t===0&&(n=gr(()=>e(()=>hr(r)))),t+=1,()=>{_t(()=>{t-=1,t===0&&(n?.(),n=void 0,hr(r))})})))}}var Ii=K|at;function $i(e,t,r,n){new Ri(e,t,r,n)}class Ri{parent;is_pending=!1;transform_error;#e;#t=R?N:null;#r;#l;#n;#i=null;#a=null;#o=null;#d=null;#s=0;#v=0;#h=!1;#c=new Set;#u=new Set;#f=null;#m=Ti(()=>(this.#f=dr(this.#s),()=>{this.#f=null}));constructor(t,r,n,a){this.#e=t,this.#r=r,this.#l=i=>{var s=I;s.b=this,s.f|=ar,n(i)},this.parent=I.b,this.transform_error=a??this.parent?.transform_error??(i=>i),this.#n=mr(()=>{if(R){const i=this.#t;Ut();const s=i.data===sa;if(i.data.startsWith(la)){const u=JSON.parse(i.data.slice(la.length));this.#g(u)}else s?this.#x():this.#_()}else this.#k()},Ii),R&&(this.#e=N)}#_(){try{this.#i=ct(()=>this.#l(this.#e))}catch(t){this.error(t)}}#g(t){const r=this.#r.failed;r&&(this.#o=ct(()=>{r(this.#e,()=>t,()=>()=>{})}))}#x(){const t=this.#r.pending;t&&(this.is_pending=!0,this.#a=ct(()=>t(this.#e)),_t(()=>{var r=this.#d=document.createDocumentFragment(),n=it();r.append(n),this.#i=this.#p(()=>ct(()=>this.#l(n))),this.#v===0&&(this.#e.before(r),this.#d=null,br(this.#a,()=>{this.#a=null}),this.#b(P))}))}#k(){try{if(this.is_pending=this.has_pending_snippet(),this.#v=0,this.#s=0,this.#i=ct(()=>{this.#l(this.#e)}),this.#v>0){var t=this.#d=document.createDocumentFragment();Qa(this.#i,t);const r=this.#r.pending;this.#a=ct(()=>r(this.#e))}else this.#b(P)}catch(r){this.error(r)}}#b(t){this.is_pending=!1,t.transfer_effects(this.#c,this.#u)}defer_effect(t){wa(t,this.#c,this.#u)}is_rendered(){return!this.is_pending&&(!this.parent||this.parent.is_rendered())}has_pending_snippet(){return!!this.#r.pending}#p(t){var r=I,n=j,a=Re;lt(this.#n),Ye(this.#n),qt(this.#n.ctx);try{return kt.ensure(),t()}catch(i){return ba(i),null}finally{lt(r),Ye(n),qt(a)}}#S(t,r){if(!this.has_pending_snippet()){this.parent&&this.parent.#S(t,r);return}this.#v+=t,this.#v===0&&(this.#b(r),this.#a&&br(this.#a,()=>{this.#a=null}),this.#d&&(this.#e.before(this.#d),this.#d=null))}update_pending_count(t,r){this.#S(t,r),this.#s+=t,!(!this.#f||this.#h)&&(this.#h=!0,_t(()=>{this.#h=!1,this.#f&&jr(this.#f,this.#s)}))}get_effect_pending(){return this.#m(),o(this.#f)}error(t){if(!this.#r.onerror&&!this.#r.failed)throw t;P?.is_fork?(this.#i&&P.skip_effect(this.#i),this.#a&&P.skip_effect(this.#a),this.#o&&P.skip_effect(this.#o),P.on_fork_commit(()=>{this.#y(t)})):this.#y(t)}#y(t){this.#i&&(we(this.#i),this.#i=null),this.#a&&(we(this.#a),this.#a=null),this.#o&&(we(this.#o),this.#o=null),R&&(Se(this.#t),cn(),Se(un()));var r=this.#r.onerror;let n=this.#r.failed;var a=!1,i=!1;const s=()=>{if(a){wi();return}a=!0,i&&ui(),this.#o!==null&&br(this.#o,()=>{this.#o=null}),this.#p(()=>{this.#k()})},l=u=>{try{i=!0,r?.(u,s),i=!1}catch(c){Tt(c,this.#n&&this.#n.parent)}n&&(this.#o=this.#p(()=>{try{return ct(()=>{var c=I;c.b=this,c.f|=ar,n(this.#e,()=>u,()=>s)})}catch(c){return Tt(c,this.#n.parent),null}}))};_t(()=>{var u;try{u=this.transform_error(t)}catch(c){Tt(c,this.#n&&this.#n.parent);return}u!==null&&typeof u=="object"&&typeof u.then=="function"?u.then(l,c=>Tt(c,this.#n&&this.#n.parent)):l(u)})}}function Ta(e,t,r,n){const a=xn;var i=e.filter(h=>!h.settled);if(r.length===0&&i.length===0){n(t.map(a));return}var s=I,l=Pi(),u=i.length===1?i[0].promise:i.length>1?Promise.all(i.map(h=>h.promise)):null;function c(h){if((s.f&O)===0){l();try{n(h)}catch(m){Tt(m,s)}Mr()}}var d=Ia();if(r.length===0){u.then(()=>c(t.map(a))).finally(d);return}function v(){Promise.all(r.map(h=>Oi(h))).then(h=>c([...t.map(a),...h])).catch(h=>Tt(h,s)).finally(d)}u?u.then(()=>{l(),v(),Mr()}):v()}function Pi(){var e=I,t=j,r=Re,n=P;return function(i=!0){lt(e),Ye(t),qt(r),i&&(e.f&O)===0&&(n?.activate(),n?.apply())}}function Mr(e=!0){lt(null),Ye(null),qt(null),e&&P?.deactivate()}function Ia(){var e=I,t=e.b,r=P,n=t.is_rendered();return t.update_pending_count(1,r),r.increment(n,e),()=>{t.update_pending_count(-1,r),r.decrement(n,e)}}function xn(e){var t=ce|fe;return I!==null&&(I.f|=at),{ctx:Re,deps:null,effects:null,equals:oa,f:t,fn:e,reactions:null,rv:0,v:de,wv:0,parent:I,ac:null}}const Nr=Symbol("obsolete");function Oi(e,t,r){let n=I;n===null&&ti();var a=void 0,i=dr(de),s=!j,l=new Set;return Ki(()=>{var u=I,c=$r();a=c.promise;try{Promise.resolve(e()).then(c.resolve,m=>{m!==Pr&&c.reject(m)}).finally(Mr)}catch(m){c.reject(m),Mr()}var d=P;if(s){if((u.f&W)!==0)var v=Ia();if(n.b.is_rendered())d.async_deriveds.get(u)?.reject(Nr);else for(const m of l.values())m.reject(Nr);l.add(c),d.async_deriveds.set(u,c)}const h=(m,g=void 0)=>{v?.(),l.delete(c),g!==Nr&&(d.activate(),g?(i.f|=Ke,jr(i,g)):((i.f&Ke)!==0&&(i.f^=Ke),jr(i,m)),d.deactivate())};c.promise.then(h,m=>h(null,m||"unknown"))}),Vr(()=>{for(const u of l)u.reject(Nr)}),new Promise(u=>{function c(d){function v(){d===a?u(i):c(a)}d.then(v,v)}c(a)})}function Ee(e){const t=xn(e);return ja(t),t}function Li(e){var t=e.effects;if(t!==null){e.effects=null;for(var r=0;r<t.length;r+=1)we(t[r])}}function kn(e){var t,r=I,n=e.parent;if(!Et&&n!==null&&e.v!==de&&(n.f&(O|Ie))!==0)return bi(),e.v;lt(n);try{e.f&=~Xe,Li(e),t=za(e)}finally{lt(r)}return t}function $a(e){var t=kn(e);if(!e.equals(t)&&(e.wv=Va(),(!P?.is_fork||e.deps===null)&&(P!==null?(P.capture(e,t,!0),mn?.capture(e,t,!0)):e.v=t,e.deps===null))){se(e,Z);return}Et||(Qe!==null?(Sn()||P?.is_fork)&&Qe.set(e,t):vn(e))}function Mi(e){if(e.effects!==null)for(const t of e.effects)(t.teardown||t.ac)&&(t.teardown?.(),t.ac?.abort(Pr),t.fn!==null&&(t.teardown=nt),t.ac=null,pr(t,0),Cn(t))}function Ra(e){if(e.effects!==null)for(const t of e.effects)t.teardown&&t.fn!==null&&er(t)}let Dr=new Set;const Vt=new Map;let Pa=!1;function dr(e,t){var r={f:0,v:e,reactions:null,equals:oa,rv:0,wv:0};return r}function L(e,t){const r=dr(e);return ja(r),r}function Oa(e,t=!1,r=!0){const n=dr(e);return t||(n.equals=Qo),n}function w(e,t,r=!1){j!==null&&(!et||(j.f&ie)!==0)&&fa()&&(j.f&(ce|ye|bt|ie))!==0&&(Ge===null||!Ae.call(Ge,e))&&ci();let n=r?xt(t):t;return jr(e,n,Lr)}function jr(e,t,r=null){if(!e.equals(t)){Vt.set(e,Et?t:e.v);var n=kt.ensure();if(n.capture(e,t),(e.f&ce)!==0){const a=e;(e.f&fe)!==0&&kn(a),Qe===null&&vn(a)}e.wv=Va(),La(e,fe,r),I!==null&&(I.f&Z)!==0&&(I.f&(Ne|Te))===0&&(We===null?Ui([e]):We.push(e)),!n.is_fork&&Dr.size>0&&!Pa&&Ni()}return t}function Ni(){Pa=!1;for(const e of Dr){(e.f&Z)!==0&&se(e,De);let t;try{t=vr(e)}catch{t=!0}t&&er(e)}Dr.clear()}function hr(e){w(e,e.v+1)}function La(e,t,r){var n=e.reactions;if(n!==null)for(var a=n.length,i=0;i<a;i++){var s=n[i],l=s.f,u=(l&fe)===0;if(u&&se(s,t),(l&ie)!==0)Dr.add(s);else if((l&ce)!==0){var c=s;Qe?.delete(c),(l&Xe)===0&&(l&ue&&(I===null||(I.f&Nt)===0)&&(s.f|=Xe),La(c,De,r))}else if(u){var d=s;(l&ye)!==0&&St!==null&&St.add(d),r!==null?r.push(d):_n(d)}}}function Di(e,t){if(t){const r=document.body;e.autofocus=!0,_t(()=>{document.activeElement===r&&e.focus()})}}let Ma=!1;function Na(){Ma||(Ma=!0,document.addEventListener("reset",e=>{Promise.resolve().then(()=>{if(!e.defaultPrevented)for(const t of e.target.elements)t[or]?.()})},{capture:!0}))}function Ur(e){var t=j,r=I;Ye(null),lt(null);try{return e()}finally{Ye(t),lt(r)}}function ji(e,t,r,n=r){e.addEventListener(t,()=>Ur(r));const a=e[or];a?e[or]=()=>{a(),n(!0)}:e[or]=()=>n(!0),Na()}let Fr=!1,Et=!1;function Da(e){Et=e}let j=null,et=!1;function Ye(e){j=e}let I=null;function lt(e){I=e}let Ge=null;function ja(e){j!==null&&(Ge===null?Ge=[e]:Ge.push(e))}let Pe=null,Fe=0,We=null;function Ui(e){We=e}let Ua=1,Bt=0,zt=Bt;function Fa(e){zt=e}function Va(){return++Ua}function vr(e){var t=e.f;if((t&fe)!==0)return!0;if(t&ce&&(e.f&=~Xe),(t&De)!==0){for(var r=e.deps,n=r.length,a=0;a<n;a++){var i=r[a];if(vr(i)&&$a(i),i.wv>e.wv)return!0}(t&ue)!==0&&Qe===null&&se(e,Z)}return!1}function Ba(e,t,r=!0){var n=e.reactions;if(n!==null&&!(Ge!==null&&Ae.call(Ge,e)))for(var a=0;a<n.length;a++){var i=n[a];(i.f&ce)!==0?Ba(i,t,!1):t===i&&(r?se(i,fe):(i.f&Z)!==0&&se(i,De),_n(i))}}function za(e){var t=Pe,r=Fe,n=We,a=j,i=Ge,s=Re,l=et,u=zt,c=e.f;Pe=null,Fe=0,We=null,j=(c&(Ne|Te))===0?e:null,Ge=null,qt(e.ctx),et=!1,zt=++Bt,e.ac!==null&&(Ur(()=>{e.ac.abort(Pr)}),e.ac=null);try{e.f|=Nt;var d=e.fn,v=d();e.f|=W;var h=e.deps,m=P?.is_fork;if(Pe!==null){var g;if(m||pr(e,Fe),h!==null&&Fe>0)for(h.length=Fe+Pe.length,g=0;g<Pe.length;g++)h[Fe+g]=Pe[g];else e.deps=h=Pe;if(Sn()&&(e.f&ue)!==0)for(g=Fe;g<h.length;g++)(h[g].reactions??=[]).push(e)}else!m&&h!==null&&Fe<h.length&&(pr(e,Fe),h.length=Fe);if(fa()&&We!==null&&!et&&h!==null&&(e.f&(ce|De|fe))===0)for(g=0;g<We.length;g++)Ba(We[g],e);if(a!==null&&a!==e){if(Bt++,a.deps!==null)for(let x=0;x<r;x+=1)a.deps[x].rv=Bt;if(t!==null)for(const x of t)x.rv=Bt;We!==null&&(n===null?n=We:n.push(...We))}return(e.f&Ke)!==0&&(e.f^=Ke),v}catch(x){return ba(x)}finally{e.f^=Nt,Pe=t,Fe=r,We=n,j=a,Ge=i,qt(s),et=l,zt=u}}function Fi(e,t){let r=t.reactions;if(r!==null){var n=rn.call(r,e);if(n!==-1){var a=r.length-1;a===0?r=t.reactions=null:(r[n]=r[a],r.pop())}}if(r===null&&(t.f&ce)!==0&&(Pe===null||!Ae.call(Pe,t))){var i=t;(i.f&ue)!==0&&(i.f^=ue,i.f&=~Xe),i.v!==de&&vn(i),Mi(i),pr(i,0)}}function pr(e,t){var r=e.deps;if(r!==null)for(var n=t;n<r.length;n++)Fi(e,r[n])}function er(e){var t=e.f;if((t&O)===0){se(e,Z);var r=I,n=Fr;I=e,Fr=!0;try{(t&(ye|Wt))!==0?Yi(e):Cn(e),Wa(e);var a=za(e);e.teardown=typeof a=="function"?a:null,e.wv=Ua;var i;Y&&fi&&(e.f&fe)!==0&&e.deps}finally{Fr=n,I=r}}}async function Ht(){await Promise.resolve(),q()}function o(e){var t=e.f,r=(t&ce)!==0;if(j!==null&&!et){var n=I!==null&&(I.f&O)!==0;if(!n&&(Ge===null||!Ae.call(Ge,e))){var a=j.deps;if((j.f&Nt)!==0)e.rv<Bt&&(e.rv=Bt,Pe===null&&a!==null&&a[Fe]===e?Fe++:Pe===null?Pe=[e]:Pe.push(e));else{(j.deps??=[]).push(e);var i=e.reactions;i===null?e.reactions=[j]:Ae.call(i,j)||i.push(j)}}}if(Et&&Vt.has(e))return Vt.get(e);if(r){var s=e;if(Et){var l=s.v;return((s.f&Z)===0&&s.reactions!==null||Ka(s))&&(l=kn(s)),Vt.set(s,l),l}var u=(s.f&ue)===0&&!et&&j!==null&&(Fr||(j.f&ue)!==0),c=(s.f&W)===0;vr(s)&&(u&&(s.f|=ue),$a(s)),u&&!c&&(Ra(s),Ha(s))}if(Qe?.has(e))return Qe.get(e);if((e.f&Ke)!==0)throw e.v;return e.v}function Ha(e){if(e.f|=ue,e.deps!==null)for(const t of e.deps)(t.reactions??=[]).push(e),(t.f&ce)!==0&&(t.f&ue)===0&&(Ra(t),Ha(t))}function Ka(e){if(e.v===de)return!0;if(e.deps===null)return!1;for(const t of e.deps)if(Vt.has(t)||(t.f&ce)!==0&&Ka(t))return!0;return!1}function gr(e){var t=et;try{return et=!0,e()}finally{et=t}}function Vi(e){I===null&&(j===null&&ai(),ni()),Et&&ri()}function Bi(e,t){var r=t.last;r===null?t.last=t.first=e:(r.next=e,e.prev=r,t.last=e)}function tt(e,t){var r=I;r!==null&&(r.f&Ie)!==0&&(e|=Ie);var n={ctx:Re,deps:null,nodes:null,f:e|fe|ue,first:null,fn:t,last:null,next:null,parent:r,b:r&&r.b,prev:null,teardown:null,wv:0,ac:null};P?.register_created_effect(n);var a=n;if((e&mt)!==0)Qt!==null?Qt.push(n):kt.ensure().schedule(n);else if(t!==null){try{er(n)}catch(s){throw we(n),s}a.deps===null&&a.teardown===null&&a.nodes===null&&a.first===a.last&&(a.f&at)===0&&(a=a.first,(e&ye)!==0&&(e&K)!==0&&a!==null&&(a.f|=K))}if(a!==null&&(a.parent=r,r!==null&&Bi(a,r),j!==null&&(j.f&ce)!==0&&(e&Te)===0)){var i=j;(i.effects??=[]).push(a)}return n}function Sn(){return j!==null&&!et}function Vr(e){const t=tt(Mt,null);return se(t,Z),t.teardown=e,t}function Oe(e){Vi();var t=I.f,r=!j&&(t&Ne)!==0&&(t&W)===0;if(r){var n=Re;(n.e??=[]).push(e)}else return Ya(e)}function Ya(e){return tt(mt|Rr,e)}function zi(e){kt.ensure();const t=tt(Te|at,e);return()=>{we(t)}}function Hi(e){kt.ensure();const t=tt(Te|at,e);return(r={})=>new Promise(n=>{r.outro?br(t,()=>{we(t),n(void 0)}):(we(t),n(void 0))})}function En(e){return tt(mt,e)}function Ki(e){return tt(bt|at,e)}function Br(e,t=0){return tt(Mt|t,e)}function xe(e,t=[],r=[],n=[]){Ta(n,t,r,a=>{tt(Mt,()=>e(...a.map(o)))})}function mr(e,t=0){var r=tt(ye|t,e);return r}function Ga(e,t=0){var r=tt(Wt|t,e);return r}function ct(e){return tt(Ne|at,e)}function Wa(e){var t=e.teardown;if(t!==null){const r=Et,n=j;Da(!0),Ye(null);try{t.call(null)}finally{Da(r),Ye(n)}}}function Cn(e,t=!1){var r=e.first;for(e.first=e.last=null;r!==null;){const a=r.ac;a!==null&&Ur(()=>{a.abort(Pr)});var n=r.next;(r.f&Te)!==0?r.parent=null:we(r,t),r=n}}function Yi(e){for(var t=e.first;t!==null;){var r=t.next;(t.f&Ne)===0&&we(t),t=r}}function we(e,t=!0){var r=!1;(t||(e.f&$e)!==0)&&e.nodes!==null&&e.nodes.end!==null&&(qa(e.nodes.start,e.nodes.end),r=!0),se(e,je),Cn(e,t&&!r),pr(e,0);var n=e.nodes&&e.nodes.t;if(n!==null)for(const i of n)i.stop();Wa(e),e.f^=je,e.f|=O;var a=e.parent;a!==null&&a.first!==null&&Ja(e),e.next=e.prev=e.teardown=e.ctx=e.deps=e.fn=e.nodes=e.ac=e.b=null}function qa(e,t){for(;e!==null;){var r=e===t?null:st(e);e.remove(),e=r}}function Ja(e){var t=e.parent,r=e.prev,n=e.next;r!==null&&(r.next=n),n!==null&&(n.prev=r),t!==null&&(t.first===e&&(t.first=n),t.last===e&&(t.last=r))}function br(e,t,r=!0){var n=[];Za(e,n,!0);var a=()=>{r&&we(e),t&&t()},i=n.length;if(i>0){var s=()=>--i||a();for(var l of n)l.out(s)}else a()}function Za(e,t,r){if((e.f&Ie)===0){e.f^=Ie;var n=e.nodes&&e.nodes.t;if(n!==null)for(const l of n)(l.is_global||r)&&t.push(l);for(var a=e.first;a!==null;){var i=a.next;if((a.f&Te)===0){var s=(a.f&K)!==0||(a.f&Ne)!==0&&(e.f&ye)!==0;Za(a,t,s?r:!1)}a=i}}}function Gi(e){Xa(e,!0)}function Xa(e,t){if((e.f&Ie)!==0){e.f^=Ie,(e.f&Z)===0&&(se(e,fe),kt.ensure().schedule(e));for(var r=e.first;r!==null;){var n=r.next,a=(r.f&K)!==0||(r.f&Ne)!==0;Xa(r,a?t:!1),r=n}var i=e.nodes&&e.nodes.t;if(i!==null)for(const s of i)(s.is_global||t)&&s.in()}}function Qa(e,t){if(e.nodes)for(var r=e.nodes.start,n=e.nodes.end;r!==null;){var a=r===n?null:st(r);t.append(r),r=a}}function eo(e){const t={get:r=>ur(t.store)[r],set:(r,n)=>{typeof r=="string"?Object.assign(ur(t.store),{[r]:n}):Object.assign(ur(t.store),r),t.store.set(ur(t.store))},store:Si(e)};return t}globalThis.$altcha=globalThis.$altcha||{algorithms:new Map,defaults:eo({}),i18n:eo({}),instances:new Set,plugins:new Set};const Wi={ariaLinkLabel:"Altcha (official website)",cancel:"Cancel",enterCode:"Enter code",enterCodeAria:"Enter code you hear. Press Space to play audio.",enterCodeFromImage:"To proceed, please enter the code from the image below.",error:"Verification failed. Try again later.",expired:"Verification expired. Try again.",footer:'Protected by <a href="https://altcha.org/" tabindex="-1" target="_blank" aria-label="Altcha (official website)">ALTCHA</a>',getAudioChallenge:"Get an audio challenge",label:"I'm not a robot",loading:"Loading...",reload:"Reload",verify:"Verify",verificationRequired:"Verification required!",verified:"Verified",verifying:"Verifying...",waitAlert:"Verifying... please wait."};globalThis.$altcha.i18n.set("en",Wi);const qi="5";typeof window<"u"&&((window.__svelte??={}).v??=new Set).add(qi);const yr=Symbol("events"),to=new Set,An=new Set;function ro(e,t,r,n={}){function a(i){if(n.capture||Tn.call(t,i),!i.cancelBubble)return Ur(()=>r?.call(this,i))}return e.startsWith("pointer")||e.startsWith("touch")||e==="wheel"?_t(()=>{t.addEventListener(e,a,n)}):t.addEventListener(e,a,n),a}function ge(e,t,r,n,a){var i={capture:n,passive:a},s=ro(e,t,r,i);(t===document.body||t===window||t===document||t instanceof HTMLMediaElement)&&Vr(()=>{t.removeEventListener(e,s,i)})}function zr(e,t,r){(t[yr]??={})[e]=r}function Hr(e){for(var t=0;t<e.length;t++)to.add(e[t]);for(var r of An)r(e)}let no=null;function Tn(e){var t=this,r=t.ownerDocument,n=e.type,a=e.composedPath?.()||[],i=a[0]||e.target;no=e;var s=0,l=no===e&&e[yr];if(l){var u=a.indexOf(l);if(u!==-1&&(t===document||t===window)){e[yr]=t;return}var c=a.indexOf(t);if(c===-1)return;u<=c&&(s=u)}if(i=a[s]||e.target,i!==t){Lt(e,"currentTarget",{configurable:!0,get(){return i||r}});var d=j,v=I;Ye(null),lt(null);try{for(var h,m=[];i!==null;){var g=i.assignedSlot||i.parentNode||i.host||null;try{var x=i[yr]?.[n];x!=null&&(!i.disabled||e.target===i)&&x.call(i,e)}catch(T){h?m.push(T):h=T}if(e.cancelBubble||g===t||g===null)break;i=g}if(h){for(let T of m)queueMicrotask(()=>{throw T});throw h}}finally{e[yr]=t,delete e.currentTarget,Ye(d),lt(v)}}}const Ji=globalThis?.window?.trustedTypes&&globalThis.window.trustedTypes.createPolicy("svelte-trusted-html",{createHTML:e=>e});function Zi(e){return Ji?.createHTML(e)??e}function ao(e){var t=hn("template");return t.innerHTML=Zi(e.replaceAll("<!>","<!---->")),t.content}function Ve(e,t){var r=I;r.nodes===null&&(r.nodes={start:e,end:t,a:null,t:null})}function re(e,t){var r=(t&di)!==0,n=(t&hi)!==0,a,i=!e.startsWith("<!>");return()=>{if(R)return Ve(N,null),N;a===void 0&&(a=ao(i?e:"<!>"+e),r||(a=Ue(a)));var s=n||pa?document.importNode(a,!0):a.cloneNode(!0);if(r){var l=Ue(s),u=s.lastChild;Ve(l,u)}else Ve(s,s);return s}}function Xi(e,t,r="svg"){var n=!e.startsWith("<!>"),a=`<${r}>${n?e:"<!>"+e}</${r}>`,i;return()=>{if(R)return Ve(N,null),N;if(!i){var s=ao(a),l=Ue(s);i=Ue(l)}var u=i.cloneNode(!0);return Ve(u,u),u}}function In(e,t){return Xi(e,t,"svg")}function Kr(e=""){if(!R){var t=it(e+"");return Ve(t,t),t}var r=N;return r.nodeType!==sr?(r.before(r=it()),Se(r)):Or(r),Ve(r,r),r}function oo(){if(R)return Ve(N,null),N;var e=document.createDocumentFragment(),t=document.createComment(""),r=it();return e.append(t,r),Ve(t,r),e}function D(e,t){if(R){var r=I;((r.f&W)===0||r.nodes.end===null)&&(r.nodes.end=N),Ut();return}e!==null&&e.before(t)}function Qi(e){return e.endsWith("capture")&&e!=="gotpointercapture"&&e!=="lostpointercapture"}const es=["beforeinput","click","change","dblclick","contextmenu","focusin","focusout","input","keydown","keyup","mousedown","mousemove","mouseout","mouseover","mouseup","pointerdown","pointermove","pointerout","pointerover","pointerup","touchend","touchmove","touchstart"];function ts(e){return es.includes(e)}const rs={formnovalidate:"formNoValidate",ismap:"isMap",nomodule:"noModule",playsinline:"playsInline",readonly:"readOnly",defaultvalue:"defaultValue",defaultchecked:"defaultChecked",srcobject:"srcObject",novalidate:"noValidate",allowfullscreen:"allowFullscreen",disablepictureinpicture:"disablePictureInPicture",disableremoteplayback:"disableRemotePlayback"};function ns(e){return e=e.toLowerCase(),rs[e]??e}const as=["touchstart","touchmove"];function os(e){return as.includes(e)}function ut(e,t){var r=t==null?"":typeof t=="object"?`${t}`:t;r!==(e[sn]??=e.nodeValue)&&(e[sn]=r,e.nodeValue=`${r}`)}function io(e,t){return so(e,t)}function is(e,t){dn(),t.intro=t.intro??!1;const r=t.target,n=R,a=N;try{for(var i=Ue(r);i&&(i.nodeType!==lr||i.data!==ln);)i=st(i);if(!i)throw Dt;ot(!0),Se(i);const s=so(e,{...t,anchor:i});return ot(!1),s}catch(s){if(s instanceof Error&&s.message.split(`
`).some(l=>l.startsWith("https://svelte.dev/e/")))throw s;return s!==Dt&&console.warn("Failed to hydrate: ",s),t.recover===!1&&ii(),dn(),xi(r),ot(!1),io(e,t)}finally{ot(n),Se(a)}}const Yr=new Map;function so(e,{target:t,anchor:r,props:n={},events:a,context:i,intro:s=!0,transformError:l}){dn();var u=void 0,c=Hi(()=>{var d=r??t.appendChild(it());$i(d,{pending:()=>{}},m=>{yt({});var g=Re;if(i&&(g.c=i),a&&(n.$$events=a),R&&Ve(m,null),u=e(m,n)||{},R&&(I.nodes.end=N,N===null||N.nodeType!==lr||N.data!==ca))throw cr(),Dt;wt()},l);var v=new Set,h=m=>{for(var g=0;g<m.length;g++){var x=m[g];if(!v.has(x)){v.add(x);var T=os(x);for(const he of[t,document]){var M=Yr.get(he);M===void 0&&(M=new Map,Yr.set(he,M));var be=M.get(x);be===void 0?(he.addEventListener(x,Tn,{passive:T}),M.set(x,1)):M.set(x,be+1)}}}};return h(Ar(to)),An.add(h),()=>{for(var m of v)for(const T of[t,document]){var g=Yr.get(T),x=g.get(m);--x==0?(T.removeEventListener(m,Tn),g.delete(m),g.size===0&&Yr.delete(T)):g.set(m,x)}An.delete(h),d!==r&&d.parentNode?.removeChild(d)}});return $n.set(u,c),u}let $n=new WeakMap;function ss(e,t){const r=$n.get(e);return r?($n.delete(e),r(t)):Promise.resolve()}class Gr{anchor;#e=new Map;#t=new Map;#r=new Map;#l=new Set;#n=!0;constructor(t,r=!0){this.anchor=t,this.#n=r}#i=t=>{if(this.#e.has(t)){var r=this.#e.get(t),n=this.#t.get(r);if(n)Gi(n),this.#l.delete(r);else{var a=this.#r.get(r);a&&(this.#t.set(r,a.effect),this.#r.delete(r),a.fragment.lastChild.remove(),this.anchor.before(a.fragment),n=a.effect)}for(const[i,s]of this.#e){if(this.#e.delete(i),i===t)break;const l=this.#r.get(s);l&&(we(l.effect),this.#r.delete(s))}for(const[i,s]of this.#t){if(i===r||this.#l.has(i))continue;const l=()=>{if(Array.from(this.#e.values()).includes(i)){var c=document.createDocumentFragment();Qa(s,c),c.append(it()),this.#r.set(i,{effect:s,fragment:c})}else we(s);this.#l.delete(i),this.#t.delete(i)};this.#n||!n?(this.#l.add(i),br(s,l,!1)):l()}}};#a=t=>{this.#e.delete(t);const r=Array.from(this.#e.values());for(const[n,a]of this.#r)r.includes(n)||(we(a.effect),this.#r.delete(n))};ensure(t,r){var n=P;r&&!this.#t.has(t)&&!this.#r.has(t)&&this.#t.set(t,ct(()=>r(this.anchor))),this.#e.set(n,t),R&&(this.anchor=N),this.#i(n)}}function ls(e,t,...r){var n=new Gr(e);mr(()=>{const a=t()??null;n.ensure(a,a&&(i=>a(i,...r)))},K)}function Rn(e){Re===null&&ei(),Oe(()=>{const t=gr(e);if(typeof t=="function")return t})}function me(e,t,r=!1){var n;R&&(n=N,Ut());var a=new Gr(e),i=r?K:0;function s(l,u){if(R){var c=ha(n);if(l!==parseInt(c.substring(1))){var d=un();Se(d),a.anchor=d,ot(!1),a.ensure(l,u),ot(!0);return}}a.ensure(l,u)}mr(()=>{var l=!1;t((u,c=0)=>{l=!0,s(c,u)}),l||s(-1,null)},i)}const cs=Symbol("NaN");function us(e,t,r){R&&Ut();var n=new Gr(e);mr(()=>{var a=t();a!==a&&(a=cs),n.ensure(a,r)})}function lo(e,t,r=!1,n=!1,a=!1,i=!1){var s=e,l="";if(r){var u=e;R&&(s=Se(Ue(u)))}xe(()=>{var c=I;if(l===(l=t()??"")){R&&Ut();return}if(r&&!R){c.nodes=null,u.innerHTML=l,l!==""&&Ve(Ue(u),u.lastChild);return}if(c.nodes!==null&&(qa(c.nodes.start,c.nodes.end),c.nodes=null),l!==""){if(R){N.data;for(var d=Ut(),v=d;d!==null&&(d.nodeType!==lr||d.data!=="");)v=d,d=st(d);if(d===null)throw cr(),Dt;Ve(N,v),s=Se(d);return}var h=n?vi:a?pi:void 0,m=hn(n?"svg":a?"math":"template",h);m.innerHTML=l;var g=n||a?m:m.content;if(Ve(Ue(g),g.lastChild),n||a)for(;Ue(g);)s.before(Ue(g));else s.before(g)}})}function fs(e,t,r){var n;R&&(n=N,Ut());var a=new Gr(e);mr(()=>{var i=t()??null;if(R){var s=ha(n),l=s===ln,u=i!==null;if(l!==u){var c=un();Se(c),a.anchor=c,ot(!1),a.ensure(i,i&&(d=>r(d,i))),ot(!0);return}}a.ensure(i,i&&(d=>r(d,i)))},K)}function ds(e,t){var r=void 0,n;Ga(()=>{r!==(r=t())&&(n&&(we(n),n=null),r&&(n=ct(()=>{En(()=>r(e))})))})}function co(e){var t,r,n="";if(typeof e=="string"||typeof e=="number")n+=e;else if(typeof e=="object")if(Array.isArray(e)){var a=e.length;for(t=0;t<a;t++)e[t]&&(r=co(e[t]))&&(n&&(n+=" "),n+=r)}else for(r in e)e[r]&&(n&&(n+=" "),n+=r);return n}function hs(){for(var e,t,r=0,n="",a=arguments.length;r<a;r++)(e=arguments[r])&&(t=co(e))&&(n&&(n+=" "),n+=t);return n}function vs(e){return typeof e=="object"?hs(e):e??""}const uo=[...` 	
\r\f \v\uFEFF`];function ps(e,t,r){var n=e==null?"":""+e;if(r){for(var a of Object.keys(r))if(r[a])n=n?n+" "+a:a;else if(n.length)for(var i=a.length,s=0;(s=n.indexOf(a,s))>=0;){var l=s+i;(s===0||uo.includes(n[s-1]))&&(l===n.length||uo.includes(n[l]))?n=(s===0?"":n.substring(0,s))+n.substring(l+1):s=l}}return n===""?null:n}function fo(e,t=!1){var r=t?" !important;":";",n="";for(var a of Object.keys(e)){var i=e[a];i!=null&&i!==""&&(n+=" "+a+": "+i+r)}return n}function Pn(e){return e[0]!=="-"||e[1]!=="-"?e.toLowerCase():e}function gs(e,t){if(t){var r="",n,a;if(Array.isArray(t)?(n=t[0],a=t[1]):n=t,e){e=String(e).replaceAll(/\s*\/\*.*?\*\/\s*/g,"").trim();var i=!1,s=0,l=!1,u=[];n&&u.push(...Object.keys(n).map(Pn)),a&&u.push(...Object.keys(a).map(Pn));var c=0,d=-1;const x=e.length;for(var v=0;v<x;v++){var h=e[v];if(l?h==="/"&&e[v-1]==="*"&&(l=!1):i?i===h&&(i=!1):h==="/"&&e[v+1]==="*"?l=!0:h==='"'||h==="'"?i=h:h==="("?s++:h===")"&&s--,!l&&i===!1&&s===0){if(h===":"&&d===-1)d=v;else if(h===";"||v===x-1){if(d!==-1){var m=Pn(e.substring(c,d).trim());if(!u.includes(m)){h!==";"&&v++;var g=e.substring(c,v).trim();r+=" "+g+";"}}c=v+1,d=-1}}}}return n&&(r+=fo(n)),a&&(r+=fo(a,!0)),r=r.trim(),r===""?null:r}return e==null?null:String(e)}function ms(e,t,r,n,a,i){var s=e[an];if(R||s!==r||s===void 0){var l=ps(r,n,i);(!R||l!==e.getAttribute("class"))&&(l==null?e.removeAttribute("class"):t?e.className=l:e.setAttribute("class",l)),e[an]=r}else if(i&&a!==i)for(var u in i){var c=!!i[u];(a==null||c!==!!a[u])&&e.classList.toggle(u,c)}return i}function On(e,t={},r,n){for(var a in r){var i=r[a];t[a]!==i&&(r[a]==null?e.style.removeProperty(a):e.style.setProperty(a,i,n))}}function bs(e,t,r,n){var a=e[on];if(R||a!==t){var i=gs(t,n);(!R||i!==e.getAttribute("style"))&&(i==null?e.removeAttribute("style"):e.style.cssText=i),e[on]=t}else n&&(Array.isArray(n)?(On(e,r?.[0],n[0]),On(e,r?.[1],n[1],"important")):On(e,r,n));return n}function Ln(e,t,r=!1){if(e.multiple){if(t==null)return;if(!Ct(t))return yi();for(var n of e.options)n.selected=t.includes(ho(n));return}for(n of e.options){var a=ho(n);if(_i(a,t)){n.selected=!0;return}}(!r||t!==void 0)&&(e.selectedIndex=-1)}function ys(e){var t=new MutationObserver(()=>{Ln(e,e.__value)});t.observe(e,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value"]}),Vr(()=>{t.disconnect()})}function ho(e){return"__value"in e?e.__value:e.value}const wr=Symbol("class"),_r=Symbol("style"),vo=Symbol("is custom element"),po=Symbol("is html"),ws=ir?"link":"LINK",_s=ir?"input":"INPUT",xs=ir?"option":"OPTION",ks=ir?"select":"SELECT",Ss=ir?"progress":"PROGRESS";function Mn(e){if(R){var t=!1,r=()=>{if(!t){if(t=!0,e.hasAttribute("value")){var n=e.value;z(e,"value",null),e.value=n}if(e.hasAttribute("checked")){var a=e.checked;z(e,"checked",null),e.checked=a}}};e[or]=r,_t(r),Na()}}function Es(e,t){var r=Nn(e);r.value===(r.value=t??void 0)||e.value===t&&(t!==0||e.nodeName!==Ss)||(e.value=t??"")}function Cs(e,t){t?e.hasAttribute("selected")||e.setAttribute("selected",""):e.removeAttribute("selected")}function z(e,t,r,n){var a=Nn(e);R&&(a[t]=e.getAttribute(t),t==="src"||t==="srcset"||t==="href"&&e.nodeName===ws)||a[t]!==(a[t]=r)&&(t==="loading"&&(e[Xo]=r),r==null?e.removeAttribute(t):typeof r!="string"&&mo(e).includes(t)?e[t]=r:e.setAttribute(t,r))}function As(e,t,r,n,a=!1,i=!1){if(R&&a&&e.nodeName===_s){var s=e,l=s.type==="checkbox"?"defaultChecked":"defaultValue";l in r||Mn(s)}var u=Nn(e),c=u[vo],d=!u[po];let v=R&&c;v&&ot(!1);var h=t||{},m=e.nodeName===xs;for(var g in t)g in r||(r[g]=null);r.class?r.class=vs(r.class):r[wr]&&(r.class=null),r[_r]&&(r.style??=null);var x=mo(e);for(const F in r){let E=r[F];if(m&&F==="value"&&E==null){e.value=e.__value="",h[F]=E;continue}if(F==="class"){var T=e.namespaceURI==="http://www.w3.org/1999/xhtml";ms(e,T,E,n,t?.[wr],r[wr]),h[F]=E,h[wr]=r[wr];continue}if(F==="style"){bs(e,E,t?.[_r],r[_r]),h[F]=E,h[_r]=r[_r];continue}var M=h[F];if(!(E===M&&!(E===void 0&&e.hasAttribute(F)))){h[F]=E;var be=F[0]+F[1];if(be!=="$$")if(be==="on"){const Q={},Ce="$$"+F;let $=F.slice(2);var he=ts($);if(Qi($)&&($=$.slice(0,-7),Q.capture=!0),!he&&M){if(E!=null)continue;e.removeEventListener($,h[Ce],Q),h[Ce]=null}if(he)zr($,e,E),Hr([$]);else if(E!=null){let ve=function(ft){h[F].call(this,ft)};h[Ce]=ro($,e,ve,Q)}}else if(F==="style")z(e,F,E);else if(F==="autofocus")Di(e,!!E);else if(!c&&(F==="__value"||F==="value"&&E!=null))e.value=e.__value=E;else if(F==="selected"&&m)Cs(e,E);else{var U=F;d||(U=ns(U));var ke=U==="defaultValue"||U==="defaultChecked";if(E==null&&!c&&!ke)if(u[F]=null,U==="value"||U==="checked"){let Q=e;const Ce=t===void 0;if(U==="value"){let $=Q.defaultValue;Q.removeAttribute(U),Q.defaultValue=$,Q.value=Q.__value=Ce?$:null}else{let $=Q.defaultChecked;Q.removeAttribute(U),Q.defaultChecked=$,Q.checked=Ce?$:!1}}else e.removeAttribute(F);else ke||x.includes(U)&&(c||typeof E!="string")?(e[U]=E,U in u&&(u[U]=de)):typeof E!="function"&&z(e,U,E)}}}return v&&ot(!0),h}function Wr(e,t,r=[],n=[],a=[],i,s=!1,l=!1){Ta(a,r,n,u=>{var c=void 0,d={},v=e.nodeName===ks,h=!1;if(Ga(()=>{var g=t(...u.map(o)),x=As(e,c,g,i,s,l);h&&v&&"value"in g&&Ln(e,g.value);for(let M of Object.getOwnPropertySymbols(d))g[M]||we(d[M]);for(let M of Object.getOwnPropertySymbols(g)){var T=g[M];M.description===gi&&(!c||T!==c[M])&&(d[M]&&we(d[M]),d[M]=ct(()=>ds(e,()=>T))),x[M]=T}c=x}),v){var m=e;En(()=>{Ln(m,c.value,!0),ys(m)})}h=!0})}function Nn(e){return e[aa]??={[vo]:e.nodeName.includes("-"),[po]:e.namespaceURI===ua}}var go=new Map;function mo(e){var t=e.getAttribute("is")||e.nodeName,r=go.get(t);if(r)return r;go.set(t,r=[]);for(var n,a=e,i=Element.prototype;i!==a;){n=nn(a);for(var s in n)n[s].set&&s!=="innerHTML"&&s!=="textContent"&&s!=="innerText"&&r.push(s);a=Ir(a)}return r}function Ts(e,t,r=t){var n=new WeakSet;ji(e,"input",async a=>{var i=a?e.defaultValue:e.value;if(i=Dn(e)?jn(i):i,r(i),P!==null&&n.add(P),await Ht(),i!==(i=t())){var s=e.selectionStart,l=e.selectionEnd,u=e.value.length;if(e.value=i??"",l!==null){var c=e.value.length;s===l&&l===u&&c>u?(e.selectionStart=c,e.selectionEnd=c):(e.selectionStart=s,e.selectionEnd=Math.min(l,c))}}}),(R&&e.defaultValue!==e.value||gr(t)==null&&e.value)&&(r(Dn(e)?jn(e.value):e.value),P!==null&&n.add(P)),Br(()=>{var a=t();if(e===document.activeElement){var i=P;if(n.has(i))return}Dn(e)&&a===jn(e.value)||e.type==="date"&&!a&&!e.value||a!==e.value&&(e.value=a??"")})}function Dn(e){var t=e.type;return t==="number"||t==="range"}function jn(e){return e===""?null:+e}function Un(e,t){return e===t||e?.[At]===t}function It(e={},t,r,n){var a=Re.r,i=I;return En(()=>{var s,l;return Br(()=>{s=l,l=[],gr(()=>{Un(r(...l),e)||(t(e,...l),s&&Un(r(...s),e)&&t(null,...s))})}),()=>{let u=i;for(;u!==a&&u.parent!==null&&u.parent.f&je;)u=u.parent;const c=()=>{l&&Un(r(...l),e)&&t(null,...l)},d=u.teardown;u.teardown=()=>{c(),d?.()}}}),e}const Is={get(e,t){if(!e.exclude.includes(t))return e.props[t]},set(e,t){return!1},getOwnPropertyDescriptor(e,t){if(!e.exclude.includes(t)&&t in e.props)return{enumerable:!0,configurable:!0,value:e.props[t]}},has(e,t){return e.exclude.includes(t)?!1:t in e.props},ownKeys(e){return Reflect.ownKeys(e.props).filter(t=>!e.exclude.includes(t))}};function qr(e,t,r){return new Proxy({props:e,exclude:t},Is)}function ne(e,t,r,n){var a=n,i=!0,s=()=>(i&&(i=!1,a=n),a),l;l=e[t],l===void 0&&n!==void 0&&(l=s());var u;u=()=>{var h=e[t];return h===void 0?s():(i=!0,h)};var c=!1,d=xn(()=>(c=!1,u())),v=I;return(function(h,m){if(arguments.length>0){const g=m?o(d):h;return w(d,g),c=!0,a!==void 0&&(a=g),h}return Et&&c||(v.f&O)!==0?d.v:o(d)})}function $s(e){return new Rs(e)}class Rs{#e;#t;constructor(t){var r=new Map,n=(i,s)=>{var l=Oa(s,!1,!1);return r.set(i,l),l};const a=new Proxy({...t.props||{},$$events:{}},{get(i,s){return o(r.get(s)??n(s,Reflect.get(i,s)))},has(i,s){return s===Zo?!0:(o(r.get(s)??n(s,Reflect.get(i,s))),Reflect.has(i,s))},set(i,s,l){return w(r.get(s)??n(s,l),l),Reflect.set(i,s,l)}});this.#t=(t.hydrate?is:io)(t.component,{target:t.target,anchor:t.anchor,props:a,context:t.context,intro:t.intro??!1,recover:t.recover,transformError:t.transformError}),(!t?.props?.$$host||t.sync===!1)&&q(),this.#e=a.$$events;for(const i of Object.keys(this.#t))i==="$set"||i==="$destroy"||i==="$on"||Lt(this,i,{get(){return this.#t[i]},set(s){this.#t[i]=s},enumerable:!0});this.#t.$set=i=>{Object.assign(a,i)},this.#t.$destroy=()=>{ss(this.#t)}}$set(t){this.#t.$set(t)}$on(t,r){this.#e[t]=this.#e[t]||[];const n=(...a)=>r.call(this,...a);return this.#e[t].push(n),()=>{this.#e[t]=this.#e[t].filter(a=>a!==n)}}$destroy(){this.#t.$destroy()}}let bo=class{};typeof HTMLElement=="function"&&(bo=class extends HTMLElement{$$ctor;$$s;$$c;$$cn=!1;$$d={};$$r=!1;$$p_d={};$$l={};$$l_u=new Map;$$me;$$shadowRoot=null;constructor(e,t,r){super(),this.$$ctor=e,this.$$s=t,r&&(this.$$shadowRoot=this.attachShadow(r))}addEventListener(e,t,r){if(this.$$l[e]=this.$$l[e]||[],this.$$l[e].push(t),this.$$c){const n=this.$$c.$on(e,t);this.$$l_u.set(t,n)}super.addEventListener(e,t,r)}removeEventListener(e,t,r){if(super.removeEventListener(e,t,r),this.$$c){const n=this.$$l_u.get(t);n&&(n(),this.$$l_u.delete(t))}}async connectedCallback(){if(this.$$cn=!0,!this.$$c){let e=function(n){return a=>{const i=hn("slot");n!=="default"&&(i.name=n),D(a,i)}};if(await Promise.resolve(),!this.$$cn||this.$$c)return;const t={},r=Ps(this);for(const n of this.$$s)n in r&&(n==="default"&&!this.$$d.children?(this.$$d.children=e(n),t.default=!0):t[n]=e(n));for(const n of this.attributes){const a=this.$$g_p(n.name);a in this.$$d||(this.$$d[a]=Jr(a,n.value,this.$$p_d,"toProp"))}for(const n in this.$$p_d)!(n in this.$$d)&&this[n]!==void 0&&(this.$$d[n]=this[n],delete this[n]);this.$$c=$s({component:this.$$ctor,target:this.$$shadowRoot||this,props:{...this.$$d,$$slots:t,$$host:this}}),this.$$me=zi(()=>{Br(()=>{this.$$r=!0;for(const n of Ot(this.$$c)){if(!this.$$p_d[n]?.reflect)continue;this.$$d[n]=this.$$c[n];const a=Jr(n,this.$$d[n],this.$$p_d,"toAttribute");a==null?this.removeAttribute(this.$$p_d[n].attribute||n):this.setAttribute(this.$$p_d[n].attribute||n,a)}this.$$r=!1})});for(const n in this.$$l)for(const a of this.$$l[n]){const i=this.$$c.$on(n,a);this.$$l_u.set(a,i)}this.$$l={}}}attributeChangedCallback(e,t,r){this.$$r||(e=this.$$g_p(e),this.$$d[e]=Jr(e,r,this.$$p_d,"toProp"),this.$$c?.$set({[e]:this.$$d[e]}))}disconnectedCallback(){this.$$cn=!1,Promise.resolve().then(()=>{!this.$$cn&&this.$$c&&(this.$$c.$destroy(),this.$$me(),this.$$c=void 0)})}$$g_p(e){return Ot(this.$$p_d).find(t=>this.$$p_d[t].attribute===e||!this.$$p_d[t].attribute&&t.toLowerCase()===e)||e}});function Jr(e,t,r,n){const a=r[e]?.type;if(t=a==="Boolean"&&typeof t!="boolean"?t!=null:t,!n||!r[e])return t;if(n==="toAttribute")switch(a){case"Object":case"Array":return t==null?null:JSON.stringify(t);case"Boolean":return t?"":null;case"Number":return t??null;default:return t}else switch(a){case"Object":case"Array":return t&&JSON.parse(t);case"Boolean":return t;case"Number":return t!=null?+t:t;default:return t}}function Ps(e){const t={};return e.childNodes.forEach(r=>{t[r.slot||"default"]=!0}),t}function $t(e,t,r,n,a,i){let s=class extends bo{constructor(){super(e,r,a),this.$$p_d=t}static get observedAttributes(){return Ot(t).map(l=>(t[l].attribute||l).toLowerCase())}};return Ot(t).forEach(l=>{Lt(s.prototype,l,{get(){return this.$$c&&l in this.$$c?this.$$c[l]:this.$$d[l]},set(u){u=Jr(l,u,t),this.$$d[l]=u;var c=this.$$c;if(c){var d=pt(c,l)?.get;d?c[l]=u:c.$set({[l]:u})}}})}),n.forEach(l=>{Lt(s.prototype,l,{get(){return this.$$c?.[l]}})}),e.element=s,s}var Os=re('<div class="altcha-checkbox"><input/> <svg aria-hidden="true" width="12" height="9" viewBox="0 0 12 9"><polyline points="1 5 4 8 11 1"></polyline></svg> <div class="altcha-spinner altcha-checkbox-spinner" aria-hidden="true"></div></div>');function yo(e,t){yt(t,!0);let r=ne(t,"loading"),n=qr(t,["$$slots","$$events","$$legacy","$$host","loading"]),a;function i(){a?.click()}var s={get loading(){return r()},set loading(d){r(d),q()}},l=Os(),u=ae(l);Wr(u,()=>({type:"checkbox",...n}),void 0,void 0,void 0,void 0,!0),It(u,d=>a=d,()=>a);var c=te(u,2);return cn(2),X(l),xe(()=>z(l,"data-loading",r())),zr("click",c,i),D(e,l),wt(s)}Hr(["click"]),$t(yo,{loading:{}},[],[],{mode:"open"});var Ls=re('<div class="altcha-checkbox-native"><input/> <div class="altcha-spinner altcha-checkbox-native-spinner"></div></div>');function wo(e,t){yt(t,!0);let r=ne(t,"loading"),n=qr(t,["$$slots","$$events","$$legacy","$$host","loading"]);var a={get loading(){return r()},set loading(l){r(l),q()}},i=Ls(),s=ae(i);return Wr(s,()=>({type:"checkbox",...n}),void 0,void 0,void 0,void 0,!0),cn(2),X(i),xe(()=>z(i,"data-loading",r())),D(e,i),wt(a)}$t(wo,{loading:{}},[],[],{mode:"open"});var Ms=re('<div><a target="_blank" class="altcha-logo" aria-hidden="true" tabindex="-1"><svg width="22" height="22" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.33955 16.4279C5.88954 20.6586 12.1971 21.2105 16.4279 17.6604C18.4699 15.947 19.6548 13.5911 19.9352 11.1365L17.9886 10.4279C17.8738 12.5624 16.909 14.6459 15.1423 16.1284C11.7577 18.9684 6.71167 18.5269 3.87164 15.1423C1.03163 11.7577 1.4731 6.71166 4.8577 3.87164C8.24231 1.03162 13.2883 1.4731 16.1284 4.8577C16.9767 5.86872 17.5322 7.02798 17.804 8.2324L19.9522 9.01429C19.7622 7.07737 19.0059 5.17558 17.6604 3.57212C14.1104 -0.658624 7.80283 -1.21043 3.57212 2.33956C-0.658625 5.88958 -1.21046 12.1971 2.33955 16.4279Z" fill="currentColor"></path><path d="M3.57212 2.33956C1.65755 3.94607 0.496389 6.11731 0.12782 8.40523L2.04639 9.13961C2.26047 7.15832 3.21057 5.25375 4.8577 3.87164C8.24231 1.03162 13.2883 1.4731 16.1284 4.8577L13.8302 6.78606L19.9633 9.13364C19.7929 7.15555 19.0335 5.20847 17.6604 3.57212C14.1104 -0.658624 7.80283 -1.21043 3.57212 2.33956Z" fill="currentColor"></path><path d="M7 10H5C5 12.7614 7.23858 15 10 15C12.7614 15 15 12.7614 15 10H13C13 11.6569 11.6569 13 10 13C8.3431 13 7 11.6569 7 10Z" fill="currentColor"></path></svg></a></div>');function Fn(e,t){yt(t,!0);let r=ne(t,"strings");const n="https://altcha.org";var a={get strings(){return r()},set strings(l){r(l),q()}},i=Ms(),s=ae(i);return z(s,"href",n),X(i),xe(()=>z(s,"aria-label",r().ariaLinkLabel)),D(e,i),wt(a)}$t(Fn,{strings:{}},[],[],{mode:"open"});var Ns=re('<div class="altcha-footer"><p></p> <!></div>');function Vn(e,t){yt(t,!0);let r=ne(t,"logo"),n=ne(t,"strings");var a={get logo(){return r()},set logo(c){r(c),q()},get strings(){return n()},set strings(c){n(c),q()}},i=Ns(),s=ae(i);lo(s,()=>n().footer,!0),X(s);var l=te(s,2);{var u=c=>{Fn(c,{get strings(){return n()}})};me(l,c=>{r()&&c(u)})}return X(i),D(e,i),wt(a)}$t(Vn,{logo:{},strings:{}},[],[],{mode:"open"});var Ds=re('<div class="altcha-switch"><input/>  <div class="altcha-switch-toggle"><div class="altcha-spinner altcha-switch-spinner"></div></div></div>');function _o(e,t){yt(t,!0);let r=ne(t,"loading"),n=qr(t,["$$slots","$$events","$$legacy","$$host","loading"]),a;function i(){a?.click()}var s={get loading(){return r()},set loading(d){r(d),q()}},l=Ds(),u=ae(l);Wr(u,()=>({type:"checkbox",...n}),void 0,void 0,void 0,void 0,!0),It(u,d=>a=d,()=>a);var c=te(u,2);return X(l),xe(()=>z(l,"data-loading",r())),zr("click",c,i),D(e,l),wt(s)}Hr(["click"]),$t(_o,{loading:{}},[],[],{mode:"open"});var _e=(e=>(e.ERROR="error",e.LOADING="loading",e.PLAYING="playing",e.PAUSED="paused",e.READY="ready",e))(_e||{}),B=(e=>(e.CODE="code",e.ERROR="error",e.VERIFIED="verified",e.VERIFYING="verifying",e.UNVERIFIED="unverified",e.EXPIRED="expired",e))(B||{}),js=re('<div class="altcha-code-challenge-title"> </div>'),Us=re('<div class="altcha-spinner"></div>'),Fs=In('<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12.8659 3.00017L22.3922 19.5002C22.6684 19.9785 22.5045 20.5901 22.0262 20.8662C21.8742 20.954 21.7017 21.0002 21.5262 21.0002H2.47363C1.92135 21.0002 1.47363 20.5525 1.47363 20.0002C1.47363 19.8246 1.51984 19.6522 1.60761 19.5002L11.1339 3.00017C11.41 2.52187 12.0216 2.358 12.4999 2.63414C12.6519 2.72191 12.7782 2.84815 12.8659 3.00017ZM10.9999 16.0002V18.0002H12.9999V16.0002H10.9999ZM10.9999 9.00017V14.0002H12.9999V9.00017H10.9999Z"></path></svg>'),Vs=In('<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M15 7C15 6.44772 15.4477 6 16 6C16.5523 6 17 6.44772 17 7V17C17 17.5523 16.5523 18 16 18C15.4477 18 15 17.5523 15 17V7ZM7 7C7 6.44772 7.44772 6 8 6C8.55228 6 9 6.44772 9 7V17C9 17.5523 8.55228 18 8 18C7.44772 18 7 17.5523 7 17V7Z"></path></svg>'),Bs=In('<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M4 12H7C8.10457 12 9 12.8954 9 14V19C9 20.1046 8.10457 21 7 21H4C2.89543 21 2 20.1046 2 19V12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12V19C22 20.1046 21.1046 21 20 21H17C15.8954 21 15 20.1046 15 19V14C15 12.8954 15.8954 12 17 12H20C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12Z"></path></svg>'),zs=re('<button type="button" class="altcha-button altcha-button-secondary"><!></button>'),Hs=re('<audio hidden="" autoplay=""></audio>'),Ks=re('<div class="altcha-code-challenge"><form data-code-challenge="true"><!> <div class="altcha-code-challenge-text"> </div> <img class="altcha-code-challenge-image" alt=""/> <div class="altcha-code-challenge-row"><input type="text" class="altcha-input" autocomplete="off" name="" required=""/> <!> <button type="button" class="altcha-button altcha-button-secondary"><svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2V4C16.4183 4 20 7.58172 20 12C20 16.4183 16.4183 20 12 20C7.58172 20 4 16.4183 4 12C4 9.25022 5.38734 6.82447 7.50024 5.38451L7.5 8H9.5V2L3.5 2V4L5.99918 3.99989C3.57075 5.82434 2 8.72873 2 12Z"></path></svg></button></div> <div class="altcha-code-challenge-buttons"><button type="submit" class="altcha-button"> </button> <button type="button" class="altcha-button altcha-button-secondary"> </button></div></form> <!></div>');function xo(e,t){yt(t,!0);let r=ne(t,"audioUrl"),n=ne(t,"codeChallenge"),a=ne(t,"config"),i=ne(t,"imageUrl"),s=ne(t,"onCancel"),l=ne(t,"onReload"),u=ne(t,"onSubmit"),c=ne(t,"strings"),d=L(void 0),v=L(void 0),h=L(void 0),m=L(!1),g=L(""),x=L(!1);Rn(()=>(a().disableAutoFocus||Ht().then(()=>{o(h)?.focus()}),()=>{o(v)&&(o(v).pause(),w(v,void 0))}));function T(){w(d,_e.PAUSED,!0)}function M(y){w(d,_e.ERROR,!0)}function be(){w(d,_e.READY,!0)}function he(){w(d,_e.LOADING,!0)}function U(){w(d,_e.PLAYING,!0)}function ke(){w(d,_e.PAUSED,!0)}function F(y){y.code==="Space"?(y.preventDefault(),y.stopPropagation(),Q()):y.code==="Escape"&&(y.preventDefault(),y.stopPropagation(),s()?.())}function E(y){y.preventDefault(),y.stopPropagation(),u()?.(o(g))}function Q(){o(v)?o(d)===_e.LOADING||(o(v).paused?(r()&&o(v).src!==r()&&(o(v).src=r()),o(v).currentTime=0,o(v).play()):o(v).pause()):(w(x,!0),requestAnimationFrame(()=>{o(v)&&r()&&(o(v).src=r(),o(v).play())}))}var Ce={get audioUrl(){return r()},set audioUrl(y){r(y),q()},get codeChallenge(){return n()},set codeChallenge(y){n(y),q()},get config(){return a()},set config(y){a(y),q()},get imageUrl(){return i()},set imageUrl(y){i(y),q()},get onCancel(){return s()},set onCancel(y){s(y),q()},get onReload(){return l()},set onReload(y){l(y),q()},get onSubmit(){return u()},set onSubmit(y){u(y),q()},get strings(){return c()},set strings(y){c(y),q()}},$=Ks(),ve=ae($),ft=ae(ve);{var Be=y=>{var le=js(),Gt=ae(le,!0);X(le),xe(()=>ut(Gt,c().verificationRequired)),D(y,le)};me(ft,y=>{a().codeChallengeDisplay!=="standard"&&y(Be)})}var Le=te(ft,2),oe=ae(Le,!0);X(Le);var dt=te(Le,2),S=te(dt,2),G=ae(S);Mn(G),G.disabled=o(m),It(G,y=>w(h,y),()=>o(h));var ze=te(G,2);{var b=y=>{var le=zs(),Gt=ae(le);{var Yn=Me=>{var ht=Us();D(Me,ht)},Er=Me=>{var ht=Fs();D(Me,ht)},Gn=Me=>{var ht=Vs();D(Me,ht)},Wn=Me=>{var ht=Bs();D(Me,ht)};me(Gt,Me=>{o(d)===_e.LOADING?Me(Yn):o(d)===_e.ERROR?Me(Er,1):o(d)===_e.PLAYING?Me(Gn,2):Me(Wn,-1)})}X(le),xe(()=>{z(le,"title",c().getAudioChallenge),le.disabled=o(d)===_e.LOADING||o(d)===_e.ERROR,z(le,"aria-label",o(d)===_e.LOADING?c().loading:c().getAudioChallenge)}),ge("click",le,()=>Q(),!0),D(y,le)};me(ze,y=>{n().audio&&y(b)})}var Kt=te(ze,2);X(S);var Zr=te(S,2),qe=ae(Zr),Kn=ae(qe,!0);X(qe);var Yt=te(qe,2),xr=ae(Yt,!0);X(Yt),X(Zr),X(ve);var kr=te(ve,2);{var Sr=y=>{var le=Hs();It(le,Gt=>w(v,Gt),()=>o(v)),ge("error",le,M),ge("loadstart",le,he),ge("canplay",le,be),ge("pause",le,ke),ge("playing",le,U),ge("ended",le,T),D(y,le)};me(kr,y=>{o(x)&&y(Sr)})}return X($),xe(()=>{ut(oe,c().enterCodeFromImage),z(dt,"src",i()),z(G,"minlength",n().length||1),z(G,"maxlength",n().length),z(G,"placeholder",c().enterCode),z(G,"aria-label",o(d)===_e.LOADING?c().loading:o(d)===_e.PLAYING?"":c().enterCodeAria),z(G,"aria-live",o(d)?"assertive":"polite"),z(G,"aria-busy",o(d)===_e.LOADING),z(Kt,"title",c().reload),z(Kt,"aria-label",c().reload),z(qe,"aria-label",c().verify),ut(Kn,c().verify),z(Yt,"aria-label",c().cancel),ut(xr,c().cancel)}),ge("submit",ve,E,!0),zr("keydown",G,F),Ts(G,()=>o(g),y=>w(g,y)),ge("click",Kt,()=>l()?.(),!0),ge("click",Yt,()=>s()?.(),!0),D(e,$),wt(Ce)}Hr(["keydown"]),$t(xo,{audioUrl:{},codeChallenge:{},config:{},imageUrl:{},onCancel:{},onReload:{},onSubmit:{},strings:{}},[],[],{mode:"open"});var Ys=re('<div class="altcha-popover-backdrop" data-backdrop=""></div>'),Gs=re('<div class="altcha-popover-arrow"></div>'),Ws=re('<div role="button" class="altcha-popover-close">&times;</div>'),qs=re('<!> <div><!> <!> <div class="altcha-popover-content"><!></div></div>',1);function Bn(e,t){yt(t,!0);let r=ne(t,"anchor"),n=ne(t,"children"),a=ne(t,"display",7,"standard"),i=ne(t,"backdrop",7,!1),s=ne(t,"onClickOutside"),l=ne(t,"onClickOutsideDelay",7,600),u=ne(t,"onClose"),c=ne(t,"placement",7,"auto"),d=ne(t,"updateUISignal"),v=ne(t,"variant",7,"neutral"),h=qr(t,["$$slots","$$events","$$legacy","$$host","anchor","children","display","backdrop","onClickOutside","onClickOutsideDelay","onClose","placement","updateUISignal","variant"]),m=L(void 0),g=L(void 0),x=L(!1),T=L(0);Oe(()=>{c()!=="auto"&&w(x,c()==="top")}),Oe(()=>{d()&&ke()}),Rn(()=>{const S=a()==="bottomsheet"||a()==="overlay";return S&&(o(g)&&document.body.append(o(g)),o(m)&&document.body.append(o(m))),ke(),Ht().then(()=>{w(T,Date.now(),!0)}),()=>{S&&(o(g)&&document.body.removeChild(o(g)),o(m)&&document.body.removeChild(o(m)))}});function M(){u()?.()}function be(S){const G=S.target;!o(m)?.contains(G)&&(!l()||o(T)+l()<Date.now())&&s()?.()}function he(){ke()}function U(){ke()}function ke(){if(r()&&c()==="auto"&&o(m)){const S=r().getBoundingClientRect(),ze=document.documentElement.clientHeight-(S.top+S.height)<o(m).clientHeight;o(x)!==ze&&w(x,ze)}}var F={get anchor(){return r()},set anchor(S){r(S),q()},get children(){return n()},set children(S){n(S),q()},get display(){return a()},set display(S="standard"){a(S),q()},get backdrop(){return i()},set backdrop(S=!1){i(S),q()},get onClickOutside(){return s()},set onClickOutside(S){s(S),q()},get onClickOutsideDelay(){return l()},set onClickOutsideDelay(S=600){l(S),q()},get onClose(){return u()},set onClose(S){u(S),q()},get placement(){return c()},set placement(S="auto"){c(S),q()},get updateUISignal(){return d()},set updateUISignal(S){d(S),q()},get variant(){return v()},set variant(S="neutral"){v(S),q()}},E=qs();ge("click",Ft,be,!0),ge("resize",Ft,he),ge("scroll",Ft,U);var Q=Jt(E);{var Ce=S=>{var G=Ys();It(G,ze=>w(g,ze),()=>o(g)),D(S,G)};me(Q,S=>{i()&&S(Ce)})}var $=te(Q,2);Wr($,()=>({...h,class:`altcha-popover ${(t.class||"")??""}`,"data-popover":!0,"data-variant":v(),"data-top":o(x),"data-display":a()}));var ve=ae($);{var ft=S=>{var G=Gs();D(S,G)};me(ve,S=>{a()==="standard"&&S(ft)})}var Be=te(ve,2);{var Le=S=>{var G=Ws();ge("click",G,M,!0),D(S,G)};me(Be,S=>{a()!=="standard"&&S(Le)})}var oe=te(Be,2),dt=ae(oe);return ls(dt,()=>n()??nt),X(oe),X($),It($,S=>w(m,S),()=>o(m)),D(e,E),wt(F)}$t(Bn,{anchor:{},children:{},display:{},backdrop:{},onClickOutside:{},onClickOutsideDelay:{},onClose:{},placement:{},updateUISignal:{},variant:{}},[],[],{mode:"open"});function Js(e){return Array.from(new Uint8Array(e)).map(t=>t.toString(16).padStart(2,"0")).join("")}function Zs(e,t="altcha-css",r){if(typeof document<"u"&&document&&!document.getElementById(t)){const n=document.createElement("style");n.id=t,n.textContent=e;const a=document.currentScript?.nonce??document.querySelector('meta[name="csp-nonce"]')?.content;a&&(n.nonce=a),document.head.appendChild(n)}}async function ko(e){const{challenge:t,concurrency:r=navigator.hardwareConcurrency,controller:n=new AbortController,createWorker:a,onOutOfMemory:i=h=>h>1?Math.floor(h/2):0,counterMode:s,timeout:l=9e4}=e,u=Math.min(16,Math.max(1,r)),c=[],d=()=>{for(const h of c)h.terminate()};for(let h=0;h<u;h++)c.push(await a(t.parameters.algorithm));let v=null;try{v=await Promise.race(c.map((h,m)=>(n.signal.addEventListener("abort",()=>{h.postMessage({type:"abort"})}),new Promise((g,x)=>{h.addEventListener("error",T=>{x(T)}),h.addEventListener("message",T=>{if(T.data){for(const M of c)M!==h&&M.postMessage({type:"abort"});if(T.data.error)return x(new Error(T.data.error))}g(T.data)}),h.postMessage({challenge:t,counterMode:s,counterStart:m,counterStep:u,timeout:l,type:"work"})}))))}catch(h){if(h instanceof Error&&!!h?.message?.includes("Out of memory")&&i){d();const g=i(u);if(g)return ko({...e,challenge:t,controller:n,concurrency:g,createWorker:a})}throw h}finally{d()}return n.signal.aborted?null:v||null}class Xs{TAG_CODES={INPUT:1,TEXTAREA:2,SELECT:3,BUTTON:4,A:5,DETAILS:6,SUMMARY:7,IFRAME:8,VIDEO:9,AUDIO:10};maxSamples;sampleInterval;target;focusStartTime=0;focusInteraction=0;focusInteractionTimer=null;lastPointerSample=0;lastTouchSample=0;lastScrollSample=0;pendingPointer=null;pendingTouch=null;focus=[];pointer=[];scroll=[];touch=[];constructor(t={}){const{maxSamples:r=60,sampleInterval:n=50,target:a=window}=t;this.maxSamples=r,this.sampleInterval=n,this.target=a,this.attach()}destroy(){const t={capture:!0};this.target.removeEventListener("focusin",this.onFocus,t),this.target.removeEventListener("keydown",this.onInteraction,t),this.target.removeEventListener("pointerdown",this.onInteraction,t),this.target.removeEventListener("pointermove",this.onPointer,t),this.target.removeEventListener("scroll",this.onScroll,t),this.target.removeEventListener("touchmove",this.onTouchMove,t)}export(){return{focus:this.focus,maxTouchPoints:navigator.maxTouchPoints||0,pointer:this.pointer,scroll:this.scroll,time:Date.now(),touch:this.touch}}attach(){const t={passive:!0,capture:!0};this.target.addEventListener("focusin",this.onFocus,t),this.target.addEventListener("keydown",this.onInteraction,t),this.target.addEventListener("pointerdown",this.onInteraction,t),this.target.addEventListener("pointermove",this.onPointer,t),this.target.addEventListener("scroll",this.onScroll,t),this.target.addEventListener("touchmove",this.onTouchMove,t)}evict(t){t.length>this.maxSamples&&t.splice(0,t.length-this.maxSamples)}onFocus=t=>{if(this.focusInteraction===2)return;const r=t.target;if(!(r instanceof Element))return;const n=performance.now();this.focusStartTime===0&&(this.focusStartTime=n),this.focus.push([Math.round(n-this.focusStartTime),r.tabIndex,this.TAG_CODES[r.tagName]??0,this.focusInteraction?1:0]),this.evict(this.focus)};onInteraction=t=>{this.focusInteraction="keyCode"in t?1:2,this.focusInteractionTimer&&clearTimeout(this.focusInteractionTimer),this.focusInteractionTimer=setTimeout(()=>{this.focusInteraction=0},100)};onPointer=t=>{if(t.pointerType==="touch")return;const r=t.timeStamp||performance.now();this.pendingPointer=[Math.round(t.clientX),Math.round(t.clientY),Math.round(r)],r-this.lastPointerSample>=this.sampleInterval&&(this.pointer.push(this.pendingPointer),this.lastPointerSample=r,this.pendingPointer=null,this.evict(this.pointer))};onScroll=()=>{const t=performance.now();t-this.lastScrollSample<this.sampleInterval||(this.scroll.push([Math.round(window.scrollY),Math.round(t)]),this.lastScrollSample=t,this.evict(this.scroll))};onTouchMove=t=>{const r=t.timeStamp||performance.now(),n=t.touches[0];n&&(this.pendingTouch=[Math.round(n.clientX),Math.round(n.clientY),Math.round(r),Math.round(n.force*1e3)/1e3,Math.round(n.radiusX||0),Math.round(n.radiusY||0)],r-this.lastTouchSample>=this.sampleInterval&&(this.touch.push(this.pendingTouch),this.lastTouchSample=r,this.pendingTouch=null,this.evict(this.touch)))}}var Qs=re('<div class="altcha-overlay-backdrop" data-backdrop=""></div>'),el=re('<div class="altcha-overlay-content"></div>'),tl=re('<div role="button" class="altcha-overlay-close">&times;</div> <!>',1),rl=re('<div class="altcha-floating-arrow"></div>'),nl=re('<input type="hidden"/>'),al=re('<div class="altcha-error">Secure context (HTTPS) required.</div>'),ol=re('<div class="altcha-error"> </div>'),il=re('<div class="altcha-error"> </div>'),sl=re("<!> <!>",1),ll=re('<!> <div class="altcha"><!> <div class="altcha-main"><div><div class="altcha-checkbox-wrap"><!> <label><!></label></div> <!></div> <!> <!> <!></div> <!></div>',1);function cl(e,t){yt(t,!0);const r=()=>xa(d,"$altchaDefaults",a),n=()=>xa(g,"$altchaI18nStore",a),[a,i]=Ei(),s='input[type="text"]:not([data-no-spamfilter]), textarea:not([data-no-spamfilter])',l='input[type="submit"], button[type="submit"], button:not([type="button"]):not([type="reset"])',u=["ar","fa","he","ur"],{isSecureContext:c}=globalThis,{store:d}=globalThis.$altcha.defaults,v=navigator.hardwareConcurrency||2,h=navigator.deviceMemory||0,m=h&&h<=4?Math.min(4,v):v,g=globalThis.$altcha.i18n.store,x=t.$$host,T=(f,p)=>{Ht().then(()=>{x?.dispatchEvent(new CustomEvent(f,{detail:p}))})};let M=null,be=L(xt(new URL(location.origin))),he=L(!1),U=L(null),ke=L(null),F=L(null),E=L(xt(B.UNVERIFIED)),Q=L(void 0),Ce=L(void 0),$=L(null),ve=L(void 0),ft=L(null),Be=L(null),Le=L(null),oe=L(null),dt=L(xt([])),S=L(0),G=L(xt({})),ze=L(!0);const b=Ee(()=>({fetch:(f,p)=>fetch(f,p),audioChallengeLanguage:"",auto:"off",barPlacement:"bottom",challenge:"",codeChallenge:null,codeChallengeDisplay:"standard",credentials:null,debug:!1,disableAutoFocus:!1,display:"standard",floatingAnchor:"",floatingOffset:8,floatingPersist:!1,floatingPlacement:"auto",hideFooter:!1,hideLogo:!1,humanInteractionSignature:!0,language:"",mockError:!1,minDuration:500,overlayContent:"",name:"altcha",popoverPlacement:"auto",retryOnOutOfMemoryError:!0,setCookie:null,serverVerificationFields:!1,serverVerificationTimeZone:!1,test:!1,timeout:9e4,type:"checkbox",validationMessage:"",verifyFunction:null,verifyUrl:"",workers:m,...r(),...o(G)})),Kt=Ee(()=>`altcha-checkbox-${t.id||Math.floor(Math.random()*1e12).toString(16)}`),Zr=Ee(()=>dl(o(b).type)),qe=Ee(()=>o(b).auto),Kn=Ee(()=>o(E)===B.VERIFYING),Yt=Ee(()=>!o(b).hideFooter),xr=Ee(()=>!o(b).hideLogo&&o(b).display!=="bar"),kr=Ee(()=>hl(n(),[o(b).language,document.documentElement.lang,...navigator.languages])),Sr=Ee(()=>u.includes(o(kr).language)?"rtl":void 0),y=Ee(()=>({...o(kr).strings})),le=Ee(()=>o(U)?.audio?.match(/^(https?:)?\//)?Xr(o(U).audio,o(be),{language:o(b).audioChallengeLanguage||o(kr).language}).toString():o(U)?.audio),Gt=Ee(()=>o(U)?.image?.match(/^(https?:)?\//)?Xr(o(U).image,o(be)):o(U)?.image);Oe(()=>{Cr({auto:t.auto,challenge:t.challenge,display:t.display,language:t.language,name:t.name,type:t.type,workers:t.workers})}),Oe(()=>{t.theme?x?.setAttribute("theme",t.theme):x?.removeAttribute("theme")}),Oe(()=>{if(t.configuration)try{Cr(JSON.parse(t.configuration))}catch{J("unable to parse the `configuration` attribute (JSON expected)")}}),Oe(()=>{o(F)!==o(b).display&&Qr(o(b).display)}),Oe(()=>{o(he)&&o(E)===B.VERIFYING&&w(he,!1)}),Oe(()=>{!o(he)&&o(E)===B.VERIFIED&&w(he,!0)}),Oe(()=>{if(!o(he)){const f=qn();f&&f.checked&&(f.checked=!1)}}),Oe(()=>{o(E)===B.VERIFIED&&qn()?.setCustomValidity("")}),Oe(()=>{if(o(qe)==="onload"){const f=setTimeout(()=>{tr()},1);return()=>{f&&clearTimeout(f)}}}),Oe(()=>{o(Be)&&J("error:",o(Be))}),Oe(()=>{o(oe)&&o(b).setCookie&&Al(o(oe),o(b).setCookie)}),Rn(()=>(J("mounted","3.2.2"),x&&globalThis.$altcha.instances.add(x),w($,o(ve)?.closest("form"),!0),o($)?.addEventListener("reset",$o),o($)?.addEventListener("submit",Ro,{capture:!0}),o($)?.addEventListener("focusin",Io),Yn(),o(b).humanInteractionSignature&&(J("human interaction signature enabled"),M=new Xs),T("load"),c||J("secure context (HTTPS) required"),()=>{Gn(),x&&globalThis.$altcha.instances.delete(x),o(Le)&&clearTimeout(o(Le)),o($)?.removeEventListener("reset",$o),o($)?.removeEventListener("submit",Ro,{capture:!0}),o($)?.removeEventListener("focusin",Io),M?.destroy()}));function Yn(){w(dt,[...globalThis.$altcha.plugins].map(f=>new f(x)),!0),J("activating plugins",o(dt).map(f=>f.constructor.name));for(const f of o(dt))f.activate()}async function Er(f,...p){let _;for(const k of o(dt))_=await k[f].call(k,...p);return _}function Gn(){for(const f of o(dt))f.destroy()}function Wn(f){const[p,_]=f.salt.split("?"),k={};if(_)try{Object.assign(k,Object.fromEntries(new URLSearchParams(_).entries()))}catch{}const A={codeChallenge:f.codeChallenge,parameters:{algorithm:f.algorithm,cost:1,data:k,expiresAt:k?.expires?parseInt(k.expires,10):void 0,keyLength:f.algorithm==="SHA-512"?64:f.algorithm==="SHA-384"?48:32,nonce:Js(new TextEncoder().encode(f.salt)),keyPrefix:f.challenge,salt:""},signature:f.signature};return Object.defineProperties(A,{_originalSalt:{enumerable:!1,value:f.salt,writable:!1},_version:{enumerable:!1,value:1,writable:!1}}),A}function Me(f,p){return{algorithm:f.parameters.algorithm,challenge:f.parameters.keyPrefix,number:p.counter,salt:"_originalSalt"in f?f._originalSalt:f.parameters.nonce,signature:f.signature,took:p.time||0}}async function ht(f){await new Promise(p=>setTimeout(p,f))}async function To(f=o(b).challenge,p){const _=await Er("onFetchChallenge",f);let k=null;if(_!==void 0)return _;if(typeof f=="string")if(f.startsWith("{")){J("parsing JSON challenge");try{k=JSON.parse(f)}catch{throw new Error("Unable to parse JSON challenge.")}}else{J("fetching challenge from",p?.method||"GET",f),w(be,new URL(f,location.origin),!0);const A=await o(b).fetch(f,{credentials:o(b).credentials||void 0,...p});await Oo(A);const C=A.headers.get("x-altcha-config");C&&Sl(C);const H=await A.json();if(H&&"his"in H&&H.his){if(J("requested HIS"),!M)throw new Error("Server requested HIS data but collector is disabled.");return To(Xr(H.his.url,o(be)),{body:JSON.stringify({his:M.export()}),headers:{"content-type":"application/json"},method:"POST"})}H&&"hisResult"in H&&H.hisResult&&J("HIS result",H.hisResult),k=H}else if(f&&typeof f=="object")try{k=JSON.parse(JSON.stringify(f))}catch{throw new Error("Unable to parse JSON challenge.")}if(ul(k)&&(k=Wn(k)),!fl(k))throw new Error("Challenge validation failed.");return k}function ul(f){return typeof f=="object"&&"challenge"in f}function fl(f){return!!f&&typeof f=="object"&&"parameters"in f&&!!f.parameters&&typeof f.parameters=="object"&&"algorithm"in f.parameters&&"nonce"in f.parameters&&"salt"in f.parameters&&"keyPrefix"in f.parameters}function qn(){return document.getElementById(o(Kt))}function dl(f){switch(f){case"checkbox":return yo;case"switch":return _o;default:return wo}}function hl(f,p){const _=Object.keys(f).map(A=>A.toLowerCase());let k=p.reduce((A,C)=>(C=C.toLowerCase(),A||(f[C]?C:null)||_.find(H=>C.split("-")[0]===H.split("-")[0])||null),null);return f[k||""]||(k="en"),{language:k,strings:f[k]}}function vl(f){switch(f){case"bar":return o(b).barPlacement||"bottom";case"floating":return o(b).floatingPlacement||"auto";default:return}}function pl(f){return[...o($)?.querySelectorAll(s)||[]].reduce((_,k)=>{const A=k.name,C=k.value;return A&&C&&(_[A]=/\n/.test(C)?C.replace(new RegExp("(?<!\\r)\\n","g"),`\r
`):C),_},{})}function gl(){try{return Intl.DateTimeFormat().resolvedOptions().timeZone}catch{}}function Xr(f,p,_){const k=new URL(f,p);if(k.search||(k.search=p.search),_)for(const A in _)_[A]!==void 0&&_[A]!==null&&k.searchParams.set(A,_[A]);return k.toString()}function ml(f){!o(he)&&f.currentTarget.checked?(f.preventDefault(),f.currentTarget.checked=!1,o(E)!==B.VERIFYING&&tr()):f.currentTarget.checked||(f.preventDefault(),Je())}function bl(f){o(E)===B.VERIFYING?f.currentTarget.setCustomValidity(o(y).waitAlert):o(b).validationMessage&&f.currentTarget.setCustomValidity(o(b).validationMessage)}function yl(){Qr(o(b).display),Je()}function wl(){en()}function _l(f){const p=f.target;o(b).display==="floating"&&p&&!x?.contains(p)&&!p.hasAttribute("data-backdrop")&&!p.closest("[data-popover]")&&o(E)!==B.VERIFIED&&!o(b).floatingPersist&&Jn()}function Io(f){o(qe)==="onfocus"&&o(E)===B.UNVERIFIED&&tr()}function $o(){Qr(o(b).display),Je()}function Ro(f){f.target?.getAttribute("data-code-challenge")!=="true"&&o(qe)==="onsubmit"&&o(E)===B.UNVERIFIED&&(f.preventDefault(),f.stopPropagation(),w(ft,f.submitter,!0),Zn(),tr().then(_=>{_&&!o(U)&&Ht().then(()=>{Po(o(ft))})}))}function xl(f){f.persisted&&(Qr(o(b).display),Je())}function kl(){en()}function Sl(f){try{const p=JSON.parse(f);p&&typeof p=="object"&&Cr({serverVerificationFields:p?.sentinel?.fields,serverVerificationTimeZone:p?.sentinel?.timeZone,verifyUrl:p.verifyurl,...p})}catch(p){J("unable to configure from x-altcha-config header",p)}}function El(f=20){if(!o(ve))return;const p=o(b).floatingPlacement;if(!o(Ce)&&(w(Ce,(o(b).floatingAnchor instanceof HTMLElement?o(b).floatingAnchor:o(b).floatingAnchor?document.querySelector(o(b).floatingAnchor):o($)?.querySelector(l))||o($),!0),!o(Ce))){J("unable to find floating anchor element");return}const _=parseInt(o(b).floatingOffset,10)||12,k=o(Ce).getBoundingClientRect(),A=o(ve).getBoundingClientRect(),C=document.documentElement.clientHeight,H=document.documentElement.clientWidth,He=!p||p==="auto"?k.bottom+A.height+_+f>C:p==="top",ee=Math.max(f,Math.min(H-f-A.width,k.left+k.width/2-A.width/2));if(o(ve).style.setProperty("--altcha-floating-left",`${ee}px`),o(ve).style.setProperty("--altcha-floating-top",He?`${k.top-(A.height+_)}px`:`${k.bottom+_}px`),o(ve).setAttribute("data-floating-position",He?"top":"bottom"),o(Q)){const pe=o(Q).getBoundingClientRect();o(Q).style.left=k.left-ee+k.width/2-pe.width/2+"px"}}async function Cl(f,p){const _=await Er("onRequestServerVerification",f,p);if(_!==void 0)return _;if(J("requesting server verification from",o(b).verifyUrl),!o(b).verifyUrl)throw new Error("Parameter verifyUrl must be set for server verification.");const k=await o(b).fetch(Xr(o(b).verifyUrl,o(be)),{body:JSON.stringify({code:p,fields:o(b).serverVerificationFields?pl():void 0,payload:f,timeZone:o(b).serverVerificationTimeZone?gl():void 0}),credentials:o(b).credentials||void 0,headers:{"Content-Type":"application/json"},method:"POST"});await Oo(k);const A=await k.json();return A&&typeof A=="object"&&"payload"in A&&A.payload&&T("serververification",A),A}function Po(f){o($)&&"requestSubmit"in o($)?o($).requestSubmit(f):o($)?.reportValidity()&&(f?f.click():o($).submit())}function Al(f,p={}){const{domain:_,name:k=o(b).name,maxAge:A,path:C,sameSite:H,secure:He}=p;let ee=`${encodeURIComponent(k)}=${encodeURIComponent(f)}`;_&&(ee+=`; Domain=${_}`),A!=null&&(ee+=`; Max-Age=${A}`),C&&(ee+=`; Path=${C}`),H&&(ee+=`; SameSite=${H}`),He&&(ee+="; Secure"),document.cookie=ee}function Qr(f){switch(f){case"bar":case"floating":case"overlay":Jn(),(!o(qe)||o(qe)==="off")&&(o(G).auto="onsubmit");break;case"standard":Zn()}o(F)!==f&&w(F,f,!0)}function Tl(f){o(Le)&&clearTimeout(o(Le));const p=()=>{o(E)!==B.UNVERIFIED?(w(he,!1),Ze(B.EXPIRED)):Je(),T("expired")},_=f*1e3-Date.now();_>=1?w(Le,setTimeout(p,_),!0):p()}async function Oo(f){if(f.status>=400){if(f.headers.get("content-type")?.includes("/json")){let _;try{_=await f.json()}catch{}if(_&&"error"in _)throw new Error(`Server responded with ${f.status} - ${_.error}`)}throw new Error(`Server responded with ${f.status}.`)}const p=f.headers.get("content-type");if(!p||!p.includes("/json"))throw new Error(`Server responded with invalid content-type. Expected application/json, received ${p}.`)}async function Lo(f){if(!o(oe)){Ze(B.ERROR,"Cannot verify code challenge without PoW payload.");return}Ze(B.VERIFYING);let p=null;if(o(b).verifyUrl)p=await Cl(o(oe),f);else if(o(b).verifyFunction)p=await o(b).verifyFunction(o(oe),f);else{Ze(B.ERROR,"Parameter verifyUrl is required for code challenge verification.");return}p?.payload&&(w(oe,p.payload,!0),J("server payload",o(oe))),p?.verified===!0?(J("verified"),Ze(B.VERIFIED),T("verified",{payload:o(oe)}),o(qe)==="onsubmit"&&Ht().then(()=>{Po(o(ft))})):Ze(B.ERROR,p?.reason||"Verification failed."),o(b).disableAutoFocus||qn()?.focus()}function Cr(f){Object.assign(o(G),{...Object.fromEntries(Object.entries(f).filter(([p,_])=>_!==void 0))})}function Il(){return{...o(b)}}function $l(){return o(E)}function Jn(){w(ze,!1)}function J(...f){(o(b).debug||f.some(p=>p instanceof Error))&&console[f[0]instanceof Error?"error":"log"]("ALTCHA",`[name=${o(b).name}]`,...f)}function Je(f=B.UNVERIFIED,p=null){w(he,!1),w(Be,p,!0),w(oe,null),o(ke)&&o(ke).abort(),o(Le)&&(clearTimeout(o(Le)),w(Le,null)),Ze(f)}function Ze(f,p=null){w(E,f,!0),w(Be,p,!0),T("statechange",{payload:o(oe),state:o(E)})}function Zn(){w(ze,!0),Ht().then(()=>{en()})}function en(){if(o(b).display==="floating")return El();w(S,o(S)+1)}async function tr(f={}){const{concurrency:p=Math.max(1,o(b).workers),controller:_=new AbortController,minDuration:k=o(b).minDuration}=f,A=performance.now();let C=null,H=null,He=!1;const ee=await Er("onVerify",f);if(ee!==void 0)return ee;Je(B.VERIFYING),w(ke,_,!0);try{if(!c)throw new Error("Secure context (HTTPS) required.");if(o(b).mockError)throw new Error("Mock error.");if(o(b).test)return J("running test mode with null challenge"),await ht(Math.max(0,k-(performance.now()-A))),o(ke)?.signal.aborted?(Je(),null):(w(oe,btoa(JSON.stringify({challenge:null,solution:null,test:!0})),!0),J("verified"),Ze(B.VERIFIED),T("verified",{payload:o(oe)}),{payload:o(oe)});if(C=await To(),!C)throw new Error("Failed to fetch challenge.");J("challenge",C),"configuration"in C&&(J("re-configuring from challenge",C.configuration),Cr(C.configuration)),C.parameters.expiresAt&&Tl(C.parameters.expiresAt),He="_version"in C&&C._version===1;const pe=globalThis.$altcha.algorithms.get(C.parameters.algorithm);if(!pe)throw new Error(`Unsupported algorithm ${C.parameters.algorithm}.`);if(H=await ko({challenge:C,concurrency:p,controller:_,createWorker:pe,counterMode:He?"string":"uint32",onOutOfMemory:Rt=>{if(J("out of memory error received"),T("outofmemory"),o(b).retryOnOutOfMemoryError&&Rt>1){const Pt=Math.floor(Rt/2);return J(`retrying with ${Pt} workers...`),Pt}},timeout:o(b).timeout}),o(ke)?.signal.aborted)return Je(),null;if(!H)throw new Error("Failed to find solution.");J("solution",H),await ht(Math.max(0,k-(performance.now()-A))),w(U,C.codeChallenge||o(b).codeChallenge||null,!0),He?w(oe,btoa(JSON.stringify(Me(C,H))),!0):w(oe,btoa(JSON.stringify({challenge:{parameters:C.parameters,signature:C.signature},solution:H})),!0),o(U)?(J("requesting code verification"),Ze(B.CODE),T("codechallenge",{codeChallenge:o(U)})):o(b).verifyUrl?await Lo():(J("verified"),Ze(B.VERIFIED),T("verified",{payload:o(oe)}))}catch(pe){return J("verification failed",pe),Ze(B.ERROR,String(pe)),null}finally{w(ke,null)}return{challenge:C,payload:o(oe),solution:H}}var Rl={configure:Cr,getConfiguration:Il,getState:$l,hide:Jn,log:J,reset:Je,setState:Ze,show:Zn,updateUI:en,verify:tr},Mo=ll();ge("scroll",fn,wl),ge("click",fn,_l),ge("pageshow",Ft,xl),ge("resize",Ft,kl);var No=Jt(Mo);{var Pl=f=>{var p=Qs();D(f,p)};me(No,f=>{o(b).display==="overlay"&&o(ze)&&f(Pl)})}var vt=te(No,2),Do=ae(vt);{var Ol=f=>{var p=tl(),_=Jt(p),k=te(_,2);{var A=C=>{var H=el();lo(H,()=>document.querySelector(o(b).overlayContent)?.innerHTML,!0),X(H),D(C,H)};me(k,C=>{o(b).overlayContent&&C(A)})}ge("click",_,yl,!0),D(f,p)};me(Do,f=>{o(b).display==="overlay"&&o(ze)&&f(Ol)})}var Xn=te(Do,2),Qn=ae(Xn),ea=ae(Qn),jo=ae(ea);{let f=Ee(()=>o(b).display==="standard"&&o(qe)!=="onsubmit"||o(E)===B.VERIFYING);fs(jo,()=>o(Zr),(p,_)=>{_(p,{get id(){return o(Kt)},name:"",get required(){return o(f)},get loading(){return o(Kn)},get checked(){return o(he)},onchange:ml,oninvalid:bl})})}var ta=te(jo,2),Ll=ae(ta);{var Ml=f=>{var p=Kr();xe(()=>ut(p,o(y).verificationRequired)),D(f,p)},Nl=f=>{var p=Kr();xe(()=>ut(p,o(y).verifying)),D(f,p)},Dl=f=>{var p=Kr();xe(()=>ut(p,o(y).verified)),D(f,p)},jl=f=>{var p=Kr();xe(()=>ut(p,o(y).label)),D(f,p)};me(Ll,f=>{o(E)===B.CODE&&o(U)?f(Ml):o(E)===B.VERIFYING?f(Nl,1):o(E)===B.VERIFIED?f(Dl,2):f(jl,-1)})}X(ta),X(ea);var Ul=te(ea,2);{var Fl=f=>{Fn(f,{get strings(){return o(y)}})};me(Ul,f=>{o(xr)&&f(Fl)})}X(Qn);var Uo=te(Qn,2);{var Vl=f=>{{let p=Ee(()=>o(b).display==="bar"&&o(xr));Vn(f,{get logo(){return o(p)},get strings(){return o(y)}})}};me(Uo,f=>{o(Yt)&&f(Vl)})}var Fo=te(Uo,2);{var Bl=f=>{var p=rl();It(p,_=>w(Q,_),()=>o(Q)),D(f,p)};me(Fo,f=>{o(b).display==="floating"&&f(Bl)})}var zl=te(Fo,2);{var Hl=f=>{var p=nl();Mn(p),xe(()=>{z(p,"name",o(b).name),Es(p,o(oe))}),D(f,p)};me(zl,f=>{o(b).setCookie||f(Hl)})}X(Xn);var Kl=te(Xn,2);{var Yl=f=>{Bn(f,{get anchor(){return o(ve)},onClickOutside:()=>{c&&Je()},get placement(){return o(b).popoverPlacement},role:"alert",variant:"error",get dir(){return o(Sr)},get updateUISignal(){return o(S)},children:(p,_)=>{var k=oo(),A=Jt(k);{var C=ee=>{var pe=al();D(ee,pe)},H=ee=>{var pe=ol(),Rt=ae(pe,!0);X(pe),xe(()=>ut(Rt,o(y).expired)),D(ee,pe)},He=ee=>{var pe=il(),Rt=ae(pe,!0);X(pe),xe(()=>{z(pe,"title",o(Be)),ut(Rt,o(y).error)}),D(ee,pe)};me(A,ee=>{!o(Be)&&!c?ee(C):!o(Be)&&o(E)===B.EXPIRED?ee(H,1):ee(He,-1)})}D(p,k)},$$slots:{default:!0}})},Gl=f=>{var p=oo(),_=Jt(p);us(_,()=>o(U),k=>{{let A=Ee(()=>o(b).codeChallengeDisplay!=="standard");Bn(k,{get anchor(){return o(ve)},get backdrop(){return o(A)},get display(){return o(b).codeChallengeDisplay},onClose:()=>{Je()},get placement(){return o(b).popoverPlacement},role:"dialog",get"aria-label"(){return o(y).verificationRequired},get dir(){return o(Sr)},get updateUISignal(){return o(S)},children:(C,H)=>{var He=sl(),ee=Jt(He);xo(ee,{get audioUrl(){return o(le)},get imageUrl(){return o(Gt)},onCancel:()=>Je(),onReload:()=>tr(),onSubmit:Pt=>Lo(Pt),get codeChallenge(){return o(U)},get config(){return o(b)},get strings(){return o(y)}});var pe=te(ee,2);{var Rt=Pt=>{Vn(Pt,{get logo(){return o(xr)},get strings(){return o(y)}})};me(pe,Pt=>{o(Yt)&&o(b).codeChallengeDisplay!=="standard"&&Pt(Rt)})}D(C,He)},$$slots:{default:!0}})}}),D(f,p)};me(Kl,f=>{o(Be)||o(E)===B.EXPIRED||!c?f(Yl):o(U)&&o(E)===B.CODE&&f(Gl,1)})}X(vt),It(vt,f=>w(ve,f),()=>o(ve)),xe(f=>{z(vt,"data-state",o(E)),z(vt,"data-display",o(b).display||void 0),z(vt,"data-placement",f),z(vt,"data-visible",o(ze)||void 0),z(vt,"dir",o(Sr)),z(ta,"for",o(Kt)),vt.dir=vt.dir},[()=>vl(o(b).display)]),D(e,Mo);var Wl=wt(Rl);return i(),Wl}typeof window<"u"&&window.customElements&&!customElements.get("altcha-widget")&&customElements.define("altcha-widget",$t(cl,{auto:{type:"String"},challenge:{type:"String"},configuration:{type:"String"},display:{type:"String"},language:{type:"String"},name:{type:"String"},theme:{type:"String"},type:{type:"String"},workers:{type:"Number"}},[],["configure","getConfiguration","getState","hide","log","reset","setState","show","updateUI","verify"]));const So=`(function() {
  "use strict";
  function bufferStartsWith(buffer, prefix) {
    if (prefix.length > buffer.length) {
      return false;
    }
    for (let i = 0; i < prefix.length; i++) {
      if (buffer[i] !== prefix[i]) {
        return false;
      }
    }
    return true;
  }
  function bufferToHex(buffer) {
    return Array.from(new Uint8Array(buffer)).map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  function concatBuffers(a, b) {
    const out = new Uint8Array(a.length + b.length);
    out.set(a, 0);
    out.set(b, a.length);
    return out;
  }
  function hexToBuffer(hex) {
    if (hex.length % 2 !== 0) {
      throw new Error(\`Hex string must have an even length. Got: \${hex}\`);
    }
    const buffer = new ArrayBuffer(hex.length / 2);
    const view = new DataView(buffer);
    for (let i = 0; i < hex.length; i += 2) {
      const byteString = hex.substring(i, i + 2);
      const byteValue = parseInt(byteString, 16);
      view.setUint8(i / 2, byteValue);
    }
    return new Uint8Array(buffer);
  }
  async function delay(ms) {
    await new Promise((resolve) => setTimeout(resolve, ms));
  }
  function timeDuration(start) {
    return Math.floor((performance.now() - start) * 10) / 10;
  }
  class PasswordBuffer {
    constructor(nonce, mode = "uint32") {
      this.nonce = nonce;
      this.mode = mode;
      this.buffer = new Uint8Array(this.nonce.length + this.COUNTER_BYTES);
      this.buffer.set(this.nonce, 0);
      this.dataView = new DataView(this.buffer.buffer);
    }
    nonce;
    mode;
    COUNTER_BYTES = 4;
    buffer;
    dataView;
    encoder = new TextEncoder();
    /**
     * Appends the counter to the nonce buffer.
     * In 'string' mode, encodes the counter as a UTF-8 string.
     * In 'uint32' mode, writes the counter as a big-endian 32-bit integer.
     */
    setCounter(n) {
      if (this.mode === "string") {
        return concatBuffers(this.nonce, this.encoder.encode(n.toString()));
      }
      this.dataView.setUint32(this.nonce.length, n, false);
      return this.buffer;
    }
  }
  async function solveChallenge(options) {
    const {
      challenge,
      controller,
      counterMode = "uint32",
      counterStart = 0,
      counterStep = 1,
      deriveKey: deriveKey2,
      timeout = 9e4
    } = options;
    const { nonce, keyPrefix, salt } = challenge.parameters;
    const nonceBuf = hexToBuffer(nonce);
    const saltBuf = hexToBuffer(salt);
    const keyPrefixBuf = keyPrefix.length % 2 === 0 ? hexToBuffer(keyPrefix) : null;
    const password = new PasswordBuffer(nonceBuf, counterMode);
    const start = performance.now();
    let counter = counterStart;
    let iterations = 0;
    let derivedKeyHex = "";
    let lastYield = start;
    while (true) {
      if (controller?.signal.aborted || timeout && iterations % 10 === 0 && performance.now() - start > timeout) {
        return null;
      }
      const { derivedKey } = await deriveKey2(
        challenge.parameters,
        saltBuf,
        password.setCounter(counter)
      );
      if (iterations % 10 === 0 && performance.now() - lastYield > 200) {
        await delay(0);
        lastYield = performance.now();
      }
      if (keyPrefixBuf ? bufferStartsWith(derivedKey, keyPrefixBuf) : bufferToHex(derivedKey).startsWith(keyPrefix)) {
        derivedKeyHex = bufferToHex(derivedKey);
        break;
      }
      counter = counter + counterStep;
      iterations = iterations + 1;
    }
    return {
      counter,
      derivedKey: derivedKeyHex,
      time: timeDuration(start)
    };
  }
  function handler(options) {
    const { deriveKey: deriveKey2 } = options;
    let controller = void 0;
    self.onmessage = async (message) => {
      const { challenge, counterMode, counterStart, counterStep, timeout, type } = message.data;
      if (type === "abort") {
        controller?.abort();
      } else if (type === "work") {
        controller = new AbortController();
        let solution;
        try {
          solution = await solveChallenge({
            challenge,
            controller,
            counterStart,
            counterStep,
            deriveKey: deriveKey2,
            counterMode,
            timeout
          });
        } catch (err) {
          return self.postMessage({ error: err });
        }
        self.postMessage(solution);
      }
    };
  }
  function getDigest(algorithm) {
    switch (algorithm) {
      case "PBKDF2/SHA-512":
        return "SHA-512";
      case "PBKDF2/SHA-384":
        return "SHA-384";
      case "PBKDF2/SHA-256":
      default:
        return "SHA-256";
    }
  }
  async function deriveKey(parameters, salt, password) {
    const { algorithm, cost, keyLength = 32 } = parameters;
    const passwordKey = await crypto.subtle.importKey(
      "raw",
      password,
      { name: "PBKDF2" },
      false,
      ["deriveKey"]
    );
    const derivedKey = await crypto.subtle.deriveKey(
      {
        name: "PBKDF2",
        salt,
        iterations: cost,
        hash: getDigest(algorithm)
      },
      passwordKey,
      { name: "AES-GCM", length: keyLength * 8 },
      true,
      ["encrypt"]
    );
    return {
      derivedKey: new Uint8Array(await crypto.subtle.exportKey("raw", derivedKey))
    };
  }
  handler({
    deriveKey
  });
})();
`,Eo=typeof self<"u"&&self.Blob&&new Blob(["(self.URL || self.webkitURL).revokeObjectURL(self.location.href);",So],{type:"text/javascript;charset=utf-8"});function zn(e){let t;try{if(t=Eo&&(self.URL||self.webkitURL).createObjectURL(Eo),!t)throw"";const r=new Worker(t,{name:e?.name});return r.addEventListener("error",()=>{(self.URL||self.webkitURL).revokeObjectURL(t)}),r}catch{return new Worker("data:text/javascript;charset=utf-8,"+encodeURIComponent(So),{name:e?.name})}}const Co=`(function() {
  "use strict";
  function bufferStartsWith(buffer, prefix) {
    if (prefix.length > buffer.length) {
      return false;
    }
    for (let i = 0; i < prefix.length; i++) {
      if (buffer[i] !== prefix[i]) {
        return false;
      }
    }
    return true;
  }
  function bufferToHex(buffer) {
    return Array.from(new Uint8Array(buffer)).map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  function concatBuffers(a, b) {
    const out = new Uint8Array(a.length + b.length);
    out.set(a, 0);
    out.set(b, a.length);
    return out;
  }
  function hexToBuffer(hex) {
    if (hex.length % 2 !== 0) {
      throw new Error(\`Hex string must have an even length. Got: \${hex}\`);
    }
    const buffer = new ArrayBuffer(hex.length / 2);
    const view = new DataView(buffer);
    for (let i = 0; i < hex.length; i += 2) {
      const byteString = hex.substring(i, i + 2);
      const byteValue = parseInt(byteString, 16);
      view.setUint8(i / 2, byteValue);
    }
    return new Uint8Array(buffer);
  }
  async function delay(ms) {
    await new Promise((resolve) => setTimeout(resolve, ms));
  }
  function timeDuration(start) {
    return Math.floor((performance.now() - start) * 10) / 10;
  }
  class PasswordBuffer {
    constructor(nonce, mode = "uint32") {
      this.nonce = nonce;
      this.mode = mode;
      this.buffer = new Uint8Array(this.nonce.length + this.COUNTER_BYTES);
      this.buffer.set(this.nonce, 0);
      this.dataView = new DataView(this.buffer.buffer);
    }
    nonce;
    mode;
    COUNTER_BYTES = 4;
    buffer;
    dataView;
    encoder = new TextEncoder();
    /**
     * Appends the counter to the nonce buffer.
     * In 'string' mode, encodes the counter as a UTF-8 string.
     * In 'uint32' mode, writes the counter as a big-endian 32-bit integer.
     */
    setCounter(n) {
      if (this.mode === "string") {
        return concatBuffers(this.nonce, this.encoder.encode(n.toString()));
      }
      this.dataView.setUint32(this.nonce.length, n, false);
      return this.buffer;
    }
  }
  async function solveChallenge(options) {
    const {
      challenge,
      controller,
      counterMode = "uint32",
      counterStart = 0,
      counterStep = 1,
      deriveKey: deriveKey2,
      timeout = 9e4
    } = options;
    const { nonce, keyPrefix, salt } = challenge.parameters;
    const nonceBuf = hexToBuffer(nonce);
    const saltBuf = hexToBuffer(salt);
    const keyPrefixBuf = keyPrefix.length % 2 === 0 ? hexToBuffer(keyPrefix) : null;
    const password = new PasswordBuffer(nonceBuf, counterMode);
    const start = performance.now();
    let counter = counterStart;
    let iterations = 0;
    let derivedKeyHex = "";
    let lastYield = start;
    while (true) {
      if (controller?.signal.aborted || timeout && iterations % 10 === 0 && performance.now() - start > timeout) {
        return null;
      }
      const { derivedKey } = await deriveKey2(
        challenge.parameters,
        saltBuf,
        password.setCounter(counter)
      );
      if (iterations % 10 === 0 && performance.now() - lastYield > 200) {
        await delay(0);
        lastYield = performance.now();
      }
      if (keyPrefixBuf ? bufferStartsWith(derivedKey, keyPrefixBuf) : bufferToHex(derivedKey).startsWith(keyPrefix)) {
        derivedKeyHex = bufferToHex(derivedKey);
        break;
      }
      counter = counter + counterStep;
      iterations = iterations + 1;
    }
    return {
      counter,
      derivedKey: derivedKeyHex,
      time: timeDuration(start)
    };
  }
  function handler(options) {
    const { deriveKey: deriveKey2 } = options;
    let controller = void 0;
    self.onmessage = async (message) => {
      const { challenge, counterMode, counterStart, counterStep, timeout, type } = message.data;
      if (type === "abort") {
        controller?.abort();
      } else if (type === "work") {
        controller = new AbortController();
        let solution;
        try {
          solution = await solveChallenge({
            challenge,
            controller,
            counterStart,
            counterStep,
            deriveKey: deriveKey2,
            counterMode,
            timeout
          });
        } catch (err) {
          return self.postMessage({ error: err });
        }
        self.postMessage(solution);
      }
    };
  }
  async function deriveKey(parameters, salt, password) {
    const { algorithm, keyLength = 32 } = parameters;
    const iterations = Math.max(1, parameters.cost);
    let data = void 0;
    let derivedKey = void 0;
    for (let i = 0; i < iterations; i++) {
      if (i === 0) {
        data = concatBuffers(salt, password);
      } else {
        data = derivedKey;
      }
      derivedKey = new Uint8Array(
        (await crypto.subtle.digest(algorithm, data)).slice(0, keyLength)
      );
    }
    return {
      parameters: {},
      derivedKey
    };
  }
  handler({
    deriveKey
  });
})();
`,Ao=typeof self<"u"&&self.Blob&&new Blob(["(self.URL || self.webkitURL).revokeObjectURL(self.location.href);",Co],{type:"text/javascript;charset=utf-8"});function Hn(e){let t;try{if(t=Ao&&(self.URL||self.webkitURL).createObjectURL(Ao),!t)throw"";const r=new Worker(t,{name:e?.name});return r.addEventListener("error",()=>{(self.URL||self.webkitURL).revokeObjectURL(t)}),r}catch{return new Worker("data:text/javascript;charset=utf-8,"+encodeURIComponent(Co),{name:e?.name})}}return Zs(`:root {
  --altcha-border-color: var(--altcha-color-neutral);
  --altcha-border-width: 1px;
  --altcha-border-radius: 6px;
  --altcha-color-base: light-dark(oklch(100% 0.00011 271.152), oklch(20.904% 0.00002 271.152));
  --altcha-color-base-content: light-dark(
  	oklch(20.904% 0.00002 271.152),
  	oklch(100% 0.00011 271.152)
  );
  --altcha-color-error: oklch(51.284% 0.20527 28.678);
  --altcha-color-error-content: oklch(100% 0.00011 271.152);
  --altcha-color-neutral: light-dark(oklch(83.591% 0.0001 271.152), oklch(46.04% 0.00005 271.152));
  --altcha-color-neutral-content: light-dark(
  	oklch(46.76% 0.00005 271.152),
  	oklch(100% 0.00011 271.152)
  );
  --altcha-color-primary: oklch(40.279% 0.2449 268.131);
  --altcha-color-primary-content: oklch(100% 0.00011 271.152);
  --altcha-color-success: oklch(55.748% 0.18968 142.511);
  --altcha-color-success-content: oklch(100% 0.00011 271.152);
  --altcha-checkbox-border-color: light-dark(
  	oklch(66.494% 0.00233 15.434),
  	oklch(51.028% 0.00006 271.152)
  );
  --altcha-checkbox-border-radius: 5px;
  --altcha-checkbox-border-width: var(--altcha-border-width);
  --altcha-checkbox-outline: 2px solid var(--altcha-checkbox-outline-color);
  --altcha-checkbox-outline-color: -webkit-focus-ring-color;
  --altcha-checkbox-outline-offset: 2px;
  --altcha-checkbox-size: 22px;
  --altcha-checkbox-transition-duration: var(--altcha-transition-duration);
  --altcha-input-background-color: var(--altcha-color-base);
  --altcha-input-border-radius: 3px;
  --altcha-input-border-width: 1px;
  --altcha-input-color: var(--altcha-color-base-content);
  --altcha-max-width: 320px;
  --altcha-padding: 0.75rem;
  --altcha-popover-arrow-size: 6px;
  --altcha-popover-color: var(--altcha-border-color);
  --altcha-shadow: drop-shadow(3px 3px 6px oklch(0% 0 0 / 0.2));
  --altcha-spinner-color: var(--altcha-color-base-content);
  --altcha-switch-background-color: var(--altcha-color-neutral);
  --altcha-switch-border-radius: calc(infinity * 1px);
  --altcha-switch-height: var(--altcha-checkbox-size);
  --altcha-switch-padding: 0.25rem;
  --altcha-switch-width: calc(var(--altcha-checkbox-size) * 1.75);
  --altcha-switch-toggle-border-radius: 100%;
  --altcha-switch-toggle-color: var(--altcha-color-neutral-content);
  --altcha-switch-toggle-size: calc(
  	var(--altcha-switch-height) - calc(var(--altcha-switch-padding) * 2)
  );
  --altcha-transition-duration: 0.6s;
  --altcha-z-index: 99999999;
  --altcha-z-index-popover: 999999999;
}

@supports (-moz-appearance: none) {
  :root {
    --altcha-checkbox-outline-color: var(--altcha-color-primary);
  }
}
.altcha {
  all: revert-layer;
  display: none;
  font-family: inherit;
  font-size: inherit;
  position: relative;
}
.altcha[data-visible] {
  display: block;
}
.altcha-popover, .altcha-popover * {
  all: revert-layer;
  box-sizing: border-box;
  font-family: inherit;
  font-size: inherit;
  line-height: 1.25;
}
.altcha * {
  all: revert-layer;
  box-sizing: border-box;
  font-family: inherit;
  font-size: inherit;
  line-height: 1.25;
}
.altcha a, .altcha-popover a {
  color: currentColor;
  text-decoration: none;
}
.altcha a:hover, .altcha-popover a:hover {
  color: currentColor;
}
.altcha-main {
  align-items: start;
  background-color: var(--altcha-color-base);
  border: var(--altcha-border-width, 1px) solid var(--altcha-border-color);
  border-radius: var(--altcha-border-radius, 0);
  color: var(--altcha-color-base-content);
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  justify-content: space-between;
  padding: var(--altcha-padding);
  max-width: var(--altcha-max-width, 100%);
}
.altcha-main > * {
  display: flex;
  width: 100%;
}
.altcha-main > *:first-child {
  flex-grow: 1;
}
.altcha-checkbox-wrap {
  align-items: center;
  display: flex;
  flex-direction: row;
  flex-grow: 1;
  gap: 0.5rem;
}
.altcha-checkbox-wrap > * {
  display: flex;
}
.altcha-logo {
  opacity: 0.7;
}
.altcha-footer {
  align-items: center;
  display: flex;
  flex-grow: 1;
  gap: 0.5rem;
  justify-content: flex-end;
  font-size: 0.7rem;
  opacity: 0.7;
}
.altcha-footer p {
  margin: 0;
  padding: 0;
}
.altcha-error {
  font-size: 0.85rem;
}
.altcha-button {
  align-items: center;
  background: var(--altcha-color-primary);
  border: var(--altcha-input-border-width) solid var(--altcha-color-primary);
  border-radius: var(--altcha-input-border-radius);
  color: var(--altcha-color-primary-content);
  cursor: pointer;
  display: flex;
  font-size: 0.9rem;
  gap: 0.5rem;
  padding: 0.35rem;
}
.altcha-button:focus {
  border-color: var(--altcha-color-primary);
  outline: var(--altcha-checkbox-outline);
  outline-offset: var(--altcha-checkbox-outline-offset);
}
.altcha-button > .altcha-spinner, .altcha-button > svg {
  height: 20px;
  width: 20px;
}
.altcha-button-secondary {
  background: transparent;
  border-color: var(--altcha-color-neutral);
  color: var(--altcha-color-neutral-content);
}
.altcha-input {
  background: var(--altcha-input-background-color);
  border: var(--altcha-input-border-width) solid var(--altcha-color-neutral);
  border-radius: var(--altcha-input-border-radius);
  color: var(--altcha-input-color);
  flex-grow: 1;
  font-size: 1rem;
  min-width: 0;
  padding: 0.25rem;
  width: auto;
}
.altcha-input:focus {
  border-color: var(--altcha-color-primary);
  outline: var(--altcha-checkbox-outline);
  outline-offset: var(--altcha-checkbox-outline-offset);
}
.altcha-spinner {
  animation: altcha-rotate 0.6s linear infinite;
  border-radius: 100%;
  border: var(--altcha-checkbox-border-width) solid var(--altcha-spinner-color);
  border-bottom-color: transparent;
  border-right-color: transparent;
  opacity: 0.7;
}
.altcha-popover {
  background-color: var(--altcha-color-base);
  border: var(--altcha-border-width) solid var(--altcha-border-color);
  border-radius: var(--altcha-border-radius);
  color: var(--altcha-color-base-content);
  filter: var(--altcha-shadow);
  position: absolute;
  left: calc(var(--altcha-padding) / 2);
  max-width: calc(var(--altcha-max-width) - var(--altcha-padding));
  top: calc(var(--altcha-padding) + var(--altcha-checkbox-size) + var(--altcha-popover-arrow-size));
  z-index: var(--altcha-z-index-popover);
}
.altcha-popover-arrow {
  border: var(--altcha-popover-arrow-size) solid transparent;
  border-bottom-color: var(--altcha-popover-color);
  content: "";
  height: 0;
  left: calc(var(--altcha-checkbox-size) / 2);
  position: absolute;
  top: calc(var(--altcha-popover-arrow-size) * -2);
  width: 0;
}
.altcha-popover-content {
  max-height: 100dvh;
  overflow: auto;
  padding: var(--altcha-padding);
}
.altcha-popover[data-top=true][data-display=standard] {
  bottom: calc(100% - (var(--altcha-padding) - var(--altcha-popover-arrow-size)));
  top: auto;
}
.altcha-popover[data-top=true][data-display=standard] .altcha-popover-arrow {
  border-bottom-color: transparent;
  border-top-color: var(--altcha-popover-color);
  bottom: calc(var(--altcha-popover-arrow-size) * -2);
  top: auto;
}
.altcha-popover[data-variant=error] {
  --altcha-popover-color: var(--altcha-color-error);
  background-color: var(--altcha-color-error);
  border-color: var(--altcha-color-error);
  color: var(--altcha-color-error-content);
}
.altcha-popover[data-variant=error] .altcha-popover-content {
  padding: calc(var(--altcha-padding) / 1.5) var(--altcha-padding);
}
.altcha-popover[data-display=overlay] {
  animation: altcha-overlay-slidein 0.5s forwards;
  left: 50%;
  position: fixed;
  top: 45%;
  transform: translate(-50%, -50%);
  width: var(--altcha-max-width);
  z-index: var(--altcha-z-index);
}
.altcha-popover[data-display=bottomsheet] {
  animation: altcha-bottomsheet-slideup 0.5s forwards;
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
  border-bottom: 0;
  bottom: -100%;
  left: 50%;
  position: fixed;
  top: auto;
  transform: translate(-50%, 0);
  width: var(--altcha-max-width);
  z-index: var(--altcha-z-index);
}
.altcha-popover[data-display=bottomsheet] .altcha-popover-content {
  padding-bottom: calc(var(--altcha-padding) * 2);
}
.altcha-popover-backdrop {
  background: var(--altcha-color-base-content);
  bottom: 0;
  left: 0;
  opacity: 0.1;
  position: fixed;
  right: 0;
  top: 0;
  transition: opacity 0.5s;
  z-index: var(--altcha-z-index);
}
.altcha-popover-close {
  color: var(--altcha-color-base-content);
  cursor: pointer;
  display: inline-block;
  font-size: 1rem;
  height: 1.25rem;
  line-height: 0.95;
  position: absolute;
  right: 0;
  text-align: center;
  text-shadow: 0 0 1px var(--altcha-color-base);
  top: -1.5rem;
  width: 1.25rem;
  z-index: var(--altcha-z-index);
}
[dir=rtl] .altcha-popover {
  left: auto;
  right: calc(var(--altcha-padding) / 2);
}
[dir=rtl] .altcha-popover-arrow {
  left: auto;
  right: calc(var(--altcha-checkbox-size) / 2);
}
[dir=rtl] .altcha-popover-close {
  left: 0;
  right: auto;
}
.altcha-popover[data-display=bottomsheet] .altcha-footer, .altcha-popover[data-display=overlay] .altcha-footer {
  align-items: center;
  justify-content: center;
  padding-top: 1rem;
  gap: 0.5rem;
}
.altcha-popover[data-display=bottomsheet] .altcha-footer svg, .altcha-popover[data-display=overlay] .altcha-footer svg {
  height: 18px;
  width: 18px;
  vertical-align: middle;
}
.altcha-code-challenge > form {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}
.altcha-code-challenge-title {
  font-weight: 600;
}
.altcha-code-challenge-text {
  font-size: 0.85rem;
}
.altcha-code-challenge-image {
  background: white;
  border: var(--altcha-input-border-width) solid var(--altcha-color-neutral);
  border-radius: var(--altcha-input-border-radius);
  object-fit: contain;
  height: 50px;
}
.altcha-code-challenge-row {
  display: flex;
  gap: 0.5rem;
}
.altcha-code-challenge-buttons {
  align-items: center;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  margin-top: var(--altcha-padding);
  justify-content: space-between;
}
.altcha-code-challenge-buttons button {
  justify-content: center;
  width: 100%;
}
.altcha-checkbox {
  cursor: pointer;
  height: var(--altcha-checkbox-size);
  position: relative;
  width: var(--altcha-checkbox-size);
}
.altcha-checkbox input {
  appearance: none;
  background: var(--altcha-input-background-color);
  border: var(--altcha-checkbox-border-width, 2px) solid var(--altcha-checkbox-border-color);
  border-radius: var(--altcha-checkbox-border-radius);
  cursor: pointer;
  height: var(--altcha-checkbox-size);
  left: 0;
  margin: 0;
  padding: 0;
  position: absolute;
  top: 0;
  width: var(--altcha-checkbox-size);
}
@supports (hanging-punctuation: first) and (font: -apple-system-body) and (-webkit-appearance: none) {
  .altcha-checkbox input {
    /* Safari-only: fixes focus outline */
  }
  .altcha-checkbox input:focus {
    outline-width: 2px;
    outline-style: solid;
  }
}
.altcha-checkbox input:before {
  border-radius: var(--altcha-checkbox-border-radius);
  content: "";
  width: 100%;
  height: 100%;
  background: var(--altcha-color-neutral);
  display: block;
  transform: scale(0);
}
.altcha-checkbox input:checked {
  background-color: var(--altcha-color-success);
  border-color: var(--altcha-color-success);
}
.altcha-checkbox input:checked::before {
  background-color: var(--altcha-color-success);
  opacity: 0;
  transform: scale(2.2);
  transition: all var(--altcha-checkbox-transition-duration) ease;
  transition-delay: 0.1s;
}
.altcha-checkbox svg {
  --altcha-radio-svg-size: calc(var(--altcha-checkbox-size) * 0.5);
  --altcha-radio-svg-offset: calc(var(--altcha-checkbox-size) * 0.25);
  fill: none;
  left: var(--altcha-radio-svg-offset);
  height: var(--altcha-radio-svg-size);
  opacity: 0;
  position: absolute;
  stroke: currentColor;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 16px;
  stroke-dashoffset: 16px;
  top: var(--altcha-radio-svg-offset);
  transform: translate3d(0, 0, 0);
  width: var(--altcha-radio-svg-size);
}
.altcha-checkbox input:checked + svg {
  color: var(--altcha-color-success-content);
  opacity: 1;
  stroke-dashoffset: 0;
  transition: all var(--altcha-checkbox-transition-duration) ease;
  transition-delay: 0.1s;
}
.altcha-checkbox-spinner {
  display: none;
  left: 0;
  height: var(--altcha-checkbox-size);
  position: absolute;
  top: 0;
  width: var(--altcha-checkbox-size);
}
.altcha-checkbox[data-loading=true] input {
  appearance: none;
  opacity: 0;
  pointer-events: none;
}
.altcha-checkbox[data-loading=true] .altcha-checkbox-spinner {
  display: block;
}
.altcha-checkbox-native {
  height: var(--altcha-checkbox-size);
  position: relative;
  width: var(--altcha-checkbox-size);
}
.altcha-checkbox-native input {
  height: var(--altcha-checkbox-size);
  margin: 0;
  width: var(--altcha-checkbox-size);
}
.altcha-checkbox-native-spinner {
  display: none;
  left: 0;
  height: var(--altcha-checkbox-size);
  position: absolute;
  top: 0;
  width: var(--altcha-checkbox-size);
}
.altcha-checkbox-native[data-loading=true] input {
  appearance: none;
  opacity: 0;
  pointer-events: none;
}
.altcha-checkbox-native[data-loading=true] .altcha-checkbox-native-spinner {
  display: block;
}
.altcha-switch {
  align-items: center;
  border-radius: var(--altcha-switch-border-radius);
  background-color: var(--altcha-switch-background-color);
  display: flex;
  height: var(--altcha-switch-height);
  padding: var(--altcha-switch-padding);
  position: relative;
  width: var(--altcha-switch-width);
}
.altcha-switch:focus-within {
  outline: var(--altcha-checkbox-outline);
  outline-offset: var(--altcha-checkbox-outline-offset);
}
.altcha-switch input {
  appearance: none;
  cursor: pointer;
  height: 100%;
  left: 0;
  opacity: 0;
  position: absolute;
  top: 0;
  width: 100%;
}
.altcha-switch-toggle {
  align-items: center;
  background-color: var(--altcha-switch-toggle-color);
  border-radius: var(--altcha-switch-toggle-border-radius);
  cursor: pointer;
  display: flex;
  height: var(--altcha-switch-toggle-size);
  justify-content: center;
  left: var(--altcha-switch-padding);
  position: absolute;
  transition: width 150ms ease-out, left 150ms ease-out;
  width: var(--altcha-switch-toggle-size);
}
.altcha-switch-spinner {
  display: none;
  height: var(--altcha-switch-toggle-size);
  width: var(--altcha-switch-toggle-size);
}
.altcha-switch[data-loading=true] {
  pointer-events: none;
}
.altcha-switch[data-loading=true] .altcha-switch-spinner {
  display: block;
}
.altcha-switch[data-loading=true] .altcha-switch-toggle {
  background-color: transparent;
  left: calc(50% - var(--altcha-switch-toggle-size) / 2);
}
[data-state=verified] .altcha-switch {
  --altcha-switch-background-color: var(--altcha-color-success);
}
[data-state=verified] .altcha-switch-toggle {
  background-color: var(--altcha-color-success-content);
  left: calc(100% - var(--altcha-switch-height) + var(--altcha-switch-padding));
}
[dir=rtl] .altcha-switch-toggle {
  left: calc(100% - var(--altcha-switch-height) + var(--altcha-switch-padding));
}
[dir=rtl][data-state=verified] .altcha-switch-toggle {
  left: var(--altcha-switch-padding);
}
.altcha-floating-arrow {
  border: 6px solid transparent;
  border-bottom-color: var(--altcha-border-color);
  content: "";
  height: 0;
  left: 12px;
  position: absolute;
  top: -12px;
  width: 0;
}
.altcha-overlay-backdrop {
  bottom: 0;
  left: 0;
  position: fixed;
  right: 0;
  top: 0;
  transition: opacity var(--altcha-transition-duration);
  z-index: var(--altcha-z-index);
}
.altcha-overlay-close {
  display: inline-block;
  color: currentColor;
  cursor: pointer;
  font-size: 1rem;
  height: 1rem;
  line-height: 0.85;
  position: absolute;
  right: 0;
  text-align: center;
  text-shadow: 0 0 1px var(--altcha-color-base);
  top: -1.5rem;
  width: 1rem;
  z-index: var(--altcha-z-index);
}
.altcha[data-display=overlay] {
  animation: altcha-overlay-slidein var(--altcha-transition-duration) forwards;
  filter: var(--altcha-shadow);
  left: 50%;
  opacity: 0;
  position: fixed;
  top: 45%;
  transform: translate(-50%, -50%);
  z-index: var(--altcha-z-index);
}
.altcha[data-display=overlay] .altcha-main {
  width: var(--altcha-max-width);
}
.altcha[data-display=floating] {
  display: none;
  filter: var(--altcha-shadow);
  left: var(--altcha-floating-left, -100%);
  position: fixed;
  top: var(--altcha-floating-top, -100%);
  z-index: var(--altcha-z-index);
}
.altcha[data-display=floating] .altcha-main {
  width: var(--altcha-max-width);
}
.altcha[data-display=floating][data-floating-position=top] .altcha-floating-arrow {
  border-bottom-color: transparent;
  border-top-color: var(--altcha-border-color);
  bottom: -12px;
  top: auto;
}
.altcha[data-display=floating][data-visible] {
  display: flex;
}
.altcha[data-display=bar] {
  bottom: -100%;
  filter: var(--altcha-shadow);
  left: 0;
  position: fixed;
  right: 0;
  transition: bottom var(--altcha-transition-duration), top var(--altcha-transition-duration);
  z-index: var(--altcha-z-index);
}
.altcha[data-display=bar] .altcha-main {
  align-items: center;
  border-radius: 0;
  border-width: var(--altcha-border-width) 0 0 0;
  flex-direction: row;
  max-width: 100% !important;
}
.altcha[data-display=bar] .altcha-main > * {
  width: auto;
}
.altcha[data-display=bar][data-placement=top] {
  bottom: auto;
  top: -100%;
}
.altcha[data-display=bar][data-placement=top] .altcha-main {
  border-width: 0 0 var(--altcha-border-width) 0;
}
.altcha[data-display=bar][data-placement=bottom]:not([data-state=unverified]) {
  bottom: 0;
}
.altcha[data-display=bar][data-placement=top]:not([data-state=unverified]) {
  top: 0;
}
.altcha[data-display=invisible] {
  display: none;
}

@keyframes altcha-rotate {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
@keyframes altcha-bottomsheet-slideup {
  100% {
    bottom: 0;
  }
}
@keyframes altcha-overlay-slidein {
  100% {
    opacity: 1;
    top: 50%;
  }
}`),$altcha.algorithms.set("SHA-256",()=>new Hn),$altcha.algorithms.set("SHA-384",()=>new Hn),$altcha.algorithms.set("SHA-512",()=>new Hn),$altcha.algorithms.set("PBKDF2/SHA-256",()=>new zn),$altcha.algorithms.set("PBKDF2/SHA-384",()=>new zn),$altcha.algorithms.set("PBKDF2/SHA-512",()=>new zn),Ko}bc();typeof window<"u"&&window.$altcha?.algorithms&&window.$altcha.algorithms.set("SHA-256",()=>new Worker("/assets/altcha-worker.js"));const yc=dc(Go.forwardRef((Y,Ct)=>V.jsx("form",{ref:Ct,...Y}))),wc="/api/Auth/login",_c="/api/Auth/login",xc={enter:Y=>({x:Y>0?40:-40,opacity:0}),center:{x:0,opacity:1},exit:Y=>({x:Y>0?-40:40,opacity:0})},kc={palette:{mode:"light"},shape:{borderRadius:7},shadows:ac,typography:nc},na=Jl(rc.merge({},kc,oc));na.components=cc(na);const Oc=({title:Y,subtitle:Ct,subtext:rn})=>{const[Ae,Ar]=rt.useState("admin"),[Ot,Lt]=rt.useState(1),[pt,nn]=rt.useState(!1),[Tr,gt]=rt.useState(""),[Ir,rr]=rt.useState(!1),[nt,nr]=rt.useState({username:"",password:""}),[$r,ce]=rt.useState({username:"",password:""}),[mt,Mt]=rt.useState(!0),Wt=rt.useRef(null),ye=rt.useRef(null),Ne=O=>{const W=O.detail;rr(W?.state==="verified")},Te=()=>{rr(!1);try{const O=ye.current||(typeof document<"u"?document.querySelector("altcha-widget"):null);O&&typeof O.reset=="function"&&O.reset()}catch(O){console.error("Failed to reset ALTCHA widget:",O)}},ar=O=>{if(ye.current&&ye.current.removeEventListener("statechange",Ne),ye.current=O,O){O.addEventListener("statechange",Ne),typeof window<"u"&&window.$altcha?.algorithms&&window.$altcha.algorithms.set("SHA-256",()=>new Worker("/assets/altcha-worker.js"));try{const W=lc();O.configure?.({challenge:`${W.API_BASE_URL}/api/Auth/altcha-challenge`,fetch:async(je,K)=>{const ie=new Headers(K?.headers||{});return W.API_KEY&&!ie.has("X-BIOPEOPLETRACKING-API-KEY")&&ie.set("X-BIOPEOPLETRACKING-API-KEY",W.API_KEY),fetch(je,{...K,headers:ie})}})}catch{}}};rt.useEffect(()=>{const O=localStorage.getItem("rememberedAdminUsername"),W=localStorage.getItem("rememberedVisitorUsername"),je=localStorage.getItem("rememberMePreference"),K=localStorage.getItem("rememberedLoginMode");O&&nr(ie=>({...ie,username:O})),W&&ce(ie=>({...ie,username:W})),je!==null&&Mt(je==="true"),K&&(K==="admin"||K==="visitor")&&Ar(K)},[]);const ue=Ae==="admin",Z=ue?nt:$r,fe=(O,W)=>{Lt(Ae==="admin"&&W==="visitor"?1:-1),Ar(W),gt(""),Te()},De=(O,W)=>je=>{gt(""),O==="admin"?nr(K=>({...K,[W]:je.target.value})):ce(K=>({...K,[W]:je.target.value}))},Ie=async O=>{O.preventDefault(),gt("");const W=ye.current?.value||ye.current?.querySelector?.('input[name="altcha"]')?.value||"";if(!W){gt("Please complete the CAPTCHA verification before signing in.");return}const je=ue?wc:_c;try{const K=await ic.post(je,{...Z,altchaPayload:W}),ie=K?.data?.collection?.data??K?.data;if(!ie?.token){const Ke=ie?.message||K?.data?.collection?.message||K?.data?.message||"Invalid username or password. Please try again.";gt(Ke),Te();return}localStorage.setItem("token",ie.token);const $e=sc(ie.token),at=$e["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"],Rr=$e["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"],Xe=$e["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"],Nt=$e.ApplicationId;if(at&&localStorage.setItem("username",at),Rr&&localStorage.setItem("email",Rr),Xe&&localStorage.setItem("levelPriority",Xe.trim()),Nt&&Xe.trim()!=="System"&&localStorage.setItem("applicationId",Nt),$e.fullName&&localStorage.setItem("fullName",$e.fullName),$e.groupName&&localStorage.setItem("groupName",$e.groupName),$e.accessibleBuildings){const Ke=$e.accessibleBuildings.split(",").map(At=>At.trim()).filter(Boolean);localStorage.setItem("accessibleBuildings",JSON.stringify(Ke))}mt?(ue?localStorage.setItem("rememberedAdminUsername",Z.username):localStorage.setItem("rememberedVisitorUsername",Z.username),localStorage.setItem("rememberMePreference","true"),localStorage.setItem("rememberedLoginMode",Ae)):(localStorage.removeItem("rememberedAdminUsername"),localStorage.removeItem("rememberedVisitorUsername"),localStorage.removeItem("rememberedLoginMode"),localStorage.setItem("rememberMePreference","false")),ie?.refreshToken&&localStorage.setItem("refreshToken",ie.refreshToken),localStorage.setItem("response",JSON.stringify(ie)),localStorage.setItem("welcomePopupShown","false");const bt=$e["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"];if(ue&&bt==="Primary"){gt("You do not have permission to login as Admin"),Te();return}setTimeout(()=>{window.location.href=ue?"/dashboards/newmainmenu":bt==="Primary"?"/security-view/dashboard":"/my-visit",console.log("decoded",$e)},300)}catch(K){const ie=K?.response?.data?.collection?.message||K?.response?.data?.message;gt(ie||"Invalid username or password. Please try again."),ue?nr({username:"",password:""}):ce({username:"",password:""}),Te(),requestAnimationFrame(()=>{Wt.current?.focus()})}};return V.jsxs(ql,{theme:na,children:[Y&&V.jsx(ra,{fontWeight:700,variant:"h3",mb:1,children:Y}),rn,V.jsx(tn,{mt:3,children:V.jsxs(Zl,{value:Ae,onChange:fe,variant:"fullWidth",sx:{mb:2,"& .MuiTab-root":{textTransform:"none",fontWeight:600}},children:[V.jsx(Vo,{value:"admin",label:"Admin"}),V.jsx(Vo,{value:"visitor",label:"Security"})]})}),Tr&&V.jsx(ra,{variant:"body2",color:"error",textAlign:"center",sx:{backgroundColor:"#ffebee",border:"1px solid #ffcdd2",borderRadius:1,p:1,mb:2},children:Tr}),V.jsx(fc,{mode:"wait",custom:Ot,children:V.jsx(yc,{onSubmit:Ie,custom:Ot,variants:xc,initial:"enter",animate:"center",exit:"exit",transition:{duration:.25,ease:"easeOut"},children:V.jsxs(Bo,{spacing:2,children:[V.jsxs(tn,{children:[V.jsx(zo,{htmlFor:"username",children:"Username"}),V.jsx(Ho,{id:"username",fullWidth:!0,inputRef:Wt,value:Z.username,onChange:De(Ae,"username")})]}),V.jsxs(tn,{children:[V.jsx(zo,{htmlFor:"password",children:"Password"}),V.jsx(Ho,{id:"password",type:pt?"text":"password",fullWidth:!0,value:Z.password,onChange:De(Ae,"password"),InputProps:{endAdornment:V.jsx(Xl,{position:"end",children:V.jsx(Ql,{onClick:()=>nn(O=>!O),children:pt?V.jsx(hc,{size:20}):V.jsx(vc,{size:20})})})}})]}),V.jsxs(Bo,{direction:"row",justifyContent:"space-between",alignItems:"center",children:[V.jsx(pc,{children:V.jsx(gc,{control:V.jsx(Jo,{checked:mt,onChange:O=>Mt(O.target.checked)}),label:"Remember this Device"})}),V.jsx(ra,{component:ec,to:"/auth/forgot-password",fontWeight:500,sx:{textDecoration:"none",color:"primary.main"},children:"Forgot Password ?"})]}),V.jsx(tn,{sx:{"& altcha-widget":{width:"100%","--altcha-border-radius":"8px","--altcha-border-color":"rgba(0,0,0,0.23)","--altcha-color-base":"#ffffff","--altcha-color-base-content":"#333333",fontSize:"0.875rem"}},children:V.jsx("altcha-widget",{ref:ar,challenge:"/api/Auth/altcha-challenge",challengeurl:"/api/Auth/altcha-challenge",hidefooter:!0,style:{width:"100%"}})}),V.jsx(tc,{type:"submit",fullWidth:!0,size:"large",variant:"contained",disabled:!Ir,children:ue?"Sign In as Admin":"Sign In as Security"})]})},Ae)}),Ct]})};export{Oc as A};
