const s="/assets/login-bg-mrVDfRMt.svg";export{s as i};
