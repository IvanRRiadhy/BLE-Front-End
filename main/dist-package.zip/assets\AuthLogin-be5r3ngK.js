import{R as Wo,j as V,s as qo,p as ql,r as nt,jL as Zl,jM as Jl,T as na,B as en,bT as Xl,bU as Bo,S as Ho,ca as zo,c4 as Ko,bf as Ql,w as ec,Z as tc,z as rc,jR as nc,jS as ac,jT as oc,jU as ic,cH as sc,jY as lc,jQ as cc,jZ as uc,ay as fc,jV as dc}from"./index-Dzx-6msi.js";import{C as hc}from"./Checkbox-Dm1bW3rP.js";import{A as vc,m as pc}from"./index-DHYV8pr2.js";import{I as gc}from"./IconEyeOff-DbQXPMqD.js";import{I as mc}from"./IconEye-C63m4cuo.js";import{F as bc}from"./FormGroup-FDhR3bIM.js";import{F as yc}from"./FormControlLabel-BPBwDXr3.js";const Zo=qo("span")(({theme:K})=>({borderRadius:3,width:19,height:19,marginLeft:"4px",boxShadow:K.palette.mode==="dark"?`0 0 0 1px ${K.palette.grey[200]}`:`inset 0 0 0 1px ${K.palette.grey[300]}`,backgroundColor:"transparent",".Mui-focusVisible &":{outline:K.palette.mode==="dark"?`0px auto ${K.palette.grey[200]}`:`0px auto  ${K.palette.grey[300]}`,outlineOffset:2},"input:hover ~ &":{backgroundColor:(K.palette.mode==="dark",K.palette.primary)},"input:disabled ~ &":{boxShadow:"none",background:K.palette.grey[100]}})),wc=qo(Zo)({boxShadow:"none",width:19,height:19,"&:before":{display:"block",width:19,height:19,backgroundImage:`url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M12 5c-.28 0-.53.11-.71.29L7 9.59l-2.29-2.3a1.003 1.003 0 00-1.42 1.42l3 3c.18.18.43.29.71.29s.53-.11.71-.29l5-5A1.003 1.003 0 0012 5z' fill='%23fff'/%3E%3C/svg%3E")`,content:'""'}}),Jo=Wo.forwardRef((K,Ct)=>V.jsx(hc,{disableRipple:!0,color:K.color||"default",checkedIcon:V.jsx(wc,{sx:{backgroundColor:K.color?`${K.color}.main`:"primary.main"}}),icon:V.jsx(Zo,{}),inputProps:{"aria-label":"Checkbox demo"},ref:Ct,...K}));Jo.displayName="CustomCheckbox";var Yo={},Go;function _c(){if(Go)return Yo;Go=1;const K=!1;var Ct=Array.isArray,tn=Array.prototype.indexOf,At=Array.prototype.includes,mt=Array.from,Dt=Object.keys,Tt=Object.defineProperty,It=Object.getOwnPropertyDescriptor,Tr=Object.getOwnPropertyDescriptors,rn=Object.prototype,Ir=Array.prototype,at=Object.getPrototypeOf,$r=Object.isExtensible;const Je=()=>{};function nn(e){for(var t=0;t<e.length;t++)e[t]()}function Zt(){var e,t,r=new Promise((n,a)=>{e=n,t=a});return{promise:r,resolve:e,reject:t}}const ge=2,ot=4,jt=8,Jt=1<<24,Ie=16,we=32,He=64,$t=128,$e=512,Y=1024,ee=2048,ze=4096,Ee=8192,Ne=16384,D=32768,te=1<<25,fe=65536,W=1<<17,le=1<<18,oe=1<<19,or=1<<20,it=65536,Rt=1<<21,bt=1<<22,Xe=1<<23,Qe=Symbol("$state"),an=Symbol("legacy props"),Xo=Symbol(""),oa=Symbol("attributes"),on=Symbol("class"),sn=Symbol("style"),ln=Symbol("text"),ir=Symbol("form reset"),Rr=new class extends Error{name="StaleReactionError";message="The reaction that called `getAbortSignal()` was re-run or destroyed"},sr=!!globalThis.document?.contentType&&globalThis.document.contentType.includes("xml"),lr=3,cr=8;function ia(e){return e===this.v}function sa(e,t){return e!=e?t==t:e!==t||e!==null&&typeof e=="object"||typeof e=="function"}function Qo(e){return!sa(e,this.v)}function ei(e){throw new Error("https://svelte.dev/e/lifecycle_outside_component")}function ti(){throw new Error("https://svelte.dev/e/async_derived_orphan")}function ri(e){throw new Error("https://svelte.dev/e/effect_in_teardown")}function ni(){throw new Error("https://svelte.dev/e/effect_in_unowned_derived")}function ai(e){throw new Error("https://svelte.dev/e/effect_orphan")}function oi(){throw new Error("https://svelte.dev/e/effect_update_depth_exceeded")}function ii(){throw new Error("https://svelte.dev/e/hydration_failed")}function si(){throw new Error("https://svelte.dev/e/state_descriptors_fixed")}function li(){throw new Error("https://svelte.dev/e/state_prototype_fixed")}function ci(){throw new Error("https://svelte.dev/e/state_unsafe_mutation")}function ui(){throw new Error("https://svelte.dev/e/svelte_boundary_reset_onerror")}let fi=!1;const di=1,hi=2,cn="[",la="[!",ca="[?",ua="]",Ut={},de=Symbol("uninitialized"),fa="http://www.w3.org/1999/xhtml",vi="http://www.w3.org/2000/svg",pi="http://www.w3.org/1998/Math/MathML",gi="@attach";let Re=null;function Xt(e){Re=e}function yt(e,t=!1,r){Re={p:Re,i:!1,c:null,e:null,s:e,x:null,r:I,l:null}}function wt(e){var t=Re,r=t.e;if(r!==null){t.e=null;for(var n of r)Ga(n)}return e!==void 0&&(t.x=e),t.i=!0,Re=t.p,e??{}}function da(){return!0}let Ft=[];function ha(){var e=Ft;Ft=[],nn(e)}function _t(e){if(Ft.length===0&&!dr){var t=Ft;queueMicrotask(()=>{t===Ft&&ha()})}Ft.push(e)}function mi(){for(;Ft.length>0;)ha()}function bi(){console.warn("https://svelte.dev/e/derived_inert")}function ur(e){console.warn("https://svelte.dev/e/hydration_mismatch")}function yi(){console.warn("https://svelte.dev/e/select_multiple_invalid_value")}function wi(){console.warn("https://svelte.dev/e/svelte_boundary_reset_noop")}let R=!1;function st(e){R=e}let M;function Ce(e){if(e===null)throw ur(),Ut;return M=e}function Vt(){return Ce(ct(M))}function J(e){if(R){if(ct(M)!==null)throw ur(),Ut;M=e}}function un(e=1){if(R){for(var t=e,r=M;t--;)r=ct(r);M=r}}function fn(e=!0){for(var t=0,r=M;;){if(r.nodeType===cr){var n=r.data;if(n===ua){if(t===0)return r;t-=1}else(n===cn||n===la||n[0]==="["&&!isNaN(Number(n.slice(1))))&&(t+=1)}var a=ct(r);e&&r.remove(),r=a}}function va(e){if(!e||e.nodeType!==cr)throw ur(),Ut;return e.data}function xt(e){if(typeof e!="object"||e===null||Qe in e)return e;const t=at(e);if(t!==rn&&t!==Ir)return e;var r=new Map,n=Ct(e),a=O(0),i=Kt,s=l=>{if(Kt===i)return l();var u=j,c=Kt;Ke(null),Va(i);var d=l();return Ke(u),Va(c),d};return n&&r.set("length",O(e.length)),new Proxy(e,{defineProperty(l,u,c){(!("value"in c)||c.configurable===!1||c.enumerable===!1||c.writable===!1)&&si();var d=r.get(u);return d===void 0?s(()=>{var v=O(c.value);return r.set(u,v),v}):w(d,c.value,!0),!0},deleteProperty(l,u){var c=r.get(u);if(c===void 0){if(u in l){const d=s(()=>O(de));r.set(u,d),vr(a)}}else w(c,de),vr(a);return!0},get(l,u,c){if(u===Qe)return e;var d=r.get(u),v=u in l;if(d===void 0&&(!v||It(l,u)?.writable)&&(d=s(()=>{var m=xt(v?l[u]:de),g=O(m);return g}),r.set(u,d)),d!==void 0){var h=o(d);return h===de?void 0:h}return Reflect.get(l,u,c)},getOwnPropertyDescriptor(l,u){var c=Reflect.getOwnPropertyDescriptor(l,u);if(c&&"value"in c){var d=r.get(u);d&&(c.value=o(d))}else if(c===void 0){var v=r.get(u),h=v?.v;if(v!==void 0&&h!==de)return{enumerable:!0,configurable:!0,value:h,writable:!0}}return c},has(l,u){if(u===Qe)return!0;var c=r.get(u),d=c!==void 0&&c.v!==de||Reflect.has(l,u);if(c!==void 0||I!==null&&(!d||It(l,u)?.writable)){c===void 0&&(c=s(()=>{var h=d?xt(l[u]):de,m=O(h);return m}),r.set(u,c));var v=o(c);if(v===de)return!1}return d},set(l,u,c,d){var v=r.get(u),h=u in l;if(n&&u==="length")for(var m=c;m<v.v;m+=1){var g=r.get(m+"");g!==void 0?w(g,de):m in l&&(g=s(()=>O(de)),r.set(m+"",g))}if(v===void 0)(!h||It(l,u)?.writable)&&(v=s(()=>O(void 0)),w(v,xt(c)),r.set(u,v));else{h=v.v!==de;var x=s(()=>xt(c));w(v,x)}var T=Reflect.getOwnPropertyDescriptor(l,u);if(T?.set&&T.set.call(d,c),!h){if(n&&typeof u=="string"){var L=r.get("length"),ye=Number(u);Number.isInteger(ye)&&ye>=L.v&&w(L,ye+1)}vr(a)}return!0},ownKeys(l){o(a);var u=Reflect.ownKeys(l).filter(v=>{var h=r.get(v);return h===void 0||h.v!==de});for(var[c,d]of r)d.v!==de&&!(c in l)&&u.push(c);return u},setPrototypeOf(){li()}})}function pa(e){try{if(e!==null&&typeof e=="object"&&Qe in e)return e[Qe]}catch{}return e}function _i(e,t){return Object.is(pa(e),pa(t))}var Bt,dn,ga,ma,ba;function hn(){if(Bt===void 0){Bt=window,dn=document,ga=/Firefox/.test(navigator.userAgent);var e=Element.prototype,t=Node.prototype,r=Text.prototype;ma=It(t,"firstChild").get,ba=It(t,"nextSibling").get,$r(e)&&(e[on]=void 0,e[oa]=null,e[sn]=void 0,e.__e=void 0),$r(r)&&(r[ln]=void 0)}}function lt(e=""){return document.createTextNode(e)}function De(e){return ma.call(e)}function ct(e){return ba.call(e)}function ie(e,t){if(!R)return De(e);var r=De(M);if(r===null)r=M.appendChild(lt());else if(t&&r.nodeType!==lr){var n=lt();return r?.before(n),Ce(n),n}return t&&Pr(r),Ce(r),r}function Qt(e,t=!1){if(!R){var r=De(e);return r instanceof Comment&&r.data===""?ct(r):r}if(t){if(M?.nodeType!==lr){var n=lt();return M?.before(n),Ce(n),n}Pr(M)}return M}function re(e,t=1,r=!1){let n=R?M:e;for(var a;t--;)a=n,n=ct(n);if(!R)return n;if(r){if(n?.nodeType!==lr){var i=lt();return n===null?a?.after(i):n.before(i),Ce(i),i}Pr(n)}return Ce(n),n}function xi(e){e.textContent=""}function vn(e,t,r){return document.createElementNS(t??fa,e,void 0)}function Pr(e){if(e.nodeValue.length<65536)return;let t=e.nextSibling;for(;t!==null&&t.nodeType===lr;)t.remove(),e.nodeValue+=t.nodeValue,t=e.nextSibling}function ya(e){var t=I;if(t===null)return j.f|=Xe,e;if((t.f&D)===0&&(t.f&ot)===0)throw e;Pt(e,t)}function Pt(e,t){for(;t!==null;){if((t.f&$t)!==0){if((t.f&D)===0)throw e;try{t.b.error(e);return}catch(r){e=r}}t=t.parent}throw e}const ki=-7169;function ce(e,t){e.f=e.f&ki|t}function pn(e){(e.f&$e)!==0||e.deps===null?ce(e,Y):ce(e,ze)}function wa(e){if(e!==null)for(const t of e)(t.f&ge)===0||(t.f&it)===0||(t.f^=it,wa(t.deps))}function _a(e,t,r){(e.f&ee)!==0?t.add(e):(e.f&ze)!==0&&r.add(e),wa(e.deps),ce(e,Y)}function xa(e,t,r){if(e==null)return t(void 0),Je;const n=mr(()=>e.subscribe(t,r));return n.unsubscribe?()=>n.unsubscribe():n}const er=[];function Si(e,t=Je){let r=null;const n=new Set;function a(l){if(sa(e,l)&&(e=l,r)){const u=!er.length;for(const c of n)c[1](),er.push(c,e);if(u){for(let c=0;c<er.length;c+=2)er[c][0](er[c+1]);er.length=0}}}function i(l){a(l(e))}function s(l,u=Je){const c=[l,u];return n.add(c),n.size===1&&(r=t(a,i)||Je),l(e),()=>{n.delete(c),n.size===0&&r&&(r(),r=null)}}return{set:a,update:i,subscribe:s}}function fr(e){let t;return xa(e,r=>t=r)(),t}let gn=Symbol("unmounted");function ka(e,t,r){const n=r[t]??={store:null,source:La(void 0),unsubscribe:Je};if(n.store!==e&&!(gn in r))if(n.unsubscribe(),n.store=e??null,e==null)n.source.v=void 0,n.unsubscribe=Je;else{var a=!0;n.unsubscribe=xa(e,i=>{a?n.source.v=i:w(n.source,i)}),a=!1}return e&&gn in r?fr(e):o(n.source)}function Ei(){const e={};function t(){Fr(()=>{for(var r in e)e[r].unsubscribe();Tt(e,gn,{enumerable:!1,value:!0})})}return[e,t]}let mn=null,tr=null,P=null,bn=null,et=null,yn=null,dr=!1,wn=!1,rr=null,Or=null;var Sa=0;let Ci=1;class kt{id=Ci++;#e=!1;linked=!0;#t=null;#r=null;async_deriveds=new Map;current=new Map;previous=new Map;unblocked=new Set;#l=new Set;#n=new Set;#i=new Set;#a=0;#o=new Map;#d=null;#s=[];#v=[];#h=new Set;#c=new Set;#u=new Map;#f=new Set;is_fork=!1;#m=!1;#_(){if(this.is_fork)return!0;for(const n of this.#o.keys()){for(var t=n,r=!1;t.parent!==null;){if(this.#u.has(t)){r=!0;break}t=t.parent}if(!r)return!0}return!1}skip_effect(t){this.#u.has(t)||this.#u.set(t,{d:[],m:[]}),this.#f.delete(t)}unskip_effect(t,r=n=>this.schedule(n)){var n=this.#u.get(t);if(n){this.#u.delete(t);for(var a of n.d)ce(a,ee),r(a);for(a of n.m)ce(a,ze),r(a)}this.#f.add(t)}#g(){if(this.#e=!0,Sa++>1e3&&(this.#w(),Ai()),!this.#_()){for(const u of this.#h)this.#c.delete(u),ce(u,ee),this.schedule(u);for(const u of this.#c)ce(u,ze),this.schedule(u)}const t=this.#s;this.#s=[],this.apply();var r=rr=[],n=[],a=Or=[];for(const u of t)try{this.#x(u,r,n)}catch(c){throw Ta(u),c}if(P=null,a.length>0){var i=kt.ensure();for(const u of a)i.schedule(u)}if(rr=null,Or=null,this.#_()){this.#p(n),this.#p(r);for(const[u,c]of this.#u)Aa(u,c);a.length>0&&P.#g();return}const s=this.#k();if(s){s.#b(this);return}this.#h.clear(),this.#c.clear();for(const u of this.#l)u(this);this.#l.clear(),bn=this,Ea(n),Ea(r),bn=null,this.#d?.resolve();var l=P;if(this.linked&&this.#a===0&&this.#w(),this.#s.length>0){l===null&&(l=this,this.#y());const u=l;u.#s.push(...this.#s.filter(c=>!u.#s.includes(c)))}l!==null&&l.#g()}#x(t,r,n){t.f^=Y;for(var a=t.first;a!==null;){var i=a.f,s=(i&(we|He))!==0,l=s&&(i&Y)!==0,u=l||(i&Ee)!==0||this.#u.has(a);if(!u&&a.fn!==null){s?a.f^=Y:(i&ot)!==0?r.push(a):pr(a)&&((i&Ie)!==0&&this.#c.add(a),nr(a));var c=a.first;if(c!==null){a=c;continue}}for(;a!==null;){var d=a.next;if(d!==null){a=d;break}a=a.parent}}}#k(){for(var t=this.#t;t!==null;){if(!t.is_fork){for(const[r,[,n]]of this.current)if(t.current.has(r)&&!n)return t}t=t.#t}return null}#b(t){for(const[n,a]of t.current)!this.previous.has(n)&&t.previous.has(n)&&this.previous.set(n,t.previous.get(n)),this.current.set(n,a);for(const[n,a]of t.async_deriveds){const i=this.async_deriveds.get(n);i&&a.promise.then(i.resolve)}const r=n=>{var a=n.reactions;if(a!==null)for(const l of a){var i=l.f;if((i&ge)!==0)r(l);else{var s=l;i&(bt|Ie)&&!this.async_deriveds.has(s)&&(this.#c.delete(s),ce(s,ee),this.schedule(s))}}};for(const n of this.current.keys())r(n);this.oncommit(()=>t.discard()),t.#w(),P=this,this.#g()}#p(t){for(var r=0;r<t.length;r+=1)_a(t[r],this.#h,this.#c)}capture(t,r,n=!1){t.v!==de&&!this.previous.has(t)&&this.previous.set(t,t.v),(t.f&Xe)===0&&(this.current.set(t,[r,n]),et?.set(t,r)),this.is_fork||(t.v=r)}activate(){P=this}deactivate(){P=null,et=null}flush(){try{wn=!0,P=this,this.#g()}finally{Sa=0,yn=null,rr=null,Or=null,wn=!1,P=null,et=null,Ht.clear()}}discard(){for(const t of this.#n)t(this);this.#n.clear(),this.#i.clear(),this.#w()}register_created_effect(t){this.#v.push(t)}#S(){this.#w();for(let d=mn;d!==null;d=d.#r){var t=d.id<this.id,r=[];for(const[v,[h,m]]of this.current){if(d.current.has(v)){var n=d.current.get(v)[0];if(t&&h!==n)d.current.set(v,[h,m]);else continue}r.push(v)}if(t)for(const[v,h]of this.async_deriveds){const m=d.async_deriveds.get(v);m&&h.promise.then(m.resolve)}if(d.#e){var a=[...d.current.keys()].filter(v=>!this.current.has(v));if(a.length===0)t&&d.discard();else if(r.length>0){if(t)for(const v of this.#f)d.unskip_effect(v,h=>{(h.f&(Ie|bt))!==0?d.schedule(h):d.#p([h])});d.activate();var i=new Set,s=new Map;for(var l of r)Ca(l,a,i,s);s=new Map;var u=[...d.current.keys()].filter(v=>this.current.has(v)?this.current.get(v)[0]!==v.v:!0);if(u.length>0)for(const v of this.#v)(v.f&(Ne|Ee|W))===0&&_n(v,u,s)&&((v.f&(bt|Ie))!==0?(ce(v,ee),d.schedule(v)):d.#h.add(v));if(d.#s.length>0){d.apply();for(var c of d.#s)d.#x(c,[],[]);d.#s=[]}d.deactivate()}}}}increment(t,r){if(this.#a+=1,t){let n=this.#o.get(r)??0;this.#o.set(r,n+1)}}decrement(t,r){if(this.#a-=1,t){let n=this.#o.get(r)??0;n===1?this.#o.delete(r):this.#o.set(r,n-1)}this.#m||(this.#m=!0,_t(()=>{this.#m=!1,this.linked&&this.flush()}))}transfer_effects(t,r){for(const n of t)this.#h.add(n);for(const n of r)this.#c.add(n);t.clear(),r.clear()}oncommit(t){this.#l.add(t)}ondiscard(t){this.#n.add(t)}on_fork_commit(t){this.#i.add(t)}run_fork_commit_callbacks(){for(const t of this.#i)t(this);this.#i.clear()}settled(){return(this.#d??=Zt()).promise}static ensure(){if(P===null){const t=P=new kt;t.#y(),!wn&&!dr&&_t(()=>{t.#e||t.flush()})}return P}apply(){{et=null;return}}schedule(t){if(yn=t,t.b?.is_pending&&(t.f&(ot|jt|Jt))!==0&&(t.f&D)===0){t.b.defer_effect(t);return}for(var r=t;r.parent!==null;){r=r.parent;var n=r.f;if(rr!==null&&r===I&&(j===null||(j.f&ge)===0))return;if((n&(He|we))!==0){if((n&Y)===0)return;r.f^=Y}}this.#s.push(r)}#y(){tr===null?mn=tr=this:(tr.#r=this,this.#t=tr),tr=this}#w(){var t=this.#t,r=this.#r;t===null?mn=r:t.#r=r,r===null?tr=t:r.#t=t,this.linked=!1}}function q(e){var t=dr;dr=!0;try{for(var r;;){if(mi(),P===null)return r;P.flush()}}finally{dr=t}}function Ai(){try{oi()}catch(e){Pt(e,yn)}}let St=null;function Ea(e){var t=e.length;if(t!==0){for(var r=0;r<t;){var n=e[r++];if((n.f&(Ne|Ee))===0&&pr(n)&&(St=new Set,nr(n),n.deps===null&&n.first===null&&n.nodes===null&&n.teardown===null&&n.ac===null&&Ja(n),St?.size>0)){Ht.clear();for(const a of St){if((a.f&(Ne|Ee))!==0)continue;const i=[a];let s=a.parent;for(;s!==null;)St.has(s)&&(St.delete(s),i.push(s)),s=s.parent;for(let l=i.length-1;l>=0;l--){const u=i[l];(u.f&(Ne|Ee))===0&&nr(u)}}St.clear()}}St=null}}function Ca(e,t,r,n){if(!r.has(e)&&(r.add(e),e.reactions!==null))for(const a of e.reactions){const i=a.f;(i&ge)!==0?Ca(a,t,r,n):(i&(bt|Ie))!==0&&(i&ee)===0&&_n(a,t,n)&&(ce(a,ee),xn(a))}}function _n(e,t,r){const n=r.get(e);if(n!==void 0)return n;if(e.deps!==null)for(const a of e.deps){if(At.call(t,a))return!0;if((a.f&ge)!==0&&_n(a,t,r))return r.set(a,!0),!0}return r.set(e,!1),!1}function xn(e){P.schedule(e)}function Aa(e,t){if(!((e.f&we)!==0&&(e.f&Y)!==0)){(e.f&ee)!==0?t.d.push(e):(e.f&ze)!==0&&t.m.push(e),ce(e,Y);for(var r=e.first;r!==null;)Aa(r,t),r=r.next}}function Ta(e){ce(e,Y);for(var t=e.first;t!==null;)Ta(t),t=t.next}function Ti(e){let t=0,r=hr(0),n;return()=>{En()&&(o(r),Vr(()=>(t===0&&(n=mr(()=>e(()=>vr(r)))),t+=1,()=>{_t(()=>{t-=1,t===0&&(n?.(),n=void 0,vr(r))})})))}}var Ii=fe|oe;function $i(e,t,r,n){new Ri(e,t,r,n)}class Ri{parent;is_pending=!1;transform_error;#e;#t=R?M:null;#r;#l;#n;#i=null;#a=null;#o=null;#d=null;#s=0;#v=0;#h=!1;#c=new Set;#u=new Set;#f=null;#m=Ti(()=>(this.#f=hr(this.#s),()=>{this.#f=null}));constructor(t,r,n,a){this.#e=t,this.#r=r,this.#l=i=>{var s=I;s.b=this,s.f|=$t,n(i)},this.parent=I.b,this.transform_error=a??this.parent?.transform_error??(i=>i),this.#n=br(()=>{if(R){const i=this.#t;Vt();const s=i.data===la;if(i.data.startsWith(ca)){const u=JSON.parse(i.data.slice(ca.length));this.#g(u)}else s?this.#x():this.#_()}else this.#k()},Ii),R&&(this.#e=M)}#_(){try{this.#i=ft(()=>this.#l(this.#e))}catch(t){this.error(t)}}#g(t){const r=this.#r.failed;r&&(this.#o=ft(()=>{r(this.#e,()=>t,()=>()=>{})}))}#x(){const t=this.#r.pending;t&&(this.is_pending=!0,this.#a=ft(()=>t(this.#e)),_t(()=>{var r=this.#d=document.createDocumentFragment(),n=lt();r.append(n),this.#i=this.#p(()=>ft(()=>this.#l(n))),this.#v===0&&(this.#e.before(r),this.#d=null,yr(this.#a,()=>{this.#a=null}),this.#b(P))}))}#k(){try{if(this.is_pending=this.has_pending_snippet(),this.#v=0,this.#s=0,this.#i=ft(()=>{this.#l(this.#e)}),this.#v>0){var t=this.#d=document.createDocumentFragment();eo(this.#i,t);const r=this.#r.pending;this.#a=ft(()=>r(this.#e))}else this.#b(P)}catch(r){this.error(r)}}#b(t){this.is_pending=!1,t.transfer_effects(this.#c,this.#u)}defer_effect(t){_a(t,this.#c,this.#u)}is_rendered(){return!this.is_pending&&(!this.parent||this.parent.is_rendered())}has_pending_snippet(){return!!this.#r.pending}#p(t){var r=I,n=j,a=Re;ut(this.#n),Ke(this.#n),Xt(this.#n.ctx);try{return kt.ensure(),t()}catch(i){return ya(i),null}finally{ut(r),Ke(n),Xt(a)}}#S(t,r){if(!this.has_pending_snippet()){this.parent&&this.parent.#S(t,r);return}this.#v+=t,this.#v===0&&(this.#b(r),this.#a&&yr(this.#a,()=>{this.#a=null}),this.#d&&(this.#e.before(this.#d),this.#d=null))}update_pending_count(t,r){this.#S(t,r),this.#s+=t,!(!this.#f||this.#h)&&(this.#h=!0,_t(()=>{this.#h=!1,this.#f&&Dr(this.#f,this.#s)}))}get_effect_pending(){return this.#m(),o(this.#f)}error(t){if(!this.#r.onerror&&!this.#r.failed)throw t;P?.is_fork?(this.#i&&P.skip_effect(this.#i),this.#a&&P.skip_effect(this.#a),this.#o&&P.skip_effect(this.#o),P.on_fork_commit(()=>{this.#y(t)})):this.#y(t)}#y(t){this.#i&&(_e(this.#i),this.#i=null),this.#a&&(_e(this.#a),this.#a=null),this.#o&&(_e(this.#o),this.#o=null),R&&(Ce(this.#t),un(),Ce(fn()));var r=this.#r.onerror;let n=this.#r.failed;var a=!1,i=!1;const s=()=>{if(a){wi();return}a=!0,i&&ui(),this.#o!==null&&yr(this.#o,()=>{this.#o=null}),this.#p(()=>{this.#k()})},l=u=>{try{i=!0,r?.(u,s),i=!1}catch(c){Pt(c,this.#n&&this.#n.parent)}n&&(this.#o=this.#p(()=>{try{return ft(()=>{var c=I;c.b=this,c.f|=$t,n(this.#e,()=>u,()=>s)})}catch(c){return Pt(c,this.#n.parent),null}}))};_t(()=>{var u;try{u=this.transform_error(t)}catch(c){Pt(c,this.#n&&this.#n.parent);return}u!==null&&typeof u=="object"&&typeof u.then=="function"?u.then(l,c=>Pt(c,this.#n&&this.#n.parent)):l(u)})}}function Ia(e,t,r,n){const a=kn;var i=e.filter(h=>!h.settled);if(r.length===0&&i.length===0){n(t.map(a));return}var s=I,l=Pi(),u=i.length===1?i[0].promise:i.length>1?Promise.all(i.map(h=>h.promise)):null;function c(h){if((s.f&Ne)===0){l();try{n(h)}catch(m){Pt(m,s)}Lr()}}var d=$a();if(r.length===0){u.then(()=>c(t.map(a))).finally(d);return}function v(){Promise.all(r.map(h=>Oi(h))).then(h=>c([...t.map(a),...h])).catch(h=>Pt(h,s)).finally(d)}u?u.then(()=>{l(),v(),Lr()}):v()}function Pi(){var e=I,t=j,r=Re,n=P;return function(i=!0){ut(e),Ke(t),Xt(r),i&&(e.f&Ne)===0&&(n?.activate(),n?.apply())}}function Lr(e=!0){ut(null),Ke(null),Xt(null),e&&P?.deactivate()}function $a(){var e=I,t=e.b,r=P,n=t.is_rendered();return t.update_pending_count(1,r),r.increment(n,e),()=>{t.update_pending_count(-1,r),r.decrement(n,e)}}function kn(e){var t=ge|ee;return I!==null&&(I.f|=oe),{ctx:Re,deps:null,effects:null,equals:ia,f:t,fn:e,reactions:null,rv:0,v:de,wv:0,parent:I,ac:null}}const Mr=Symbol("obsolete");function Oi(e,t,r){let n=I;n===null&&ti();var a=void 0,i=hr(de),s=!j,l=new Set;return Ki(()=>{var u=I,c=Zt();a=c.promise;try{Promise.resolve(e()).then(c.resolve,m=>{m!==Rr&&c.reject(m)}).finally(Lr)}catch(m){c.reject(m),Lr()}var d=P;if(s){if((u.f&D)!==0)var v=$a();if(n.b.is_rendered())d.async_deriveds.get(u)?.reject(Mr);else for(const m of l.values())m.reject(Mr);l.add(c),d.async_deriveds.set(u,c)}const h=(m,g=void 0)=>{v?.(),l.delete(c),g!==Mr&&(d.activate(),g?(i.f|=Xe,Dr(i,g)):((i.f&Xe)!==0&&(i.f^=Xe),Dr(i,m)),d.deactivate())};c.promise.then(h,m=>h(null,m||"unknown"))}),Fr(()=>{for(const u of l)u.reject(Mr)}),new Promise(u=>{function c(d){function v(){d===a?u(i):c(a)}d.then(v,v)}c(a)})}function Ae(e){const t=kn(e);return Ua(t),t}function Li(e){var t=e.effects;if(t!==null){e.effects=null;for(var r=0;r<t.length;r+=1)_e(t[r])}}function Sn(e){var t,r=I,n=e.parent;if(!Et&&n!==null&&e.v!==de&&(n.f&(Ne|Ee))!==0)return bi(),e.v;ut(n);try{e.f&=~it,Li(e),t=za(e)}finally{ut(r)}return t}function Ra(e){var t=Sn(e);if(!e.equals(t)&&(e.wv=Ba(),(!P?.is_fork||e.deps===null)&&(P!==null?(P.capture(e,t,!0),bn?.capture(e,t,!0)):e.v=t,e.deps===null))){ce(e,Y);return}Et||(et!==null?(En()||P?.is_fork)&&et.set(e,t):pn(e))}function Mi(e){if(e.effects!==null)for(const t of e.effects)(t.teardown||t.ac)&&(t.teardown?.(),t.ac?.abort(Rr),t.fn!==null&&(t.teardown=Je),t.ac=null,gr(t,0),An(t))}function Pa(e){if(e.effects!==null)for(const t of e.effects)t.teardown&&t.fn!==null&&nr(t)}let Nr=new Set;const Ht=new Map;let Oa=!1;function hr(e,t){var r={f:0,v:e,reactions:null,equals:ia,rv:0,wv:0};return r}function O(e,t){const r=hr(e);return Ua(r),r}function La(e,t=!1,r=!0){const n=hr(e);return t||(n.equals=Qo),n}function w(e,t,r=!1){j!==null&&(!tt||(j.f&W)!==0)&&da()&&(j.f&(ge|Ie|bt|W))!==0&&(Ye===null||!At.call(Ye,e))&&ci();let n=r?xt(t):t;return Dr(e,n,Or)}function Dr(e,t,r=null){if(!e.equals(t)){Ht.set(e,Et?t:e.v);var n=kt.ensure();if(n.capture(e,t),(e.f&ge)!==0){const a=e;(e.f&ee)!==0&&Sn(a),et===null&&pn(a)}e.wv=Ba(),Ma(e,ee,r),I!==null&&(I.f&Y)!==0&&(I.f&(we|He))===0&&(Ge===null?Ui([e]):Ge.push(e)),!n.is_fork&&Nr.size>0&&!Oa&&Ni()}return t}function Ni(){Oa=!1;for(const e of Nr){(e.f&Y)!==0&&ce(e,ze);let t;try{t=pr(e)}catch{t=!0}t&&nr(e)}Nr.clear()}function vr(e){w(e,e.v+1)}function Ma(e,t,r){var n=e.reactions;if(n!==null)for(var a=n.length,i=0;i<a;i++){var s=n[i],l=s.f,u=(l&ee)===0;if(u&&ce(s,t),(l&W)!==0)Nr.add(s);else if((l&ge)!==0){var c=s;et?.delete(c),(l&it)===0&&(l&$e&&(I===null||(I.f&Rt)===0)&&(s.f|=it),Ma(c,ze,r))}else if(u){var d=s;(l&Ie)!==0&&St!==null&&St.add(d),r!==null?r.push(d):xn(d)}}}function Di(e,t){if(t){const r=document.body;e.autofocus=!0,_t(()=>{document.activeElement===r&&e.focus()})}}let Na=!1;function Da(){Na||(Na=!0,document.addEventListener("reset",e=>{Promise.resolve().then(()=>{if(!e.defaultPrevented)for(const t of e.target.elements)t[ir]?.()})},{capture:!0}))}function jr(e){var t=j,r=I;Ke(null),ut(null);try{return e()}finally{Ke(t),ut(r)}}function ji(e,t,r,n=r){e.addEventListener(t,()=>jr(r));const a=e[ir];a?e[ir]=()=>{a(),n(!0)}:e[ir]=()=>n(!0),Da()}let Ur=!1,Et=!1;function ja(e){Et=e}let j=null,tt=!1;function Ke(e){j=e}let I=null;function ut(e){I=e}let Ye=null;function Ua(e){j!==null&&(Ye===null?Ye=[e]:Ye.push(e))}let Pe=null,je=0,Ge=null;function Ui(e){Ge=e}let Fa=1,zt=0,Kt=zt;function Va(e){Kt=e}function Ba(){return++Fa}function pr(e){var t=e.f;if((t&ee)!==0)return!0;if(t&ge&&(e.f&=~it),(t&ze)!==0){for(var r=e.deps,n=r.length,a=0;a<n;a++){var i=r[a];if(pr(i)&&Ra(i),i.wv>e.wv)return!0}(t&$e)!==0&&et===null&&ce(e,Y)}return!1}function Ha(e,t,r=!0){var n=e.reactions;if(n!==null&&!(Ye!==null&&At.call(Ye,e)))for(var a=0;a<n.length;a++){var i=n[a];(i.f&ge)!==0?Ha(i,t,!1):t===i&&(r?ce(i,ee):(i.f&Y)!==0&&ce(i,ze),xn(i))}}function za(e){var t=Pe,r=je,n=Ge,a=j,i=Ye,s=Re,l=tt,u=Kt,c=e.f;Pe=null,je=0,Ge=null,j=(c&(we|He))===0?e:null,Ye=null,Xt(e.ctx),tt=!1,Kt=++zt,e.ac!==null&&(jr(()=>{e.ac.abort(Rr)}),e.ac=null);try{e.f|=Rt;var d=e.fn,v=d();e.f|=D;var h=e.deps,m=P?.is_fork;if(Pe!==null){var g;if(m||gr(e,je),h!==null&&je>0)for(h.length=je+Pe.length,g=0;g<Pe.length;g++)h[je+g]=Pe[g];else e.deps=h=Pe;if(En()&&(e.f&$e)!==0)for(g=je;g<h.length;g++)(h[g].reactions??=[]).push(e)}else!m&&h!==null&&je<h.length&&(gr(e,je),h.length=je);if(da()&&Ge!==null&&!tt&&h!==null&&(e.f&(ge|ze|ee))===0)for(g=0;g<Ge.length;g++)Ha(Ge[g],e);if(a!==null&&a!==e){if(zt++,a.deps!==null)for(let x=0;x<r;x+=1)a.deps[x].rv=zt;if(t!==null)for(const x of t)x.rv=zt;Ge!==null&&(n===null?n=Ge:n.push(...Ge))}return(e.f&Xe)!==0&&(e.f^=Xe),v}catch(x){return ya(x)}finally{e.f^=Rt,Pe=t,je=r,Ge=n,j=a,Ye=i,Xt(s),tt=l,Kt=u}}function Fi(e,t){let r=t.reactions;if(r!==null){var n=tn.call(r,e);if(n!==-1){var a=r.length-1;a===0?r=t.reactions=null:(r[n]=r[a],r.pop())}}if(r===null&&(t.f&ge)!==0&&(Pe===null||!At.call(Pe,t))){var i=t;(i.f&$e)!==0&&(i.f^=$e,i.f&=~it),i.v!==de&&pn(i),Mi(i),gr(i,0)}}function gr(e,t){var r=e.deps;if(r!==null)for(var n=t;n<r.length;n++)Fi(e,r[n])}function nr(e){var t=e.f;if((t&Ne)===0){ce(e,Y);var r=I,n=Ur;I=e,Ur=!0;try{(t&(Ie|Jt))!==0?Yi(e):An(e),qa(e);var a=za(e);e.teardown=typeof a=="function"?a:null,e.wv=Fa;var i;K&&fi&&(e.f&ee)!==0&&e.deps}finally{Ur=n,I=r}}}async function Yt(){await Promise.resolve(),q()}function o(e){var t=e.f,r=(t&ge)!==0;if(j!==null&&!tt){var n=I!==null&&(I.f&Ne)!==0;if(!n&&(Ye===null||!At.call(Ye,e))){var a=j.deps;if((j.f&Rt)!==0)e.rv<zt&&(e.rv=zt,Pe===null&&a!==null&&a[je]===e?je++:Pe===null?Pe=[e]:Pe.push(e));else{(j.deps??=[]).push(e);var i=e.reactions;i===null?e.reactions=[j]:At.call(i,j)||i.push(j)}}}if(Et&&Ht.has(e))return Ht.get(e);if(r){var s=e;if(Et){var l=s.v;return((s.f&Y)===0&&s.reactions!==null||Ya(s))&&(l=Sn(s)),Ht.set(s,l),l}var u=(s.f&$e)===0&&!tt&&j!==null&&(Ur||(j.f&$e)!==0),c=(s.f&D)===0;pr(s)&&(u&&(s.f|=$e),Ra(s)),u&&!c&&(Pa(s),Ka(s))}if(et?.has(e))return et.get(e);if((e.f&Xe)!==0)throw e.v;return e.v}function Ka(e){if(e.f|=$e,e.deps!==null)for(const t of e.deps)(t.reactions??=[]).push(e),(t.f&ge)!==0&&(t.f&$e)===0&&(Pa(t),Ka(t))}function Ya(e){if(e.v===de)return!0;if(e.deps===null)return!1;for(const t of e.deps)if(Ht.has(t)||(t.f&ge)!==0&&Ya(t))return!0;return!1}function mr(e){var t=tt;try{return tt=!0,e()}finally{tt=t}}function Vi(e){I===null&&(j===null&&ai(),ni()),Et&&ri()}function Bi(e,t){var r=t.last;r===null?t.last=t.first=e:(r.next=e,e.prev=r,t.last=e)}function rt(e,t){var r=I;r!==null&&(r.f&Ee)!==0&&(e|=Ee);var n={ctx:Re,deps:null,nodes:null,f:e|ee|$e,first:null,fn:t,last:null,next:null,parent:r,b:r&&r.b,prev:null,teardown:null,wv:0,ac:null};P?.register_created_effect(n);var a=n;if((e&ot)!==0)rr!==null?rr.push(n):kt.ensure().schedule(n);else if(t!==null){try{nr(n)}catch(s){throw _e(n),s}a.deps===null&&a.teardown===null&&a.nodes===null&&a.first===a.last&&(a.f&oe)===0&&(a=a.first,(e&Ie)!==0&&(e&fe)!==0&&a!==null&&(a.f|=fe))}if(a!==null&&(a.parent=r,r!==null&&Bi(a,r),j!==null&&(j.f&ge)!==0&&(e&He)===0)){var i=j;(i.effects??=[]).push(a)}return n}function En(){return j!==null&&!tt}function Fr(e){const t=rt(jt,null);return ce(t,Y),t.teardown=e,t}function Oe(e){Vi();var t=I.f,r=!j&&(t&we)!==0&&(t&D)===0;if(r){var n=Re;(n.e??=[]).push(e)}else return Ga(e)}function Ga(e){return rt(ot|or,e)}function Hi(e){kt.ensure();const t=rt(He|oe,e);return()=>{_e(t)}}function zi(e){kt.ensure();const t=rt(He|oe,e);return(r={})=>new Promise(n=>{r.outro?yr(t,()=>{_e(t),n(void 0)}):(_e(t),n(void 0))})}function Cn(e){return rt(ot,e)}function Ki(e){return rt(bt|oe,e)}function Vr(e,t=0){return rt(jt|t,e)}function ke(e,t=[],r=[],n=[]){Ia(n,t,r,a=>{rt(jt,()=>e(...a.map(o)))})}function br(e,t=0){var r=rt(Ie|t,e);return r}function Wa(e,t=0){var r=rt(Jt|t,e);return r}function ft(e){return rt(we|oe,e)}function qa(e){var t=e.teardown;if(t!==null){const r=Et,n=j;ja(!0),Ke(null);try{t.call(null)}finally{ja(r),Ke(n)}}}function An(e,t=!1){var r=e.first;for(e.first=e.last=null;r!==null;){const a=r.ac;a!==null&&jr(()=>{a.abort(Rr)});var n=r.next;(r.f&He)!==0?r.parent=null:_e(r,t),r=n}}function Yi(e){for(var t=e.first;t!==null;){var r=t.next;(t.f&we)===0&&_e(t),t=r}}function _e(e,t=!0){var r=!1;(t||(e.f&le)!==0)&&e.nodes!==null&&e.nodes.end!==null&&(Za(e.nodes.start,e.nodes.end),r=!0),ce(e,te),An(e,t&&!r),gr(e,0);var n=e.nodes&&e.nodes.t;if(n!==null)for(const i of n)i.stop();qa(e),e.f^=te,e.f|=Ne;var a=e.parent;a!==null&&a.first!==null&&Ja(e),e.next=e.prev=e.teardown=e.ctx=e.deps=e.fn=e.nodes=e.ac=e.b=null}function Za(e,t){for(;e!==null;){var r=e===t?null:ct(e);e.remove(),e=r}}function Ja(e){var t=e.parent,r=e.prev,n=e.next;r!==null&&(r.next=n),n!==null&&(n.prev=r),t!==null&&(t.first===e&&(t.first=n),t.last===e&&(t.last=r))}function yr(e,t,r=!0){var n=[];Xa(e,n,!0);var a=()=>{r&&_e(e),t&&t()},i=n.length;if(i>0){var s=()=>--i||a();for(var l of n)l.out(s)}else a()}function Xa(e,t,r){if((e.f&Ee)===0){e.f^=Ee;var n=e.nodes&&e.nodes.t;if(n!==null)for(const l of n)(l.is_global||r)&&t.push(l);for(var a=e.first;a!==null;){var i=a.next;if((a.f&He)===0){var s=(a.f&fe)!==0||(a.f&we)!==0&&(e.f&Ie)!==0;Xa(a,t,s?r:!1)}a=i}}}function Gi(e){Qa(e,!0)}function Qa(e,t){if((e.f&Ee)!==0){e.f^=Ee,(e.f&Y)===0&&(ce(e,ee),kt.ensure().schedule(e));for(var r=e.first;r!==null;){var n=r.next,a=(r.f&fe)!==0||(r.f&we)!==0;Qa(r,a?t:!1),r=n}var i=e.nodes&&e.nodes.t;if(i!==null)for(const s of i)(s.is_global||t)&&s.in()}}function eo(e,t){if(e.nodes)for(var r=e.nodes.start,n=e.nodes.end;r!==null;){var a=r===n?null:ct(r);t.append(r),r=a}}function to(e){const t={get:r=>fr(t.store)[r],set:(r,n)=>{typeof r=="string"?Object.assign(fr(t.store),{[r]:n}):Object.assign(fr(t.store),r),t.store.set(fr(t.store))},store:Si(e)};return t}globalThis.$altcha=globalThis.$altcha||{algorithms:new Map,defaults:to({}),i18n:to({}),instances:new Set,plugins:new Set};const Wi={ariaLinkLabel:"Altcha (official website)",cancel:"Cancel",enterCode:"Enter code",enterCodeAria:"Enter code you hear. Press Space to play audio.",enterCodeFromImage:"To proceed, please enter the code from the image below.",error:"Verification failed. Try again later.",expired:"Verification expired. Try again.",footer:'Protected by <a href="https://altcha.org/" tabindex="-1" target="_blank" aria-label="Altcha (official website)">ALTCHA</a>',getAudioChallenge:"Get an audio challenge",label:"I'm not a robot",loading:"Loading...",reload:"Reload",verify:"Verify",verificationRequired:"Verification required!",verified:"Verified",verifying:"Verifying...",waitAlert:"Verifying... please wait."};globalThis.$altcha.i18n.set("en",Wi);const qi="5";typeof window<"u"&&((window.__svelte??={}).v??=new Set).add(qi);const wr=Symbol("events"),ro=new Set,Tn=new Set;function no(e,t,r,n={}){function a(i){if(n.capture||In.call(t,i),!i.cancelBubble)return jr(()=>r?.call(this,i))}return e.startsWith("pointer")||e.startsWith("touch")||e==="wheel"?_t(()=>{t.addEventListener(e,a,n)}):t.addEventListener(e,a,n),a}function me(e,t,r,n,a){var i={capture:n,passive:a},s=no(e,t,r,i);(t===document.body||t===window||t===document||t instanceof HTMLMediaElement)&&Fr(()=>{t.removeEventListener(e,s,i)})}function Br(e,t,r){(t[wr]??={})[e]=r}function Hr(e){for(var t=0;t<e.length;t++)ro.add(e[t]);for(var r of Tn)r(e)}let ao=null;function In(e){var t=this,r=t.ownerDocument,n=e.type,a=e.composedPath?.()||[],i=a[0]||e.target;ao=e;var s=0,l=ao===e&&e[wr];if(l){var u=a.indexOf(l);if(u!==-1&&(t===document||t===window)){e[wr]=t;return}var c=a.indexOf(t);if(c===-1)return;u<=c&&(s=u)}if(i=a[s]||e.target,i!==t){Tt(e,"currentTarget",{configurable:!0,get(){return i||r}});var d=j,v=I;Ke(null),ut(null);try{for(var h,m=[];i!==null;){var g=i.assignedSlot||i.parentNode||i.host||null;try{var x=i[wr]?.[n];x!=null&&(!i.disabled||e.target===i)&&x.call(i,e)}catch(T){h?m.push(T):h=T}if(e.cancelBubble||g===t||g===null)break;i=g}if(h){for(let T of m)queueMicrotask(()=>{throw T});throw h}}finally{e[wr]=t,delete e.currentTarget,Ke(d),ut(v)}}}const Zi=globalThis?.window?.trustedTypes&&globalThis.window.trustedTypes.createPolicy("svelte-trusted-html",{createHTML:e=>e});function Ji(e){return Zi?.createHTML(e)??e}function oo(e){var t=vn("template");return t.innerHTML=Ji(e.replaceAll("<!>","<!---->")),t.content}function Ue(e,t){var r=I;r.nodes===null&&(r.nodes={start:e,end:t,a:null,t:null})}function ne(e,t){var r=(t&di)!==0,n=(t&hi)!==0,a,i=!e.startsWith("<!>");return()=>{if(R)return Ue(M,null),M;a===void 0&&(a=oo(i?e:"<!>"+e),r||(a=De(a)));var s=n||ga?document.importNode(a,!0):a.cloneNode(!0);if(r){var l=De(s),u=s.lastChild;Ue(l,u)}else Ue(s,s);return s}}function Xi(e,t,r="svg"){var n=!e.startsWith("<!>"),a=`<${r}>${n?e:"<!>"+e}</${r}>`,i;return()=>{if(R)return Ue(M,null),M;if(!i){var s=oo(a),l=De(s);i=De(l)}var u=i.cloneNode(!0);return Ue(u,u),u}}function $n(e,t){return Xi(e,t,"svg")}function zr(e=""){if(!R){var t=lt(e+"");return Ue(t,t),t}var r=M;return r.nodeType!==lr?(r.before(r=lt()),Ce(r)):Pr(r),Ue(r,r),r}function io(){if(R)return Ue(M,null),M;var e=document.createDocumentFragment(),t=document.createComment(""),r=lt();return e.append(t,r),Ue(t,r),e}function N(e,t){if(R){var r=I;((r.f&D)===0||r.nodes.end===null)&&(r.nodes.end=M),Vt();return}e!==null&&e.before(t)}function Qi(e){return e.endsWith("capture")&&e!=="gotpointercapture"&&e!=="lostpointercapture"}const es=["beforeinput","click","change","dblclick","contextmenu","focusin","focusout","input","keydown","keyup","mousedown","mousemove","mouseout","mouseover","mouseup","pointerdown","pointermove","pointerout","pointerover","pointerup","touchend","touchmove","touchstart"];function ts(e){return es.includes(e)}const rs={formnovalidate:"formNoValidate",ismap:"isMap",nomodule:"noModule",playsinline:"playsInline",readonly:"readOnly",defaultvalue:"defaultValue",defaultchecked:"defaultChecked",srcobject:"srcObject",novalidate:"noValidate",allowfullscreen:"allowFullscreen",disablepictureinpicture:"disablePictureInPicture",disableremoteplayback:"disableRemotePlayback"};function ns(e){return e=e.toLowerCase(),rs[e]??e}const as=["touchstart","touchmove"];function os(e){return as.includes(e)}function dt(e,t){var r=t==null?"":typeof t=="object"?`${t}`:t;r!==(e[ln]??=e.nodeValue)&&(e[ln]=r,e.nodeValue=`${r}`)}function so(e,t){return lo(e,t)}function is(e,t){hn(),t.intro=t.intro??!1;const r=t.target,n=R,a=M;try{for(var i=De(r);i&&(i.nodeType!==cr||i.data!==cn);)i=ct(i);if(!i)throw Ut;st(!0),Ce(i);const s=lo(e,{...t,anchor:i});return st(!1),s}catch(s){if(s instanceof Error&&s.message.split(`
`).some(l=>l.startsWith("https://svelte.dev/e/")))throw s;return s!==Ut&&console.warn("Failed to hydrate: ",s),t.recover===!1&&ii(),hn(),xi(r),st(!1),so(e,t)}finally{st(n),Ce(a)}}const Kr=new Map;function lo(e,{target:t,anchor:r,props:n={},events:a,context:i,intro:s=!0,transformError:l}){hn();var u=void 0,c=zi(()=>{var d=r??t.appendChild(lt());$i(d,{pending:()=>{}},m=>{yt({});var g=Re;if(i&&(g.c=i),a&&(n.$$events=a),R&&Ue(m,null),u=e(m,n)||{},R&&(I.nodes.end=M,M===null||M.nodeType!==cr||M.data!==ua))throw ur(),Ut;wt()},l);var v=new Set,h=m=>{for(var g=0;g<m.length;g++){var x=m[g];if(!v.has(x)){v.add(x);var T=os(x);for(const he of[t,document]){var L=Kr.get(he);L===void 0&&(L=new Map,Kr.set(he,L));var ye=L.get(x);ye===void 0?(he.addEventListener(x,In,{passive:T}),L.set(x,1)):L.set(x,ye+1)}}}};return h(mt(ro)),Tn.add(h),()=>{for(var m of v)for(const T of[t,document]){var g=Kr.get(T),x=g.get(m);--x==0?(T.removeEventListener(m,In),g.delete(m),g.size===0&&Kr.delete(T)):g.set(m,x)}Tn.delete(h),d!==r&&d.parentNode?.removeChild(d)}});return Rn.set(u,c),u}let Rn=new WeakMap;function ss(e,t){const r=Rn.get(e);return r?(Rn.delete(e),r(t)):Promise.resolve()}class Yr{anchor;#e=new Map;#t=new Map;#r=new Map;#l=new Set;#n=!0;constructor(t,r=!0){this.anchor=t,this.#n=r}#i=t=>{if(this.#e.has(t)){var r=this.#e.get(t),n=this.#t.get(r);if(n)Gi(n),this.#l.delete(r);else{var a=this.#r.get(r);a&&(this.#t.set(r,a.effect),this.#r.delete(r),a.fragment.lastChild.remove(),this.anchor.before(a.fragment),n=a.effect)}for(const[i,s]of this.#e){if(this.#e.delete(i),i===t)break;const l=this.#r.get(s);l&&(_e(l.effect),this.#r.delete(s))}for(const[i,s]of this.#t){if(i===r||this.#l.has(i))continue;const l=()=>{if(Array.from(this.#e.values()).includes(i)){var c=document.createDocumentFragment();eo(s,c),c.append(lt()),this.#r.set(i,{effect:s,fragment:c})}else _e(s);this.#l.delete(i),this.#t.delete(i)};this.#n||!n?(this.#l.add(i),yr(s,l,!1)):l()}}};#a=t=>{this.#e.delete(t);const r=Array.from(this.#e.values());for(const[n,a]of this.#r)r.includes(n)||(_e(a.effect),this.#r.delete(n))};ensure(t,r){var n=P;r&&!this.#t.has(t)&&!this.#r.has(t)&&this.#t.set(t,ft(()=>r(this.anchor))),this.#e.set(n,t),R&&(this.anchor=M),this.#i(n)}}function ls(e,t,...r){var n=new Yr(e);br(()=>{const a=t()??null;n.ensure(a,a&&(i=>a(i,...r)))},fe)}function Pn(e){Re===null&&ei(),Oe(()=>{const t=mr(e);if(typeof t=="function")return t})}function be(e,t,r=!1){var n;R&&(n=M,Vt());var a=new Yr(e),i=r?fe:0;function s(l,u){if(R){var c=va(n);if(l!==parseInt(c.substring(1))){var d=fn();Ce(d),a.anchor=d,st(!1),a.ensure(l,u),st(!0);return}}a.ensure(l,u)}br(()=>{var l=!1;t((u,c=0)=>{l=!0,s(c,u)}),l||s(-1,null)},i)}const cs=Symbol("NaN");function us(e,t,r){R&&Vt();var n=new Yr(e);br(()=>{var a=t();a!==a&&(a=cs),n.ensure(a,r)})}function co(e,t,r=!1,n=!1,a=!1,i=!1){var s=e,l="";if(r){var u=e;R&&(s=Ce(De(u)))}ke(()=>{var c=I;if(l===(l=t()??"")){R&&Vt();return}if(r&&!R){c.nodes=null,u.innerHTML=l,l!==""&&Ue(De(u),u.lastChild);return}if(c.nodes!==null&&(Za(c.nodes.start,c.nodes.end),c.nodes=null),l!==""){if(R){M.data;for(var d=Vt(),v=d;d!==null&&(d.nodeType!==cr||d.data!=="");)v=d,d=ct(d);if(d===null)throw ur(),Ut;Ue(M,v),s=Ce(d);return}var h=n?vi:a?pi:void 0,m=vn(n?"svg":a?"math":"template",h);m.innerHTML=l;var g=n||a?m:m.content;if(Ue(De(g),g.lastChild),n||a)for(;De(g);)s.before(De(g));else s.before(g)}})}function fs(e,t,r){var n;R&&(n=M,Vt());var a=new Yr(e);br(()=>{var i=t()??null;if(R){var s=va(n),l=s===cn,u=i!==null;if(l!==u){var c=fn();Ce(c),a.anchor=c,st(!1),a.ensure(i,i&&(d=>r(d,i))),st(!0);return}}a.ensure(i,i&&(d=>r(d,i)))},fe)}function ds(e,t){var r=void 0,n;Wa(()=>{r!==(r=t())&&(n&&(_e(n),n=null),r&&(n=ft(()=>{Cn(()=>r(e))})))})}function uo(e){var t,r,n="";if(typeof e=="string"||typeof e=="number")n+=e;else if(typeof e=="object")if(Array.isArray(e)){var a=e.length;for(t=0;t<a;t++)e[t]&&(r=uo(e[t]))&&(n&&(n+=" "),n+=r)}else for(r in e)e[r]&&(n&&(n+=" "),n+=r);return n}function hs(){for(var e,t,r=0,n="",a=arguments.length;r<a;r++)(e=arguments[r])&&(t=uo(e))&&(n&&(n+=" "),n+=t);return n}function vs(e){return typeof e=="object"?hs(e):e??""}const fo=[...` 	
\r\f \v\uFEFF`];function ps(e,t,r){var n=e==null?"":""+e;if(r){for(var a of Object.keys(r))if(r[a])n=n?n+" "+a:a;else if(n.length)for(var i=a.length,s=0;(s=n.indexOf(a,s))>=0;){var l=s+i;(s===0||fo.includes(n[s-1]))&&(l===n.length||fo.includes(n[l]))?n=(s===0?"":n.substring(0,s))+n.substring(l+1):s=l}}return n===""?null:n}function ho(e,t=!1){var r=t?" !important;":";",n="";for(var a of Object.keys(e)){var i=e[a];i!=null&&i!==""&&(n+=" "+a+": "+i+r)}return n}function On(e){return e[0]!=="-"||e[1]!=="-"?e.toLowerCase():e}function gs(e,t){if(t){var r="",n,a;if(Array.isArray(t)?(n=t[0],a=t[1]):n=t,e){e=String(e).replaceAll(/\s*\/\*.*?\*\/\s*/g,"").trim();var i=!1,s=0,l=!1,u=[];n&&u.push(...Object.keys(n).map(On)),a&&u.push(...Object.keys(a).map(On));var c=0,d=-1;const x=e.length;for(var v=0;v<x;v++){var h=e[v];if(l?h==="/"&&e[v-1]==="*"&&(l=!1):i?i===h&&(i=!1):h==="/"&&e[v+1]==="*"?l=!0:h==='"'||h==="'"?i=h:h==="("?s++:h===")"&&s--,!l&&i===!1&&s===0){if(h===":"&&d===-1)d=v;else if(h===";"||v===x-1){if(d!==-1){var m=On(e.substring(c,d).trim());if(!u.includes(m)){h!==";"&&v++;var g=e.substring(c,v).trim();r+=" "+g+";"}}c=v+1,d=-1}}}}return n&&(r+=ho(n)),a&&(r+=ho(a,!0)),r=r.trim(),r===""?null:r}return e==null?null:String(e)}function ms(e,t,r,n,a,i){var s=e[on];if(R||s!==r||s===void 0){var l=ps(r,n,i);(!R||l!==e.getAttribute("class"))&&(l==null?e.removeAttribute("class"):t?e.className=l:e.setAttribute("class",l)),e[on]=r}else if(i&&a!==i)for(var u in i){var c=!!i[u];(a==null||c!==!!a[u])&&e.classList.toggle(u,c)}return i}function Ln(e,t={},r,n){for(var a in r){var i=r[a];t[a]!==i&&(r[a]==null?e.style.removeProperty(a):e.style.setProperty(a,i,n))}}function bs(e,t,r,n){var a=e[sn];if(R||a!==t){var i=gs(t,n);(!R||i!==e.getAttribute("style"))&&(i==null?e.removeAttribute("style"):e.style.cssText=i),e[sn]=t}else n&&(Array.isArray(n)?(Ln(e,r?.[0],n[0]),Ln(e,r?.[1],n[1],"important")):Ln(e,r,n));return n}function Mn(e,t,r=!1){if(e.multiple){if(t==null)return;if(!Ct(t))return yi();for(var n of e.options)n.selected=t.includes(vo(n));return}for(n of e.options){var a=vo(n);if(_i(a,t)){n.selected=!0;return}}(!r||t!==void 0)&&(e.selectedIndex=-1)}function ys(e){var t=new MutationObserver(()=>{Mn(e,e.__value)});t.observe(e,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value"]}),Fr(()=>{t.disconnect()})}function vo(e){return"__value"in e?e.__value:e.value}const _r=Symbol("class"),xr=Symbol("style"),po=Symbol("is custom element"),go=Symbol("is html"),ws=sr?"link":"LINK",_s=sr?"input":"INPUT",xs=sr?"option":"OPTION",ks=sr?"select":"SELECT",Ss=sr?"progress":"PROGRESS";function Nn(e){if(R){var t=!1,r=()=>{if(!t){if(t=!0,e.hasAttribute("value")){var n=e.value;H(e,"value",null),e.value=n}if(e.hasAttribute("checked")){var a=e.checked;H(e,"checked",null),e.checked=a}}};e[ir]=r,_t(r),Da()}}function Es(e,t){var r=Dn(e);r.value===(r.value=t??void 0)||e.value===t&&(t!==0||e.nodeName!==Ss)||(e.value=t??"")}function Cs(e,t){t?e.hasAttribute("selected")||e.setAttribute("selected",""):e.removeAttribute("selected")}function H(e,t,r,n){var a=Dn(e);R&&(a[t]=e.getAttribute(t),t==="src"||t==="srcset"||t==="href"&&e.nodeName===ws)||a[t]!==(a[t]=r)&&(t==="loading"&&(e[Xo]=r),r==null?e.removeAttribute(t):typeof r!="string"&&bo(e).includes(t)?e[t]=r:e.setAttribute(t,r))}function As(e,t,r,n,a=!1,i=!1){if(R&&a&&e.nodeName===_s){var s=e,l=s.type==="checkbox"?"defaultChecked":"defaultValue";l in r||Nn(s)}var u=Dn(e),c=u[po],d=!u[go];let v=R&&c;v&&st(!1);var h=t||{},m=e.nodeName===xs;for(var g in t)g in r||(r[g]=null);r.class?r.class=vs(r.class):r[_r]&&(r.class=null),r[xr]&&(r.style??=null);var x=bo(e);for(const F in r){let E=r[F];if(m&&F==="value"&&E==null){e.value=e.__value="",h[F]=E;continue}if(F==="class"){var T=e.namespaceURI==="http://www.w3.org/1999/xhtml";ms(e,T,E,n,t?.[_r],r[_r]),h[F]=E,h[_r]=r[_r];continue}if(F==="style"){bs(e,E,t?.[xr],r[xr]),h[F]=E,h[xr]=r[xr];continue}var L=h[F];if(!(E===L&&!(E===void 0&&e.hasAttribute(F)))){h[F]=E;var ye=F[0]+F[1];if(ye!=="$$")if(ye==="on"){const X={},Te="$$"+F;let $=F.slice(2);var he=ts($);if(Qi($)&&($=$.slice(0,-7),X.capture=!0),!he&&L){if(E!=null)continue;e.removeEventListener($,h[Te],X),h[Te]=null}if(he)Br($,e,E),Hr([$]);else if(E!=null){let ve=function(ht){h[F].call(this,ht)};h[Te]=no($,e,ve,X)}}else if(F==="style")H(e,F,E);else if(F==="autofocus")Di(e,!!E);else if(!c&&(F==="__value"||F==="value"&&E!=null))e.value=e.__value=E;else if(F==="selected"&&m)Cs(e,E);else{var U=F;d||(U=ns(U));var Se=U==="defaultValue"||U==="defaultChecked";if(E==null&&!c&&!Se)if(u[F]=null,U==="value"||U==="checked"){let X=e;const Te=t===void 0;if(U==="value"){let $=X.defaultValue;X.removeAttribute(U),X.defaultValue=$,X.value=X.__value=Te?$:null}else{let $=X.defaultChecked;X.removeAttribute(U),X.defaultChecked=$,X.checked=Te?$:!1}}else e.removeAttribute(F);else Se||x.includes(U)&&(c||typeof E!="string")?(e[U]=E,U in u&&(u[U]=de)):typeof E!="function"&&H(e,U,E)}}}return v&&st(!0),h}function Gr(e,t,r=[],n=[],a=[],i,s=!1,l=!1){Ia(a,r,n,u=>{var c=void 0,d={},v=e.nodeName===ks,h=!1;if(Wa(()=>{var g=t(...u.map(o)),x=As(e,c,g,i,s,l);h&&v&&"value"in g&&Mn(e,g.value);for(let L of Object.getOwnPropertySymbols(d))g[L]||_e(d[L]);for(let L of Object.getOwnPropertySymbols(g)){var T=g[L];L.description===gi&&(!c||T!==c[L])&&(d[L]&&_e(d[L]),d[L]=ft(()=>ds(e,()=>T))),x[L]=T}c=x}),v){var m=e;Cn(()=>{Mn(m,c.value,!0),ys(m)})}h=!0})}function Dn(e){return e[oa]??={[po]:e.nodeName.includes("-"),[go]:e.namespaceURI===fa}}var mo=new Map;function bo(e){var t=e.getAttribute("is")||e.nodeName,r=mo.get(t);if(r)return r;mo.set(t,r=[]);for(var n,a=e,i=Element.prototype;i!==a;){n=Tr(a);for(var s in n)n[s].set&&s!=="innerHTML"&&s!=="textContent"&&s!=="innerText"&&r.push(s);a=at(a)}return r}function Ts(e,t,r=t){var n=new WeakSet;ji(e,"input",async a=>{var i=a?e.defaultValue:e.value;if(i=jn(e)?Un(i):i,r(i),P!==null&&n.add(P),await Yt(),i!==(i=t())){var s=e.selectionStart,l=e.selectionEnd,u=e.value.length;if(e.value=i??"",l!==null){var c=e.value.length;s===l&&l===u&&c>u?(e.selectionStart=c,e.selectionEnd=c):(e.selectionStart=s,e.selectionEnd=Math.min(l,c))}}}),(R&&e.defaultValue!==e.value||mr(t)==null&&e.value)&&(r(jn(e)?Un(e.value):e.value),P!==null&&n.add(P)),Vr(()=>{var a=t();if(e===document.activeElement){var i=P;if(n.has(i))return}jn(e)&&a===Un(e.value)||e.type==="date"&&!a&&!e.value||a!==e.value&&(e.value=a??"")})}function jn(e){var t=e.type;return t==="number"||t==="range"}function Un(e){return e===""?null:+e}function Fn(e,t){return e===t||e?.[Qe]===t}function Ot(e={},t,r,n){var a=Re.r,i=I;return Cn(()=>{var s,l;return Vr(()=>{s=l,l=[],mr(()=>{Fn(r(...l),e)||(t(e,...l),s&&Fn(r(...s),e)&&t(null,...s))})}),()=>{let u=i;for(;u!==a&&u.parent!==null&&u.parent.f&te;)u=u.parent;const c=()=>{l&&Fn(r(...l),e)&&t(null,...l)},d=u.teardown;u.teardown=()=>{c(),d?.()}}}),e}const Is={get(e,t){if(!e.exclude.includes(t))return e.props[t]},set(e,t){return!1},getOwnPropertyDescriptor(e,t){if(!e.exclude.includes(t)&&t in e.props)return{enumerable:!0,configurable:!0,value:e.props[t]}},has(e,t){return e.exclude.includes(t)?!1:t in e.props},ownKeys(e){return Reflect.ownKeys(e.props).filter(t=>!e.exclude.includes(t))}};function Wr(e,t,r){return new Proxy({props:e,exclude:t},Is)}function ae(e,t,r,n){var a=n,i=!0,s=()=>(i&&(i=!1,a=n),a),l;l=e[t],l===void 0&&n!==void 0&&(l=s());var u;u=()=>{var h=e[t];return h===void 0?s():(i=!0,h)};var c=!1,d=kn(()=>(c=!1,u())),v=I;return(function(h,m){if(arguments.length>0){const g=m?o(d):h;return w(d,g),c=!0,a!==void 0&&(a=g),h}return Et&&c||(v.f&Ne)!==0?d.v:o(d)})}function $s(e){return new Rs(e)}class Rs{#e;#t;constructor(t){var r=new Map,n=(i,s)=>{var l=La(s,!1,!1);return r.set(i,l),l};const a=new Proxy({...t.props||{},$$events:{}},{get(i,s){return o(r.get(s)??n(s,Reflect.get(i,s)))},has(i,s){return s===an?!0:(o(r.get(s)??n(s,Reflect.get(i,s))),Reflect.has(i,s))},set(i,s,l){return w(r.get(s)??n(s,l),l),Reflect.set(i,s,l)}});this.#t=(t.hydrate?is:so)(t.component,{target:t.target,anchor:t.anchor,props:a,context:t.context,intro:t.intro??!1,recover:t.recover,transformError:t.transformError}),(!t?.props?.$$host||t.sync===!1)&&q(),this.#e=a.$$events;for(const i of Object.keys(this.#t))i==="$set"||i==="$destroy"||i==="$on"||Tt(this,i,{get(){return this.#t[i]},set(s){this.#t[i]=s},enumerable:!0});this.#t.$set=i=>{Object.assign(a,i)},this.#t.$destroy=()=>{ss(this.#t)}}$set(t){this.#t.$set(t)}$on(t,r){this.#e[t]=this.#e[t]||[];const n=(...a)=>r.call(this,...a);return this.#e[t].push(n),()=>{this.#e[t]=this.#e[t].filter(a=>a!==n)}}$destroy(){this.#t.$destroy()}}let yo=class{};typeof HTMLElement=="function"&&(yo=class extends HTMLElement{$$ctor;$$s;$$c;$$cn=!1;$$d={};$$r=!1;$$p_d={};$$l={};$$l_u=new Map;$$me;$$shadowRoot=null;constructor(e,t,r){super(),this.$$ctor=e,this.$$s=t,r&&(this.$$shadowRoot=this.attachShadow(r))}addEventListener(e,t,r){if(this.$$l[e]=this.$$l[e]||[],this.$$l[e].push(t),this.$$c){const n=this.$$c.$on(e,t);this.$$l_u.set(t,n)}super.addEventListener(e,t,r)}removeEventListener(e,t,r){if(super.removeEventListener(e,t,r),this.$$c){const n=this.$$l_u.get(t);n&&(n(),this.$$l_u.delete(t))}}async connectedCallback(){if(this.$$cn=!0,!this.$$c){let e=function(n){return a=>{const i=vn("slot");n!=="default"&&(i.name=n),N(a,i)}};if(await Promise.resolve(),!this.$$cn||this.$$c)return;const t={},r=Ps(this);for(const n of this.$$s)n in r&&(n==="default"&&!this.$$d.children?(this.$$d.children=e(n),t.default=!0):t[n]=e(n));for(const n of this.attributes){const a=this.$$g_p(n.name);a in this.$$d||(this.$$d[a]=qr(a,n.value,this.$$p_d,"toProp"))}for(const n in this.$$p_d)!(n in this.$$d)&&this[n]!==void 0&&(this.$$d[n]=this[n],delete this[n]);this.$$c=$s({component:this.$$ctor,target:this.$$shadowRoot||this,props:{...this.$$d,$$slots:t,$$host:this}}),this.$$me=Hi(()=>{Vr(()=>{this.$$r=!0;for(const n of Dt(this.$$c)){if(!this.$$p_d[n]?.reflect)continue;this.$$d[n]=this.$$c[n];const a=qr(n,this.$$d[n],this.$$p_d,"toAttribute");a==null?this.removeAttribute(this.$$p_d[n].attribute||n):this.setAttribute(this.$$p_d[n].attribute||n,a)}this.$$r=!1})});for(const n in this.$$l)for(const a of this.$$l[n]){const i=this.$$c.$on(n,a);this.$$l_u.set(a,i)}this.$$l={}}}attributeChangedCallback(e,t,r){this.$$r||(e=this.$$g_p(e),this.$$d[e]=qr(e,r,this.$$p_d,"toProp"),this.$$c?.$set({[e]:this.$$d[e]}))}disconnectedCallback(){this.$$cn=!1,Promise.resolve().then(()=>{!this.$$cn&&this.$$c&&(this.$$c.$destroy(),this.$$me(),this.$$c=void 0)})}$$g_p(e){return Dt(this.$$p_d).find(t=>this.$$p_d[t].attribute===e||!this.$$p_d[t].attribute&&t.toLowerCase()===e)||e}});function qr(e,t,r,n){const a=r[e]?.type;if(t=a==="Boolean"&&typeof t!="boolean"?t!=null:t,!n||!r[e])return t;if(n==="toAttribute")switch(a){case"Object":case"Array":return t==null?null:JSON.stringify(t);case"Boolean":return t?"":null;case"Number":return t??null;default:return t}else switch(a){case"Object":case"Array":return t&&JSON.parse(t);case"Boolean":return t;case"Number":return t!=null?+t:t;default:return t}}function Ps(e){const t={};return e.childNodes.forEach(r=>{t[r.slot||"default"]=!0}),t}function Lt(e,t,r,n,a,i){let s=class extends yo{constructor(){super(e,r,a),this.$$p_d=t}static get observedAttributes(){return Dt(t).map(l=>(t[l].attribute||l).toLowerCase())}};return Dt(t).forEach(l=>{Tt(s.prototype,l,{get(){return this.$$c&&l in this.$$c?this.$$c[l]:this.$$d[l]},set(u){u=qr(l,u,t),this.$$d[l]=u;var c=this.$$c;if(c){var d=It(c,l)?.get;d?c[l]=u:c.$set({[l]:u})}}})}),n.forEach(l=>{Tt(s.prototype,l,{get(){return this.$$c?.[l]}})}),e.element=s,s}var Os=ne('<div class="altcha-checkbox"><input/> <svg aria-hidden="true" width="12" height="9" viewBox="0 0 12 9"><polyline points="1 5 4 8 11 1"></polyline></svg> <div class="altcha-spinner altcha-checkbox-spinner" aria-hidden="true"></div></div>');function wo(e,t){yt(t,!0);let r=ae(t,"loading"),n=Wr(t,["$$slots","$$events","$$legacy","$$host","loading"]),a;function i(){a?.click()}var s={get loading(){return r()},set loading(d){r(d),q()}},l=Os(),u=ie(l);Gr(u,()=>({type:"checkbox",...n}),void 0,void 0,void 0,void 0,!0),Ot(u,d=>a=d,()=>a);var c=re(u,2);return un(2),J(l),ke(()=>H(l,"data-loading",r())),Br("click",c,i),N(e,l),wt(s)}Hr(["click"]),Lt(wo,{loading:{}},[],[],{mode:"open"});var Ls=ne('<div class="altcha-checkbox-native"><input/> <div class="altcha-spinner altcha-checkbox-native-spinner"></div></div>');function _o(e,t){yt(t,!0);let r=ae(t,"loading"),n=Wr(t,["$$slots","$$events","$$legacy","$$host","loading"]);var a={get loading(){return r()},set loading(l){r(l),q()}},i=Ls(),s=ie(i);return Gr(s,()=>({type:"checkbox",...n}),void 0,void 0,void 0,void 0,!0),un(2),J(i),ke(()=>H(i,"data-loading",r())),N(e,i),wt(a)}Lt(_o,{loading:{}},[],[],{mode:"open"});var Ms=ne('<div><a target="_blank" class="altcha-logo" aria-hidden="true" tabindex="-1"><svg width="22" height="22" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.33955 16.4279C5.88954 20.6586 12.1971 21.2105 16.4279 17.6604C18.4699 15.947 19.6548 13.5911 19.9352 11.1365L17.9886 10.4279C17.8738 12.5624 16.909 14.6459 15.1423 16.1284C11.7577 18.9684 6.71167 18.5269 3.87164 15.1423C1.03163 11.7577 1.4731 6.71166 4.8577 3.87164C8.24231 1.03162 13.2883 1.4731 16.1284 4.8577C16.9767 5.86872 17.5322 7.02798 17.804 8.2324L19.9522 9.01429C19.7622 7.07737 19.0059 5.17558 17.6604 3.57212C14.1104 -0.658624 7.80283 -1.21043 3.57212 2.33956C-0.658625 5.88958 -1.21046 12.1971 2.33955 16.4279Z" fill="currentColor"></path><path d="M3.57212 2.33956C1.65755 3.94607 0.496389 6.11731 0.12782 8.40523L2.04639 9.13961C2.26047 7.15832 3.21057 5.25375 4.8577 3.87164C8.24231 1.03162 13.2883 1.4731 16.1284 4.8577L13.8302 6.78606L19.9633 9.13364C19.7929 7.15555 19.0335 5.20847 17.6604 3.57212C14.1104 -0.658624 7.80283 -1.21043 3.57212 2.33956Z" fill="currentColor"></path><path d="M7 10H5C5 12.7614 7.23858 15 10 15C12.7614 15 15 12.7614 15 10H13C13 11.6569 11.6569 13 10 13C8.3431 13 7 11.6569 7 10Z" fill="currentColor"></path></svg></a></div>');function Vn(e,t){yt(t,!0);let r=ae(t,"strings");const n="https://altcha.org";var a={get strings(){return r()},set strings(l){r(l),q()}},i=Ms(),s=ie(i);return H(s,"href",n),J(i),ke(()=>H(s,"aria-label",r().ariaLinkLabel)),N(e,i),wt(a)}Lt(Vn,{strings:{}},[],[],{mode:"open"});var Ns=ne('<div class="altcha-footer"><p></p> <!></div>');function Bn(e,t){yt(t,!0);let r=ae(t,"logo"),n=ae(t,"strings");var a={get logo(){return r()},set logo(c){r(c),q()},get strings(){return n()},set strings(c){n(c),q()}},i=Ns(),s=ie(i);co(s,()=>n().footer,!0),J(s);var l=re(s,2);{var u=c=>{Vn(c,{get strings(){return n()}})};be(l,c=>{r()&&c(u)})}return J(i),N(e,i),wt(a)}Lt(Bn,{logo:{},strings:{}},[],[],{mode:"open"});var Ds=ne('<div class="altcha-switch"><input/>  <div class="altcha-switch-toggle"><div class="altcha-spinner altcha-switch-spinner"></div></div></div>');function xo(e,t){yt(t,!0);let r=ae(t,"loading"),n=Wr(t,["$$slots","$$events","$$legacy","$$host","loading"]),a;function i(){a?.click()}var s={get loading(){return r()},set loading(d){r(d),q()}},l=Ds(),u=ie(l);Gr(u,()=>({type:"checkbox",...n}),void 0,void 0,void 0,void 0,!0),Ot(u,d=>a=d,()=>a);var c=re(u,2);return J(l),ke(()=>H(l,"data-loading",r())),Br("click",c,i),N(e,l),wt(s)}Hr(["click"]),Lt(xo,{loading:{}},[],[],{mode:"open"});var xe=(e=>(e.ERROR="error",e.LOADING="loading",e.PLAYING="playing",e.PAUSED="paused",e.READY="ready",e))(xe||{}),B=(e=>(e.CODE="code",e.ERROR="error",e.VERIFIED="verified",e.VERIFYING="verifying",e.UNVERIFIED="unverified",e.EXPIRED="expired",e))(B||{}),js=ne('<div class="altcha-code-challenge-title"> </div>'),Us=ne('<div class="altcha-spinner"></div>'),Fs=$n('<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12.8659 3.00017L22.3922 19.5002C22.6684 19.9785 22.5045 20.5901 22.0262 20.8662C21.8742 20.954 21.7017 21.0002 21.5262 21.0002H2.47363C1.92135 21.0002 1.47363 20.5525 1.47363 20.0002C1.47363 19.8246 1.51984 19.6522 1.60761 19.5002L11.1339 3.00017C11.41 2.52187 12.0216 2.358 12.4999 2.63414C12.6519 2.72191 12.7782 2.84815 12.8659 3.00017ZM10.9999 16.0002V18.0002H12.9999V16.0002H10.9999ZM10.9999 9.00017V14.0002H12.9999V9.00017H10.9999Z"></path></svg>'),Vs=$n('<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M15 7C15 6.44772 15.4477 6 16 6C16.5523 6 17 6.44772 17 7V17C17 17.5523 16.5523 18 16 18C15.4477 18 15 17.5523 15 17V7ZM7 7C7 6.44772 7.44772 6 8 6C8.55228 6 9 6.44772 9 7V17C9 17.5523 8.55228 18 8 18C7.44772 18 7 17.5523 7 17V7Z"></path></svg>'),Bs=$n('<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M4 12H7C8.10457 12 9 12.8954 9 14V19C9 20.1046 8.10457 21 7 21H4C2.89543 21 2 20.1046 2 19V12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12V19C22 20.1046 21.1046 21 20 21H17C15.8954 21 15 20.1046 15 19V14C15 12.8954 15.8954 12 17 12H20C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12Z"></path></svg>'),Hs=ne('<button type="button" class="altcha-button altcha-button-secondary"><!></button>'),zs=ne('<audio hidden="" autoplay=""></audio>'),Ks=ne('<div class="altcha-code-challenge"><form data-code-challenge="true"><!> <div class="altcha-code-challenge-text"> </div> <img class="altcha-code-challenge-image" alt=""/> <div class="altcha-code-challenge-row"><input type="text" class="altcha-input" autocomplete="off" name="" required=""/> <!> <button type="button" class="altcha-button altcha-button-secondary"><svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2V4C16.4183 4 20 7.58172 20 12C20 16.4183 16.4183 20 12 20C7.58172 20 4 16.4183 4 12C4 9.25022 5.38734 6.82447 7.50024 5.38451L7.5 8H9.5V2L3.5 2V4L5.99918 3.99989C3.57075 5.82434 2 8.72873 2 12Z"></path></svg></button></div> <div class="altcha-code-challenge-buttons"><button type="submit" class="altcha-button"> </button> <button type="button" class="altcha-button altcha-button-secondary"> </button></div></form> <!></div>');function ko(e,t){yt(t,!0);let r=ae(t,"audioUrl"),n=ae(t,"codeChallenge"),a=ae(t,"config"),i=ae(t,"imageUrl"),s=ae(t,"onCancel"),l=ae(t,"onReload"),u=ae(t,"onSubmit"),c=ae(t,"strings"),d=O(void 0),v=O(void 0),h=O(void 0),m=O(!1),g=O(""),x=O(!1);Pn(()=>(a().disableAutoFocus||Yt().then(()=>{o(h)?.focus()}),()=>{o(v)&&(o(v).pause(),w(v,void 0))}));function T(){w(d,xe.PAUSED,!0)}function L(y){w(d,xe.ERROR,!0)}function ye(){w(d,xe.READY,!0)}function he(){w(d,xe.LOADING,!0)}function U(){w(d,xe.PLAYING,!0)}function Se(){w(d,xe.PAUSED,!0)}function F(y){y.code==="Space"?(y.preventDefault(),y.stopPropagation(),X()):y.code==="Escape"&&(y.preventDefault(),y.stopPropagation(),s()?.())}function E(y){y.preventDefault(),y.stopPropagation(),u()?.(o(g))}function X(){o(v)?o(d)===xe.LOADING||(o(v).paused?(r()&&o(v).src!==r()&&(o(v).src=r()),o(v).currentTime=0,o(v).play()):o(v).pause()):(w(x,!0),requestAnimationFrame(()=>{o(v)&&r()&&(o(v).src=r(),o(v).play())}))}var Te={get audioUrl(){return r()},set audioUrl(y){r(y),q()},get codeChallenge(){return n()},set codeChallenge(y){n(y),q()},get config(){return a()},set config(y){a(y),q()},get imageUrl(){return i()},set imageUrl(y){i(y),q()},get onCancel(){return s()},set onCancel(y){s(y),q()},get onReload(){return l()},set onReload(y){l(y),q()},get onSubmit(){return u()},set onSubmit(y){u(y),q()},get strings(){return c()},set strings(y){c(y),q()}},$=Ks(),ve=ie($),ht=ie(ve);{var Fe=y=>{var ue=js(),qt=ie(ue,!0);J(ue),ke(()=>dt(qt,c().verificationRequired)),N(y,ue)};be(ht,y=>{a().codeChallengeDisplay!=="standard"&&y(Fe)})}var Le=re(ht,2),se=ie(Le,!0);J(Le);var vt=re(Le,2),S=re(vt,2),G=ie(S);Nn(G),G.disabled=o(m),Ot(G,y=>w(h,y),()=>o(h));var Ve=re(G,2);{var b=y=>{var ue=Hs(),qt=ie(ue);{var Gn=Me=>{var pt=Us();N(Me,pt)},Cr=Me=>{var pt=Fs();N(Me,pt)},Wn=Me=>{var pt=Vs();N(Me,pt)},qn=Me=>{var pt=Bs();N(Me,pt)};be(qt,Me=>{o(d)===xe.LOADING?Me(Gn):o(d)===xe.ERROR?Me(Cr,1):o(d)===xe.PLAYING?Me(Wn,2):Me(qn,-1)})}J(ue),ke(()=>{H(ue,"title",c().getAudioChallenge),ue.disabled=o(d)===xe.LOADING||o(d)===xe.ERROR,H(ue,"aria-label",o(d)===xe.LOADING?c().loading:c().getAudioChallenge)}),me("click",ue,()=>X(),!0),N(y,ue)};be(Ve,y=>{n().audio&&y(b)})}var Gt=re(Ve,2);J(S);var Zr=re(S,2),We=ie(Zr),Yn=ie(We,!0);J(We);var Wt=re(We,2),kr=ie(Wt,!0);J(Wt),J(Zr),J(ve);var Sr=re(ve,2);{var Er=y=>{var ue=zs();Ot(ue,qt=>w(v,qt),()=>o(v)),me("error",ue,L),me("loadstart",ue,he),me("canplay",ue,ye),me("pause",ue,Se),me("playing",ue,U),me("ended",ue,T),N(y,ue)};be(Sr,y=>{o(x)&&y(Er)})}return J($),ke(()=>{dt(se,c().enterCodeFromImage),H(vt,"src",i()),H(G,"minlength",n().length||1),H(G,"maxlength",n().length),H(G,"placeholder",c().enterCode),H(G,"aria-label",o(d)===xe.LOADING?c().loading:o(d)===xe.PLAYING?"":c().enterCodeAria),H(G,"aria-live",o(d)?"assertive":"polite"),H(G,"aria-busy",o(d)===xe.LOADING),H(Gt,"title",c().reload),H(Gt,"aria-label",c().reload),H(We,"aria-label",c().verify),dt(Yn,c().verify),H(Wt,"aria-label",c().cancel),dt(kr,c().cancel)}),me("submit",ve,E,!0),Br("keydown",G,F),Ts(G,()=>o(g),y=>w(g,y)),me("click",Gt,()=>l()?.(),!0),me("click",Wt,()=>s()?.(),!0),N(e,$),wt(Te)}Hr(["keydown"]),Lt(ko,{audioUrl:{},codeChallenge:{},config:{},imageUrl:{},onCancel:{},onReload:{},onSubmit:{},strings:{}},[],[],{mode:"open"});var Ys=ne('<div class="altcha-popover-backdrop" data-backdrop=""></div>'),Gs=ne('<div class="altcha-popover-arrow"></div>'),Ws=ne('<div role="button" class="altcha-popover-close">&times;</div>'),qs=ne('<!> <div><!> <!> <div class="altcha-popover-content"><!></div></div>',1);function Hn(e,t){yt(t,!0);let r=ae(t,"anchor"),n=ae(t,"children"),a=ae(t,"display",7,"standard"),i=ae(t,"backdrop",7,!1),s=ae(t,"onClickOutside"),l=ae(t,"onClickOutsideDelay",7,600),u=ae(t,"onClose"),c=ae(t,"placement",7,"auto"),d=ae(t,"updateUISignal"),v=ae(t,"variant",7,"neutral"),h=Wr(t,["$$slots","$$events","$$legacy","$$host","anchor","children","display","backdrop","onClickOutside","onClickOutsideDelay","onClose","placement","updateUISignal","variant"]),m=O(void 0),g=O(void 0),x=O(!1),T=O(0);Oe(()=>{c()!=="auto"&&w(x,c()==="top")}),Oe(()=>{d()&&Se()}),Pn(()=>{const S=a()==="bottomsheet"||a()==="overlay";return S&&(o(g)&&document.body.append(o(g)),o(m)&&document.body.append(o(m))),Se(),Yt().then(()=>{w(T,Date.now(),!0)}),()=>{S&&(o(g)&&document.body.removeChild(o(g)),o(m)&&document.body.removeChild(o(m)))}});function L(){u()?.()}function ye(S){const G=S.target;!o(m)?.contains(G)&&(!l()||o(T)+l()<Date.now())&&s()?.()}function he(){Se()}function U(){Se()}function Se(){if(r()&&c()==="auto"&&o(m)){const S=r().getBoundingClientRect(),Ve=document.documentElement.clientHeight-(S.top+S.height)<o(m).clientHeight;o(x)!==Ve&&w(x,Ve)}}var F={get anchor(){return r()},set anchor(S){r(S),q()},get children(){return n()},set children(S){n(S),q()},get display(){return a()},set display(S="standard"){a(S),q()},get backdrop(){return i()},set backdrop(S=!1){i(S),q()},get onClickOutside(){return s()},set onClickOutside(S){s(S),q()},get onClickOutsideDelay(){return l()},set onClickOutsideDelay(S=600){l(S),q()},get onClose(){return u()},set onClose(S){u(S),q()},get placement(){return c()},set placement(S="auto"){c(S),q()},get updateUISignal(){return d()},set updateUISignal(S){d(S),q()},get variant(){return v()},set variant(S="neutral"){v(S),q()}},E=qs();me("click",Bt,ye,!0),me("resize",Bt,he),me("scroll",Bt,U);var X=Qt(E);{var Te=S=>{var G=Ys();Ot(G,Ve=>w(g,Ve),()=>o(g)),N(S,G)};be(X,S=>{i()&&S(Te)})}var $=re(X,2);Gr($,()=>({...h,class:`altcha-popover ${(t.class||"")??""}`,"data-popover":!0,"data-variant":v(),"data-top":o(x),"data-display":a()}));var ve=ie($);{var ht=S=>{var G=Gs();N(S,G)};be(ve,S=>{a()==="standard"&&S(ht)})}var Fe=re(ve,2);{var Le=S=>{var G=Ws();me("click",G,L,!0),N(S,G)};be(Fe,S=>{a()!=="standard"&&S(Le)})}var se=re(Fe,2),vt=ie(se);return ls(vt,()=>n()??Je),J(se),J($),Ot($,S=>w(m,S),()=>o(m)),N(e,E),wt(F)}Lt(Hn,{anchor:{},children:{},display:{},backdrop:{},onClickOutside:{},onClickOutsideDelay:{},onClose:{},placement:{},updateUISignal:{},variant:{}},[],[],{mode:"open"});function Zs(e){return Array.from(new Uint8Array(e)).map(t=>t.toString(16).padStart(2,"0")).join("")}function Js(e,t="altcha-css",r){if(typeof document<"u"&&document&&!document.getElementById(t)){const n=document.createElement("style");n.id=t,n.textContent=e;const a=document.currentScript?.nonce??document.querySelector('meta[name="csp-nonce"]')?.content;a&&(n.nonce=a),document.head.appendChild(n)}}async function So(e){const{challenge:t,concurrency:r=navigator.hardwareConcurrency,controller:n=new AbortController,createWorker:a,onOutOfMemory:i=h=>h>1?Math.floor(h/2):0,counterMode:s,timeout:l=9e4}=e,u=Math.min(16,Math.max(1,r)),c=[],d=()=>{for(const h of c)h.terminate()};for(let h=0;h<u;h++)c.push(await a(t.parameters.algorithm));let v=null;try{v=await Promise.race(c.map((h,m)=>(n.signal.addEventListener("abort",()=>{h.postMessage({type:"abort"})}),new Promise((g,x)=>{h.addEventListener("error",T=>{x(T)}),h.addEventListener("message",T=>{if(T.data){for(const L of c)L!==h&&L.postMessage({type:"abort"});if(T.data.error)return x(new Error(T.data.error))}g(T.data)}),h.postMessage({challenge:t,counterMode:s,counterStart:m,counterStep:u,timeout:l,type:"work"})}))))}catch(h){if(h instanceof Error&&!!h?.message?.includes("Out of memory")&&i){d();const g=i(u);if(g)return So({...e,challenge:t,controller:n,concurrency:g,createWorker:a})}throw h}finally{d()}return n.signal.aborted?null:v||null}class Xs{TAG_CODES={INPUT:1,TEXTAREA:2,SELECT:3,BUTTON:4,A:5,DETAILS:6,SUMMARY:7,IFRAME:8,VIDEO:9,AUDIO:10};maxSamples;sampleInterval;target;focusStartTime=0;focusInteraction=0;focusInteractionTimer=null;lastPointerSample=0;lastTouchSample=0;lastScrollSample=0;pendingPointer=null;pendingTouch=null;focus=[];pointer=[];scroll=[];touch=[];constructor(t={}){const{maxSamples:r=60,sampleInterval:n=50,target:a=window}=t;this.maxSamples=r,this.sampleInterval=n,this.target=a,this.attach()}destroy(){const t={capture:!0};this.target.removeEventListener("focusin",this.onFocus,t),this.target.removeEventListener("keydown",this.onInteraction,t),this.target.removeEventListener("pointerdown",this.onInteraction,t),this.target.removeEventListener("pointermove",this.onPointer,t),this.target.removeEventListener("scroll",this.onScroll,t),this.target.removeEventListener("touchmove",this.onTouchMove,t)}export(){return{focus:this.focus,maxTouchPoints:navigator.maxTouchPoints||0,pointer:this.pointer,scroll:this.scroll,time:Date.now(),touch:this.touch}}attach(){const t={passive:!0,capture:!0};this.target.addEventListener("focusin",this.onFocus,t),this.target.addEventListener("keydown",this.onInteraction,t),this.target.addEventListener("pointerdown",this.onInteraction,t),this.target.addEventListener("pointermove",this.onPointer,t),this.target.addEventListener("scroll",this.onScroll,t),this.target.addEventListener("touchmove",this.onTouchMove,t)}evict(t){t.length>this.maxSamples&&t.splice(0,t.length-this.maxSamples)}onFocus=t=>{if(this.focusInteraction===2)return;const r=t.target;if(!(r instanceof Element))return;const n=performance.now();this.focusStartTime===0&&(this.focusStartTime=n),this.focus.push([Math.round(n-this.focusStartTime),r.tabIndex,this.TAG_CODES[r.tagName]??0,this.focusInteraction?1:0]),this.evict(this.focus)};onInteraction=t=>{this.focusInteraction="keyCode"in t?1:2,this.focusInteractionTimer&&clearTimeout(this.focusInteractionTimer),this.focusInteractionTimer=setTimeout(()=>{this.focusInteraction=0},100)};onPointer=t=>{if(t.pointerType==="touch")return;const r=t.timeStamp||performance.now();this.pendingPointer=[Math.round(t.clientX),Math.round(t.clientY),Math.round(r)],r-this.lastPointerSample>=this.sampleInterval&&(this.pointer.push(this.pendingPointer),this.lastPointerSample=r,this.pendingPointer=null,this.evict(this.pointer))};onScroll=()=>{const t=performance.now();t-this.lastScrollSample<this.sampleInterval||(this.scroll.push([Math.round(window.scrollY),Math.round(t)]),this.lastScrollSample=t,this.evict(this.scroll))};onTouchMove=t=>{const r=t.timeStamp||performance.now(),n=t.touches[0];n&&(this.pendingTouch=[Math.round(n.clientX),Math.round(n.clientY),Math.round(r),Math.round(n.force*1e3)/1e3,Math.round(n.radiusX||0),Math.round(n.radiusY||0)],r-this.lastTouchSample>=this.sampleInterval&&(this.touch.push(this.pendingTouch),this.lastTouchSample=r,this.pendingTouch=null,this.evict(this.touch)))}}var Qs=ne('<div class="altcha-overlay-backdrop" data-backdrop=""></div>'),el=ne('<div class="altcha-overlay-content"></div>'),tl=ne('<div role="button" class="altcha-overlay-close">&times;</div> <!>',1),rl=ne('<div class="altcha-floating-arrow"></div>'),nl=ne('<input type="hidden"/>'),al=ne('<div class="altcha-error">Secure context (HTTPS) required.</div>'),ol=ne('<div class="altcha-error"> </div>'),il=ne('<div class="altcha-error"> </div>'),sl=ne("<!> <!>",1),ll=ne('<!> <div class="altcha"><!> <div class="altcha-main"><div><div class="altcha-checkbox-wrap"><!> <label><!></label></div> <!></div> <!> <!> <!></div> <!></div>',1);function cl(e,t){yt(t,!0);const r=()=>ka(d,"$altchaDefaults",a),n=()=>ka(g,"$altchaI18nStore",a),[a,i]=Ei(),s='input[type="text"]:not([data-no-spamfilter]), textarea:not([data-no-spamfilter])',l='input[type="submit"], button[type="submit"], button:not([type="button"]):not([type="reset"])',u=["ar","fa","he","ur"],{isSecureContext:c}=globalThis,{store:d}=globalThis.$altcha.defaults,v=navigator.hardwareConcurrency||2,h=navigator.deviceMemory||0,m=h&&h<=4?Math.min(4,v):v,g=globalThis.$altcha.i18n.store,x=t.$$host,T=(f,p)=>{Yt().then(()=>{x?.dispatchEvent(new CustomEvent(f,{detail:p}))})};let L=null,ye=O(xt(new URL(location.origin))),he=O(!1),U=O(null),Se=O(null),F=O(null),E=O(xt(B.UNVERIFIED)),X=O(void 0),Te=O(void 0),$=O(null),ve=O(void 0),ht=O(null),Fe=O(null),Le=O(null),se=O(null),vt=O(xt([])),S=O(0),G=O(xt({})),Ve=O(!0);const b=Ae(()=>({fetch:(f,p)=>fetch(f,p),audioChallengeLanguage:"",auto:"off",barPlacement:"bottom",challenge:"",codeChallenge:null,codeChallengeDisplay:"standard",credentials:null,debug:!1,disableAutoFocus:!1,display:"standard",floatingAnchor:"",floatingOffset:8,floatingPersist:!1,floatingPlacement:"auto",hideFooter:!1,hideLogo:!1,humanInteractionSignature:!0,language:"",mockError:!1,minDuration:500,overlayContent:"",name:"altcha",popoverPlacement:"auto",retryOnOutOfMemoryError:!0,setCookie:null,serverVerificationFields:!1,serverVerificationTimeZone:!1,test:!1,timeout:9e4,type:"checkbox",validationMessage:"",verifyFunction:null,verifyUrl:"",workers:m,...r(),...o(G)})),Gt=Ae(()=>`altcha-checkbox-${t.id||Math.floor(Math.random()*1e12).toString(16)}`),Zr=Ae(()=>dl(o(b).type)),We=Ae(()=>o(b).auto),Yn=Ae(()=>o(E)===B.VERIFYING),Wt=Ae(()=>!o(b).hideFooter),kr=Ae(()=>!o(b).hideLogo&&o(b).display!=="bar"),Sr=Ae(()=>hl(n(),[o(b).language,document.documentElement.lang,...navigator.languages])),Er=Ae(()=>u.includes(o(Sr).language)?"rtl":void 0),y=Ae(()=>({...o(Sr).strings})),ue=Ae(()=>o(U)?.audio?.match(/^(https?:)?\//)?Jr(o(U).audio,o(ye),{language:o(b).audioChallengeLanguage||o(Sr).language}).toString():o(U)?.audio),qt=Ae(()=>o(U)?.image?.match(/^(https?:)?\//)?Jr(o(U).image,o(ye)):o(U)?.image);Oe(()=>{Ar({auto:t.auto,challenge:t.challenge,display:t.display,language:t.language,name:t.name,type:t.type,workers:t.workers})}),Oe(()=>{t.theme?x?.setAttribute("theme",t.theme):x?.removeAttribute("theme")}),Oe(()=>{if(t.configuration)try{Ar(JSON.parse(t.configuration))}catch{Z("unable to parse the `configuration` attribute (JSON expected)")}}),Oe(()=>{o(F)!==o(b).display&&Xr(o(b).display)}),Oe(()=>{o(he)&&o(E)===B.VERIFYING&&w(he,!1)}),Oe(()=>{!o(he)&&o(E)===B.VERIFIED&&w(he,!0)}),Oe(()=>{if(!o(he)){const f=Zn();f&&f.checked&&(f.checked=!1)}}),Oe(()=>{o(E)===B.VERIFIED&&Zn()?.setCustomValidity("")}),Oe(()=>{if(o(We)==="onload"){const f=setTimeout(()=>{ar()},1);return()=>{f&&clearTimeout(f)}}}),Oe(()=>{o(Fe)&&Z("error:",o(Fe))}),Oe(()=>{o(se)&&o(b).setCookie&&Al(o(se),o(b).setCookie)}),Pn(()=>(Z("mounted","3.2.2"),x&&globalThis.$altcha.instances.add(x),w($,o(ve)?.closest("form"),!0),o($)?.addEventListener("reset",Ro),o($)?.addEventListener("submit",Po,{capture:!0}),o($)?.addEventListener("focusin",$o),Gn(),o(b).humanInteractionSignature&&(Z("human interaction signature enabled"),L=new Xs),T("load"),c||Z("secure context (HTTPS) required"),()=>{Wn(),x&&globalThis.$altcha.instances.delete(x),o(Le)&&clearTimeout(o(Le)),o($)?.removeEventListener("reset",Ro),o($)?.removeEventListener("submit",Po,{capture:!0}),o($)?.removeEventListener("focusin",$o),L?.destroy()}));function Gn(){w(vt,[...globalThis.$altcha.plugins].map(f=>new f(x)),!0),Z("activating plugins",o(vt).map(f=>f.constructor.name));for(const f of o(vt))f.activate()}async function Cr(f,...p){let _;for(const k of o(vt))_=await k[f].call(k,...p);return _}function Wn(){for(const f of o(vt))f.destroy()}function qn(f){const[p,_]=f.salt.split("?"),k={};if(_)try{Object.assign(k,Object.fromEntries(new URLSearchParams(_).entries()))}catch{}const A={codeChallenge:f.codeChallenge,parameters:{algorithm:f.algorithm,cost:1,data:k,expiresAt:k?.expires?parseInt(k.expires,10):void 0,keyLength:f.algorithm==="SHA-512"?64:f.algorithm==="SHA-384"?48:32,nonce:Zs(new TextEncoder().encode(f.salt)),keyPrefix:f.challenge,salt:""},signature:f.signature};return Object.defineProperties(A,{_originalSalt:{enumerable:!1,value:f.salt,writable:!1},_version:{enumerable:!1,value:1,writable:!1}}),A}function Me(f,p){return{algorithm:f.parameters.algorithm,challenge:f.parameters.keyPrefix,number:p.counter,salt:"_originalSalt"in f?f._originalSalt:f.parameters.nonce,signature:f.signature,took:p.time||0}}async function pt(f){await new Promise(p=>setTimeout(p,f))}async function Io(f=o(b).challenge,p){const _=await Cr("onFetchChallenge",f);let k=null;if(_!==void 0)return _;if(typeof f=="string")if(f.startsWith("{")){Z("parsing JSON challenge");try{k=JSON.parse(f)}catch{throw new Error("Unable to parse JSON challenge.")}}else{Z("fetching challenge from",p?.method||"GET",f),w(ye,new URL(f,location.origin),!0);const A=await o(b).fetch(f,{credentials:o(b).credentials||void 0,...p});await Lo(A);const C=A.headers.get("x-altcha-config");C&&Sl(C);const z=await A.json();if(z&&"his"in z&&z.his){if(Z("requested HIS"),!L)throw new Error("Server requested HIS data but collector is disabled.");return Io(Jr(z.his.url,o(ye)),{body:JSON.stringify({his:L.export()}),headers:{"content-type":"application/json"},method:"POST"})}z&&"hisResult"in z&&z.hisResult&&Z("HIS result",z.hisResult),k=z}else if(f&&typeof f=="object")try{k=JSON.parse(JSON.stringify(f))}catch{throw new Error("Unable to parse JSON challenge.")}if(ul(k)&&(k=qn(k)),!fl(k))throw new Error("Challenge validation failed.");return k}function ul(f){return typeof f=="object"&&"challenge"in f}function fl(f){return!!f&&typeof f=="object"&&"parameters"in f&&!!f.parameters&&typeof f.parameters=="object"&&"algorithm"in f.parameters&&"nonce"in f.parameters&&"salt"in f.parameters&&"keyPrefix"in f.parameters}function Zn(){return document.getElementById(o(Gt))}function dl(f){switch(f){case"checkbox":return wo;case"switch":return xo;default:return _o}}function hl(f,p){const _=Object.keys(f).map(A=>A.toLowerCase());let k=p.reduce((A,C)=>(C=C.toLowerCase(),A||(f[C]?C:null)||_.find(z=>C.split("-")[0]===z.split("-")[0])||null),null);return f[k||""]||(k="en"),{language:k,strings:f[k]}}function vl(f){switch(f){case"bar":return o(b).barPlacement||"bottom";case"floating":return o(b).floatingPlacement||"auto";default:return}}function pl(f){return[...o($)?.querySelectorAll(s)||[]].reduce((_,k)=>{const A=k.name,C=k.value;return A&&C&&(_[A]=/\n/.test(C)?C.replace(new RegExp("(?<!\\r)\\n","g"),`\r
`):C),_},{})}function gl(){try{return Intl.DateTimeFormat().resolvedOptions().timeZone}catch{}}function Jr(f,p,_){const k=new URL(f,p);if(k.search||(k.search=p.search),_)for(const A in _)_[A]!==void 0&&_[A]!==null&&k.searchParams.set(A,_[A]);return k.toString()}function ml(f){!o(he)&&f.currentTarget.checked?(f.preventDefault(),f.currentTarget.checked=!1,o(E)!==B.VERIFYING&&ar()):f.currentTarget.checked||(f.preventDefault(),qe())}function bl(f){o(E)===B.VERIFYING?f.currentTarget.setCustomValidity(o(y).waitAlert):o(b).validationMessage&&f.currentTarget.setCustomValidity(o(b).validationMessage)}function yl(){Xr(o(b).display),qe()}function wl(){Qr()}function _l(f){const p=f.target;o(b).display==="floating"&&p&&!x?.contains(p)&&!p.hasAttribute("data-backdrop")&&!p.closest("[data-popover]")&&o(E)!==B.VERIFIED&&!o(b).floatingPersist&&Jn()}function $o(f){o(We)==="onfocus"&&o(E)===B.UNVERIFIED&&ar()}function Ro(){Xr(o(b).display),qe()}function Po(f){f.target?.getAttribute("data-code-challenge")!=="true"&&o(We)==="onsubmit"&&o(E)===B.UNVERIFIED&&(f.preventDefault(),f.stopPropagation(),w(ht,f.submitter,!0),Xn(),ar().then(_=>{_&&!o(U)&&Yt().then(()=>{Oo(o(ht))})}))}function xl(f){f.persisted&&(Xr(o(b).display),qe())}function kl(){Qr()}function Sl(f){try{const p=JSON.parse(f);p&&typeof p=="object"&&Ar({serverVerificationFields:p?.sentinel?.fields,serverVerificationTimeZone:p?.sentinel?.timeZone,verifyUrl:p.verifyurl,...p})}catch(p){Z("unable to configure from x-altcha-config header",p)}}function El(f=20){if(!o(ve))return;const p=o(b).floatingPlacement;if(!o(Te)&&(w(Te,(o(b).floatingAnchor instanceof HTMLElement?o(b).floatingAnchor:o(b).floatingAnchor?document.querySelector(o(b).floatingAnchor):o($)?.querySelector(l))||o($),!0),!o(Te))){Z("unable to find floating anchor element");return}const _=parseInt(o(b).floatingOffset,10)||12,k=o(Te).getBoundingClientRect(),A=o(ve).getBoundingClientRect(),C=document.documentElement.clientHeight,z=document.documentElement.clientWidth,Be=!p||p==="auto"?k.bottom+A.height+_+f>C:p==="top",Q=Math.max(f,Math.min(z-f-A.width,k.left+k.width/2-A.width/2));if(o(ve).style.setProperty("--altcha-floating-left",`${Q}px`),o(ve).style.setProperty("--altcha-floating-top",Be?`${k.top-(A.height+_)}px`:`${k.bottom+_}px`),o(ve).setAttribute("data-floating-position",Be?"top":"bottom"),o(X)){const pe=o(X).getBoundingClientRect();o(X).style.left=k.left-Q+k.width/2-pe.width/2+"px"}}async function Cl(f,p){const _=await Cr("onRequestServerVerification",f,p);if(_!==void 0)return _;if(Z("requesting server verification from",o(b).verifyUrl),!o(b).verifyUrl)throw new Error("Parameter verifyUrl must be set for server verification.");const k=await o(b).fetch(Jr(o(b).verifyUrl,o(ye)),{body:JSON.stringify({code:p,fields:o(b).serverVerificationFields?pl():void 0,payload:f,timeZone:o(b).serverVerificationTimeZone?gl():void 0}),credentials:o(b).credentials||void 0,headers:{"Content-Type":"application/json"},method:"POST"});await Lo(k);const A=await k.json();return A&&typeof A=="object"&&"payload"in A&&A.payload&&T("serververification",A),A}function Oo(f){o($)&&"requestSubmit"in o($)?o($).requestSubmit(f):o($)?.reportValidity()&&(f?f.click():o($).submit())}function Al(f,p={}){const{domain:_,name:k=o(b).name,maxAge:A,path:C,sameSite:z,secure:Be}=p;let Q=`${encodeURIComponent(k)}=${encodeURIComponent(f)}`;_&&(Q+=`; Domain=${_}`),A!=null&&(Q+=`; Max-Age=${A}`),C&&(Q+=`; Path=${C}`),z&&(Q+=`; SameSite=${z}`),Be&&(Q+="; Secure"),document.cookie=Q}function Xr(f){switch(f){case"bar":case"floating":case"overlay":Jn(),(!o(We)||o(We)==="off")&&(o(G).auto="onsubmit");break;case"standard":Xn()}o(F)!==f&&w(F,f,!0)}function Tl(f){o(Le)&&clearTimeout(o(Le));const p=()=>{o(E)!==B.UNVERIFIED?(w(he,!1),Ze(B.EXPIRED)):qe(),T("expired")},_=f*1e3-Date.now();_>=1?w(Le,setTimeout(p,_),!0):p()}async function Lo(f){if(f.status>=400){if(f.headers.get("content-type")?.includes("/json")){let _;try{_=await f.json()}catch{}if(_&&"error"in _)throw new Error(`Server responded with ${f.status} - ${_.error}`)}throw new Error(`Server responded with ${f.status}.`)}const p=f.headers.get("content-type");if(!p||!p.includes("/json"))throw new Error(`Server responded with invalid content-type. Expected application/json, received ${p}.`)}async function Mo(f){if(!o(se)){Ze(B.ERROR,"Cannot verify code challenge without PoW payload.");return}Ze(B.VERIFYING);let p=null;if(o(b).verifyUrl)p=await Cl(o(se),f);else if(o(b).verifyFunction)p=await o(b).verifyFunction(o(se),f);else{Ze(B.ERROR,"Parameter verifyUrl is required for code challenge verification.");return}p?.payload&&(w(se,p.payload,!0),Z("server payload",o(se))),p?.verified===!0?(Z("verified"),Ze(B.VERIFIED),T("verified",{payload:o(se)}),o(We)==="onsubmit"&&Yt().then(()=>{Oo(o(ht))})):Ze(B.ERROR,p?.reason||"Verification failed."),o(b).disableAutoFocus||Zn()?.focus()}function Ar(f){Object.assign(o(G),{...Object.fromEntries(Object.entries(f).filter(([p,_])=>_!==void 0))})}function Il(){return{...o(b)}}function $l(){return o(E)}function Jn(){w(Ve,!1)}function Z(...f){(o(b).debug||f.some(p=>p instanceof Error))&&console[f[0]instanceof Error?"error":"log"]("ALTCHA",`[name=${o(b).name}]`,...f)}function qe(f=B.UNVERIFIED,p=null){w(he,!1),w(Fe,p,!0),w(se,null),o(Se)&&o(Se).abort(),o(Le)&&(clearTimeout(o(Le)),w(Le,null)),Ze(f)}function Ze(f,p=null){w(E,f,!0),w(Fe,p,!0),T("statechange",{payload:o(se),state:o(E)})}function Xn(){w(Ve,!0),Yt().then(()=>{Qr()})}function Qr(){if(o(b).display==="floating")return El();w(S,o(S)+1)}async function ar(f={}){const{concurrency:p=Math.max(1,o(b).workers),controller:_=new AbortController,minDuration:k=o(b).minDuration}=f,A=performance.now();let C=null,z=null,Be=!1;const Q=await Cr("onVerify",f);if(Q!==void 0)return Q;qe(B.VERIFYING),w(Se,_,!0);try{if(!c)throw new Error("Secure context (HTTPS) required.");if(o(b).mockError)throw new Error("Mock error.");if(o(b).test)return Z("running test mode with null challenge"),await pt(Math.max(0,k-(performance.now()-A))),o(Se)?.signal.aborted?(qe(),null):(w(se,btoa(JSON.stringify({challenge:null,solution:null,test:!0})),!0),Z("verified"),Ze(B.VERIFIED),T("verified",{payload:o(se)}),{payload:o(se)});if(C=await Io(),!C)throw new Error("Failed to fetch challenge.");Z("challenge",C),"configuration"in C&&(Z("re-configuring from challenge",C.configuration),Ar(C.configuration)),C.parameters.expiresAt&&Tl(C.parameters.expiresAt),Be="_version"in C&&C._version===1;const pe=globalThis.$altcha.algorithms.get(C.parameters.algorithm);if(!pe)throw new Error(`Unsupported algorithm ${C.parameters.algorithm}.`);if(z=await So({challenge:C,concurrency:p,controller:_,createWorker:pe,counterMode:Be?"string":"uint32",onOutOfMemory:Mt=>{if(Z("out of memory error received"),T("outofmemory"),o(b).retryOnOutOfMemoryError&&Mt>1){const Nt=Math.floor(Mt/2);return Z(`retrying with ${Nt} workers...`),Nt}},timeout:o(b).timeout}),o(Se)?.signal.aborted)return qe(),null;if(!z)throw new Error("Failed to find solution.");Z("solution",z),await pt(Math.max(0,k-(performance.now()-A))),w(U,C.codeChallenge||o(b).codeChallenge||null,!0),Be?w(se,btoa(JSON.stringify(Me(C,z))),!0):w(se,btoa(JSON.stringify({challenge:{parameters:C.parameters,signature:C.signature},solution:z})),!0),o(U)?(Z("requesting code verification"),Ze(B.CODE),T("codechallenge",{codeChallenge:o(U)})):o(b).verifyUrl?await Mo():(Z("verified"),Ze(B.VERIFIED),T("verified",{payload:o(se)}))}catch(pe){return Z("verification failed",pe),Ze(B.ERROR,String(pe)),null}finally{w(Se,null)}return{challenge:C,payload:o(se),solution:z}}var Rl={configure:Ar,getConfiguration:Il,getState:$l,hide:Jn,log:Z,reset:qe,setState:Ze,show:Xn,updateUI:Qr,verify:ar},No=ll();me("scroll",dn,wl),me("click",dn,_l),me("pageshow",Bt,xl),me("resize",Bt,kl);var Do=Qt(No);{var Pl=f=>{var p=Qs();N(f,p)};be(Do,f=>{o(b).display==="overlay"&&o(Ve)&&f(Pl)})}var gt=re(Do,2),jo=ie(gt);{var Ol=f=>{var p=tl(),_=Qt(p),k=re(_,2);{var A=C=>{var z=el();co(z,()=>document.querySelector(o(b).overlayContent)?.innerHTML,!0),J(z),N(C,z)};be(k,C=>{o(b).overlayContent&&C(A)})}me("click",_,yl,!0),N(f,p)};be(jo,f=>{o(b).display==="overlay"&&o(Ve)&&f(Ol)})}var Qn=re(jo,2),ea=ie(Qn),ta=ie(ea),Uo=ie(ta);{let f=Ae(()=>o(b).display==="standard"&&o(We)!=="onsubmit"||o(E)===B.VERIFYING);fs(Uo,()=>o(Zr),(p,_)=>{_(p,{get id(){return o(Gt)},name:"",get required(){return o(f)},get loading(){return o(Yn)},get checked(){return o(he)},onchange:ml,oninvalid:bl})})}var ra=re(Uo,2),Ll=ie(ra);{var Ml=f=>{var p=zr();ke(()=>dt(p,o(y).verificationRequired)),N(f,p)},Nl=f=>{var p=zr();ke(()=>dt(p,o(y).verifying)),N(f,p)},Dl=f=>{var p=zr();ke(()=>dt(p,o(y).verified)),N(f,p)},jl=f=>{var p=zr();ke(()=>dt(p,o(y).label)),N(f,p)};be(Ll,f=>{o(E)===B.CODE&&o(U)?f(Ml):o(E)===B.VERIFYING?f(Nl,1):o(E)===B.VERIFIED?f(Dl,2):f(jl,-1)})}J(ra),J(ta);var Ul=re(ta,2);{var Fl=f=>{Vn(f,{get strings(){return o(y)}})};be(Ul,f=>{o(kr)&&f(Fl)})}J(ea);var Fo=re(ea,2);{var Vl=f=>{{let p=Ae(()=>o(b).display==="bar"&&o(kr));Bn(f,{get logo(){return o(p)},get strings(){return o(y)}})}};be(Fo,f=>{o(Wt)&&f(Vl)})}var Vo=re(Fo,2);{var Bl=f=>{var p=rl();Ot(p,_=>w(X,_),()=>o(X)),N(f,p)};be(Vo,f=>{o(b).display==="floating"&&f(Bl)})}var Hl=re(Vo,2);{var zl=f=>{var p=nl();Nn(p),ke(()=>{H(p,"name",o(b).name),Es(p,o(se))}),N(f,p)};be(Hl,f=>{o(b).setCookie||f(zl)})}J(Qn);var Kl=re(Qn,2);{var Yl=f=>{Hn(f,{get anchor(){return o(ve)},onClickOutside:()=>{c&&qe()},get placement(){return o(b).popoverPlacement},role:"alert",variant:"error",get dir(){return o(Er)},get updateUISignal(){return o(S)},children:(p,_)=>{var k=io(),A=Qt(k);{var C=Q=>{var pe=al();N(Q,pe)},z=Q=>{var pe=ol(),Mt=ie(pe,!0);J(pe),ke(()=>dt(Mt,o(y).expired)),N(Q,pe)},Be=Q=>{var pe=il(),Mt=ie(pe,!0);J(pe),ke(()=>{H(pe,"title",o(Fe)),dt(Mt,o(y).error)}),N(Q,pe)};be(A,Q=>{!o(Fe)&&!c?Q(C):!o(Fe)&&o(E)===B.EXPIRED?Q(z,1):Q(Be,-1)})}N(p,k)},$$slots:{default:!0}})},Gl=f=>{var p=io(),_=Qt(p);us(_,()=>o(U),k=>{{let A=Ae(()=>o(b).codeChallengeDisplay!=="standard");Hn(k,{get anchor(){return o(ve)},get backdrop(){return o(A)},get display(){return o(b).codeChallengeDisplay},onClose:()=>{qe()},get placement(){return o(b).popoverPlacement},role:"dialog",get"aria-label"(){return o(y).verificationRequired},get dir(){return o(Er)},get updateUISignal(){return o(S)},children:(C,z)=>{var Be=sl(),Q=Qt(Be);ko(Q,{get audioUrl(){return o(ue)},get imageUrl(){return o(qt)},onCancel:()=>qe(),onReload:()=>ar(),onSubmit:Nt=>Mo(Nt),get codeChallenge(){return o(U)},get config(){return o(b)},get strings(){return o(y)}});var pe=re(Q,2);{var Mt=Nt=>{Bn(Nt,{get logo(){return o(kr)},get strings(){return o(y)}})};be(pe,Nt=>{o(Wt)&&o(b).codeChallengeDisplay!=="standard"&&Nt(Mt)})}N(C,Be)},$$slots:{default:!0}})}}),N(f,p)};be(Kl,f=>{o(Fe)||o(E)===B.EXPIRED||!c?f(Yl):o(U)&&o(E)===B.CODE&&f(Gl,1)})}J(gt),Ot(gt,f=>w(ve,f),()=>o(ve)),ke(f=>{H(gt,"data-state",o(E)),H(gt,"data-display",o(b).display||void 0),H(gt,"data-placement",f),H(gt,"data-visible",o(Ve)||void 0),H(gt,"dir",o(Er)),H(ra,"for",o(Gt)),gt.dir=gt.dir},[()=>vl(o(b).display)]),N(e,No);var Wl=wt(Rl);return i(),Wl}typeof window<"u"&&window.customElements&&!customElements.get("altcha-widget")&&customElements.define("altcha-widget",Lt(cl,{auto:{type:"String"},challenge:{type:"String"},configuration:{type:"String"},display:{type:"String"},language:{type:"String"},name:{type:"String"},theme:{type:"String"},type:{type:"String"},workers:{type:"Number"}},[],["configure","getConfiguration","getState","hide","log","reset","setState","show","updateUI","verify"]));const Eo=`(function() {
  "use strict";
  function bufferStartsWith(buffer, prefix) {
    if (prefix.length > buffer.length) {
      return false;
    }
    for (let i = 0; i < prefix.length; i++) {
      if (buffer[i] !== prefix[i]) {
        return false;
      }
    }
    return true;
  }
  function bufferToHex(buffer) {
    return Array.from(new Uint8Array(buffer)).map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  function concatBuffers(a, b) {
    const out = new Uint8Array(a.length + b.length);
    out.set(a, 0);
    out.set(b, a.length);
    return out;
  }
  function hexToBuffer(hex) {
    if (hex.length % 2 !== 0) {
      throw new Error(\`Hex string must have an even length. Got: \${hex}\`);
    }
    const buffer = new ArrayBuffer(hex.length / 2);
    const view = new DataView(buffer);
    for (let i = 0; i < hex.length; i += 2) {
      const byteString = hex.substring(i, i + 2);
      const byteValue = parseInt(byteString, 16);
      view.setUint8(i / 2, byteValue);
    }
    return new Uint8Array(buffer);
  }
  async function delay(ms) {
    await new Promise((resolve) => setTimeout(resolve, ms));
  }
  function timeDuration(start) {
    return Math.floor((performance.now() - start) * 10) / 10;
  }
  class PasswordBuffer {
    constructor(nonce, mode = "uint32") {
      this.nonce = nonce;
      this.mode = mode;
      this.buffer = new Uint8Array(this.nonce.length + this.COUNTER_BYTES);
      this.buffer.set(this.nonce, 0);
      this.dataView = new DataView(this.buffer.buffer);
    }
    nonce;
    mode;
    COUNTER_BYTES = 4;
    buffer;
    dataView;
    encoder = new TextEncoder();
    /**
     * Appends the counter to the nonce buffer.
     * In 'string' mode, encodes the counter as a UTF-8 string.
     * In 'uint32' mode, writes the counter as a big-endian 32-bit integer.
     */
    setCounter(n) {
      if (this.mode === "string") {
        return concatBuffers(this.nonce, this.encoder.encode(n.toString()));
      }
      this.dataView.setUint32(this.nonce.length, n, false);
      return this.buffer;
    }
  }
  async function solveChallenge(options) {
    const {
      challenge,
      controller,
      counterMode = "uint32",
      counterStart = 0,
      counterStep = 1,
      deriveKey: deriveKey2,
      timeout = 9e4
    } = options;
    const { nonce, keyPrefix, salt } = challenge.parameters;
    const nonceBuf = hexToBuffer(nonce);
    const saltBuf = hexToBuffer(salt);
    const keyPrefixBuf = keyPrefix.length % 2 === 0 ? hexToBuffer(keyPrefix) : null;
    const password = new PasswordBuffer(nonceBuf, counterMode);
    const start = performance.now();
    let counter = counterStart;
    let iterations = 0;
    let derivedKeyHex = "";
    let lastYield = start;
    while (true) {
      if (controller?.signal.aborted || timeout && iterations % 10 === 0 && performance.now() - start > timeout) {
        return null;
      }
      const { derivedKey } = await deriveKey2(
        challenge.parameters,
        saltBuf,
        password.setCounter(counter)
      );
      if (iterations % 10 === 0 && performance.now() - lastYield > 200) {
        await delay(0);
        lastYield = performance.now();
      }
      if (keyPrefixBuf ? bufferStartsWith(derivedKey, keyPrefixBuf) : bufferToHex(derivedKey).startsWith(keyPrefix)) {
        derivedKeyHex = bufferToHex(derivedKey);
        break;
      }
      counter = counter + counterStep;
      iterations = iterations + 1;
    }
    return {
      counter,
      derivedKey: derivedKeyHex,
      time: timeDuration(start)
    };
  }
  function handler(options) {
    const { deriveKey: deriveKey2 } = options;
    let controller = void 0;
    self.onmessage = async (message) => {
      const { challenge, counterMode, counterStart, counterStep, timeout, type } = message.data;
      if (type === "abort") {
        controller?.abort();
      } else if (type === "work") {
        controller = new AbortController();
        let solution;
        try {
          solution = await solveChallenge({
            challenge,
            controller,
            counterStart,
            counterStep,
            deriveKey: deriveKey2,
            counterMode,
            timeout
          });
        } catch (err) {
          return self.postMessage({ error: err });
        }
        self.postMessage(solution);
      }
    };
  }
  function getDigest(algorithm) {
    switch (algorithm) {
      case "PBKDF2/SHA-512":
        return "SHA-512";
      case "PBKDF2/SHA-384":
        return "SHA-384";
      case "PBKDF2/SHA-256":
      default:
        return "SHA-256";
    }
  }
  async function deriveKey(parameters, salt, password) {
    const { algorithm, cost, keyLength = 32 } = parameters;
    const passwordKey = await crypto.subtle.importKey(
      "raw",
      password,
      { name: "PBKDF2" },
      false,
      ["deriveKey"]
    );
    const derivedKey = await crypto.subtle.deriveKey(
      {
        name: "PBKDF2",
        salt,
        iterations: cost,
        hash: getDigest(algorithm)
      },
      passwordKey,
      { name: "AES-GCM", length: keyLength * 8 },
      true,
      ["encrypt"]
    );
    return {
      derivedKey: new Uint8Array(await crypto.subtle.exportKey("raw", derivedKey))
    };
  }
  handler({
    deriveKey
  });
})();
`,Co=typeof self<"u"&&self.Blob&&new Blob(["(self.URL || self.webkitURL).revokeObjectURL(self.location.href);",Eo],{type:"text/javascript;charset=utf-8"});function zn(e){let t;try{if(t=Co&&(self.URL||self.webkitURL).createObjectURL(Co),!t)throw"";const r=new Worker(t,{name:e?.name});return r.addEventListener("error",()=>{(self.URL||self.webkitURL).revokeObjectURL(t)}),r}catch{return new Worker("data:text/javascript;charset=utf-8,"+encodeURIComponent(Eo),{name:e?.name})}}const Ao=`(function() {
  "use strict";
  function bufferStartsWith(buffer, prefix) {
    if (prefix.length > buffer.length) {
      return false;
    }
    for (let i = 0; i < prefix.length; i++) {
      if (buffer[i] !== prefix[i]) {
        return false;
      }
    }
    return true;
  }
  function bufferToHex(buffer) {
    return Array.from(new Uint8Array(buffer)).map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  function concatBuffers(a, b) {
    const out = new Uint8Array(a.length + b.length);
    out.set(a, 0);
    out.set(b, a.length);
    return out;
  }
  function hexToBuffer(hex) {
    if (hex.length % 2 !== 0) {
      throw new Error(\`Hex string must have an even length. Got: \${hex}\`);
    }
    const buffer = new ArrayBuffer(hex.length / 2);
    const view = new DataView(buffer);
    for (let i = 0; i < hex.length; i += 2) {
      const byteString = hex.substring(i, i + 2);
      const byteValue = parseInt(byteString, 16);
      view.setUint8(i / 2, byteValue);
    }
    return new Uint8Array(buffer);
  }
  async function delay(ms) {
    await new Promise((resolve) => setTimeout(resolve, ms));
  }
  function timeDuration(start) {
    return Math.floor((performance.now() - start) * 10) / 10;
  }
  class PasswordBuffer {
    constructor(nonce, mode = "uint32") {
      this.nonce = nonce;
      this.mode = mode;
      this.buffer = new Uint8Array(this.nonce.length + this.COUNTER_BYTES);
      this.buffer.set(this.nonce, 0);
      this.dataView = new DataView(this.buffer.buffer);
    }
    nonce;
    mode;
    COUNTER_BYTES = 4;
    buffer;
    dataView;
    encoder = new TextEncoder();
    /**
     * Appends the counter to the nonce buffer.
     * In 'string' mode, encodes the counter as a UTF-8 string.
     * In 'uint32' mode, writes the counter as a big-endian 32-bit integer.
     */
    setCounter(n) {
      if (this.mode === "string") {
        return concatBuffers(this.nonce, this.encoder.encode(n.toString()));
      }
      this.dataView.setUint32(this.nonce.length, n, false);
      return this.buffer;
    }
  }
  async function solveChallenge(options) {
    const {
      challenge,
      controller,
      counterMode = "uint32",
      counterStart = 0,
      counterStep = 1,
      deriveKey: deriveKey2,
      timeout = 9e4
    } = options;
    const { nonce, keyPrefix, salt } = challenge.parameters;
    const nonceBuf = hexToBuffer(nonce);
    const saltBuf = hexToBuffer(salt);
    const keyPrefixBuf = keyPrefix.length % 2 === 0 ? hexToBuffer(keyPrefix) : null;
    const password = new PasswordBuffer(nonceBuf, counterMode);
    const start = performance.now();
    let counter = counterStart;
    let iterations = 0;
    let derivedKeyHex = "";
    let lastYield = start;
    while (true) {
      if (controller?.signal.aborted || timeout && iterations % 10 === 0 && performance.now() - start > timeout) {
        return null;
      }
      const { derivedKey } = await deriveKey2(
        challenge.parameters,
        saltBuf,
        password.setCounter(counter)
      );
      if (iterations % 10 === 0 && performance.now() - lastYield > 200) {
        await delay(0);
        lastYield = performance.now();
      }
      if (keyPrefixBuf ? bufferStartsWith(derivedKey, keyPrefixBuf) : bufferToHex(derivedKey).startsWith(keyPrefix)) {
        derivedKeyHex = bufferToHex(derivedKey);
        break;
      }
      counter = counter + counterStep;
      iterations = iterations + 1;
    }
    return {
      counter,
      derivedKey: derivedKeyHex,
      time: timeDuration(start)
    };
  }
  function handler(options) {
    const { deriveKey: deriveKey2 } = options;
    let controller = void 0;
    self.onmessage = async (message) => {
      const { challenge, counterMode, counterStart, counterStep, timeout, type } = message.data;
      if (type === "abort") {
        controller?.abort();
      } else if (type === "work") {
        controller = new AbortController();
        let solution;
        try {
          solution = await solveChallenge({
            challenge,
            controller,
            counterStart,
            counterStep,
            deriveKey: deriveKey2,
            counterMode,
            timeout
          });
        } catch (err) {
          return self.postMessage({ error: err });
        }
        self.postMessage(solution);
      }
    };
  }
  async function deriveKey(parameters, salt, password) {
    const { algorithm, keyLength = 32 } = parameters;
    const iterations = Math.max(1, parameters.cost);
    let data = void 0;
    let derivedKey = void 0;
    for (let i = 0; i < iterations; i++) {
      if (i === 0) {
        data = concatBuffers(salt, password);
      } else {
        data = derivedKey;
      }
      derivedKey = new Uint8Array(
        (await crypto.subtle.digest(algorithm, data)).slice(0, keyLength)
      );
    }
    return {
      parameters: {},
      derivedKey
    };
  }
  handler({
    deriveKey
  });
})();
`,To=typeof self<"u"&&self.Blob&&new Blob(["(self.URL || self.webkitURL).revokeObjectURL(self.location.href);",Ao],{type:"text/javascript;charset=utf-8"});function Kn(e){let t;try{if(t=To&&(self.URL||self.webkitURL).createObjectURL(To),!t)throw"";const r=new Worker(t,{name:e?.name});return r.addEventListener("error",()=>{(self.URL||self.webkitURL).revokeObjectURL(t)}),r}catch{return new Worker("data:text/javascript;charset=utf-8,"+encodeURIComponent(Ao),{name:e?.name})}}return Js(`:root {
  --altcha-border-color: var(--altcha-color-neutral);
  --altcha-border-width: 1px;
  --altcha-border-radius: 6px;
  --altcha-color-base: light-dark(oklch(100% 0.00011 271.152), oklch(20.904% 0.00002 271.152));
  --altcha-color-base-content: light-dark(
  	oklch(20.904% 0.00002 271.152),
  	oklch(100% 0.00011 271.152)
  );
  --altcha-color-error: oklch(51.284% 0.20527 28.678);
  --altcha-color-error-content: oklch(100% 0.00011 271.152);
  --altcha-color-neutral: light-dark(oklch(83.591% 0.0001 271.152), oklch(46.04% 0.00005 271.152));
  --altcha-color-neutral-content: light-dark(
  	oklch(46.76% 0.00005 271.152),
  	oklch(100% 0.00011 271.152)
  );
  --altcha-color-primary: oklch(40.279% 0.2449 268.131);
  --altcha-color-primary-content: oklch(100% 0.00011 271.152);
  --altcha-color-success: oklch(55.748% 0.18968 142.511);
  --altcha-color-success-content: oklch(100% 0.00011 271.152);
  --altcha-checkbox-border-color: light-dark(
  	oklch(66.494% 0.00233 15.434),
  	oklch(51.028% 0.00006 271.152)
  );
  --altcha-checkbox-border-radius: 5px;
  --altcha-checkbox-border-width: var(--altcha-border-width);
  --altcha-checkbox-outline: 2px solid var(--altcha-checkbox-outline-color);
  --altcha-checkbox-outline-color: -webkit-focus-ring-color;
  --altcha-checkbox-outline-offset: 2px;
  --altcha-checkbox-size: 22px;
  --altcha-checkbox-transition-duration: var(--altcha-transition-duration);
  --altcha-input-background-color: var(--altcha-color-base);
  --altcha-input-border-radius: 3px;
  --altcha-input-border-width: 1px;
  --altcha-input-color: var(--altcha-color-base-content);
  --altcha-max-width: 320px;
  --altcha-padding: 0.75rem;
  --altcha-popover-arrow-size: 6px;
  --altcha-popover-color: var(--altcha-border-color);
  --altcha-shadow: drop-shadow(3px 3px 6px oklch(0% 0 0 / 0.2));
  --altcha-spinner-color: var(--altcha-color-base-content);
  --altcha-switch-background-color: var(--altcha-color-neutral);
  --altcha-switch-border-radius: calc(infinity * 1px);
  --altcha-switch-height: var(--altcha-checkbox-size);
  --altcha-switch-padding: 0.25rem;
  --altcha-switch-width: calc(var(--altcha-checkbox-size) * 1.75);
  --altcha-switch-toggle-border-radius: 100%;
  --altcha-switch-toggle-color: var(--altcha-color-neutral-content);
  --altcha-switch-toggle-size: calc(
  	var(--altcha-switch-height) - calc(var(--altcha-switch-padding) * 2)
  );
  --altcha-transition-duration: 0.6s;
  --altcha-z-index: 99999999;
  --altcha-z-index-popover: 999999999;
}

@supports (-moz-appearance: none) {
  :root {
    --altcha-checkbox-outline-color: var(--altcha-color-primary);
  }
}
.altcha {
  all: revert-layer;
  display: none;
  font-family: inherit;
  font-size: inherit;
  position: relative;
}
.altcha[data-visible] {
  display: block;
}
.altcha-popover, .altcha-popover * {
  all: revert-layer;
  box-sizing: border-box;
  font-family: inherit;
  font-size: inherit;
  line-height: 1.25;
}
.altcha * {
  all: revert-layer;
  box-sizing: border-box;
  font-family: inherit;
  font-size: inherit;
  line-height: 1.25;
}
.altcha a, .altcha-popover a {
  color: currentColor;
  text-decoration: none;
}
.altcha a:hover, .altcha-popover a:hover {
  color: currentColor;
}
.altcha-main {
  align-items: start;
  background-color: var(--altcha-color-base);
  border: var(--altcha-border-width, 1px) solid var(--altcha-border-color);
  border-radius: var(--altcha-border-radius, 0);
  color: var(--altcha-color-base-content);
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  justify-content: space-between;
  padding: var(--altcha-padding);
  max-width: var(--altcha-max-width, 100%);
}
.altcha-main > * {
  display: flex;
  width: 100%;
}
.altcha-main > *:first-child {
  flex-grow: 1;
}
.altcha-checkbox-wrap {
  align-items: center;
  display: flex;
  flex-direction: row;
  flex-grow: 1;
  gap: 0.5rem;
}
.altcha-checkbox-wrap > * {
  display: flex;
}
.altcha-logo {
  opacity: 0.7;
}
.altcha-footer {
  align-items: center;
  display: flex;
  flex-grow: 1;
  gap: 0.5rem;
  justify-content: flex-end;
  font-size: 0.7rem;
  opacity: 0.7;
}
.altcha-footer p {
  margin: 0;
  padding: 0;
}
.altcha-error {
  font-size: 0.85rem;
}
.altcha-button {
  align-items: center;
  background: var(--altcha-color-primary);
  border: var(--altcha-input-border-width) solid var(--altcha-color-primary);
  border-radius: var(--altcha-input-border-radius);
  color: var(--altcha-color-primary-content);
  cursor: pointer;
  display: flex;
  font-size: 0.9rem;
  gap: 0.5rem;
  padding: 0.35rem;
}
.altcha-button:focus {
  border-color: var(--altcha-color-primary);
  outline: var(--altcha-checkbox-outline);
  outline-offset: var(--altcha-checkbox-outline-offset);
}
.altcha-button > .altcha-spinner, .altcha-button > svg {
  height: 20px;
  width: 20px;
}
.altcha-button-secondary {
  background: transparent;
  border-color: var(--altcha-color-neutral);
  color: var(--altcha-color-neutral-content);
}
.altcha-input {
  background: var(--altcha-input-background-color);
  border: var(--altcha-input-border-width) solid var(--altcha-color-neutral);
  border-radius: var(--altcha-input-border-radius);
  color: var(--altcha-input-color);
  flex-grow: 1;
  font-size: 1rem;
  min-width: 0;
  padding: 0.25rem;
  width: auto;
}
.altcha-input:focus {
  border-color: var(--altcha-color-primary);
  outline: var(--altcha-checkbox-outline);
  outline-offset: var(--altcha-checkbox-outline-offset);
}
.altcha-spinner {
  animation: altcha-rotate 0.6s linear infinite;
  border-radius: 100%;
  border: var(--altcha-checkbox-border-width) solid var(--altcha-spinner-color);
  border-bottom-color: transparent;
  border-right-color: transparent;
  opacity: 0.7;
}
.altcha-popover {
  background-color: var(--altcha-color-base);
  border: var(--altcha-border-width) solid var(--altcha-border-color);
  border-radius: var(--altcha-border-radius);
  color: var(--altcha-color-base-content);
  filter: var(--altcha-shadow);
  position: absolute;
  left: calc(var(--altcha-padding) / 2);
  max-width: calc(var(--altcha-max-width) - var(--altcha-padding));
  top: calc(var(--altcha-padding) + var(--altcha-checkbox-size) + var(--altcha-popover-arrow-size));
  z-index: var(--altcha-z-index-popover);
}
.altcha-popover-arrow {
  border: var(--altcha-popover-arrow-size) solid transparent;
  border-bottom-color: var(--altcha-popover-color);
  content: "";
  height: 0;
  left: calc(var(--altcha-checkbox-size) / 2);
  position: absolute;
  top: calc(var(--altcha-popover-arrow-size) * -2);
  width: 0;
}
.altcha-popover-content {
  max-height: 100dvh;
  overflow: auto;
  padding: var(--altcha-padding);
}
.altcha-popover[data-top=true][data-display=standard] {
  bottom: calc(100% - (var(--altcha-padding) - var(--altcha-popover-arrow-size)));
  top: auto;
}
.altcha-popover[data-top=true][data-display=standard] .altcha-popover-arrow {
  border-bottom-color: transparent;
  border-top-color: var(--altcha-popover-color);
  bottom: calc(var(--altcha-popover-arrow-size) * -2);
  top: auto;
}
.altcha-popover[data-variant=error] {
  --altcha-popover-color: var(--altcha-color-error);
  background-color: var(--altcha-color-error);
  border-color: var(--altcha-color-error);
  color: var(--altcha-color-error-content);
}
.altcha-popover[data-variant=error] .altcha-popover-content {
  padding: calc(var(--altcha-padding) / 1.5) var(--altcha-padding);
}
.altcha-popover[data-display=overlay] {
  animation: altcha-overlay-slidein 0.5s forwards;
  left: 50%;
  position: fixed;
  top: 45%;
  transform: translate(-50%, -50%);
  width: var(--altcha-max-width);
  z-index: var(--altcha-z-index);
}
.altcha-popover[data-display=bottomsheet] {
  animation: altcha-bottomsheet-slideup 0.5s forwards;
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
  border-bottom: 0;
  bottom: -100%;
  left: 50%;
  position: fixed;
  top: auto;
  transform: translate(-50%, 0);
  width: var(--altcha-max-width);
  z-index: var(--altcha-z-index);
}
.altcha-popover[data-display=bottomsheet] .altcha-popover-content {
  padding-bottom: calc(var(--altcha-padding) * 2);
}
.altcha-popover-backdrop {
  background: var(--altcha-color-base-content);
  bottom: 0;
  left: 0;
  opacity: 0.1;
  position: fixed;
  right: 0;
  top: 0;
  transition: opacity 0.5s;
  z-index: var(--altcha-z-index);
}
.altcha-popover-close {
  color: var(--altcha-color-base-content);
  cursor: pointer;
  display: inline-block;
  font-size: 1rem;
  height: 1.25rem;
  line-height: 0.95;
  position: absolute;
  right: 0;
  text-align: center;
  text-shadow: 0 0 1px var(--altcha-color-base);
  top: -1.5rem;
  width: 1.25rem;
  z-index: var(--altcha-z-index);
}
[dir=rtl] .altcha-popover {
  left: auto;
  right: calc(var(--altcha-padding) / 2);
}
[dir=rtl] .altcha-popover-arrow {
  left: auto;
  right: calc(var(--altcha-checkbox-size) / 2);
}
[dir=rtl] .altcha-popover-close {
  left: 0;
  right: auto;
}
.altcha-popover[data-display=bottomsheet] .altcha-footer, .altcha-popover[data-display=overlay] .altcha-footer {
  align-items: center;
  justify-content: center;
  padding-top: 1rem;
  gap: 0.5rem;
}
.altcha-popover[data-display=bottomsheet] .altcha-footer svg, .altcha-popover[data-display=overlay] .altcha-footer svg {
  height: 18px;
  width: 18px;
  vertical-align: middle;
}
.altcha-code-challenge > form {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}
.altcha-code-challenge-title {
  font-weight: 600;
}
.altcha-code-challenge-text {
  font-size: 0.85rem;
}
.altcha-code-challenge-image {
  background: white;
  border: var(--altcha-input-border-width) solid var(--altcha-color-neutral);
  border-radius: var(--altcha-input-border-radius);
  object-fit: contain;
  height: 50px;
}
.altcha-code-challenge-row {
  display: flex;
  gap: 0.5rem;
}
.altcha-code-challenge-buttons {
  align-items: center;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  margin-top: var(--altcha-padding);
  justify-content: space-between;
}
.altcha-code-challenge-buttons button {
  justify-content: center;
  width: 100%;
}
.altcha-checkbox {
  cursor: pointer;
  height: var(--altcha-checkbox-size);
  position: relative;
  width: var(--altcha-checkbox-size);
}
.altcha-checkbox input {
  appearance: none;
  background: var(--altcha-input-background-color);
  border: var(--altcha-checkbox-border-width, 2px) solid var(--altcha-checkbox-border-color);
  border-radius: var(--altcha-checkbox-border-radius);
  cursor: pointer;
  height: var(--altcha-checkbox-size);
  left: 0;
  margin: 0;
  padding: 0;
  position: absolute;
  top: 0;
  width: var(--altcha-checkbox-size);
}
@supports (hanging-punctuation: first) and (font: -apple-system-body) and (-webkit-appearance: none) {
  .altcha-checkbox input {
    /* Safari-only: fixes focus outline */
  }
  .altcha-checkbox input:focus {
    outline-width: 2px;
    outline-style: solid;
  }
}
.altcha-checkbox input:before {
  border-radius: var(--altcha-checkbox-border-radius);
  content: "";
  width: 100%;
  height: 100%;
  background: var(--altcha-color-neutral);
  display: block;
  transform: scale(0);
}
.altcha-checkbox input:checked {
  background-color: var(--altcha-color-success);
  border-color: var(--altcha-color-success);
}
.altcha-checkbox input:checked::before {
  background-color: var(--altcha-color-success);
  opacity: 0;
  transform: scale(2.2);
  transition: all var(--altcha-checkbox-transition-duration) ease;
  transition-delay: 0.1s;
}
.altcha-checkbox svg {
  --altcha-radio-svg-size: calc(var(--altcha-checkbox-size) * 0.5);
  --altcha-radio-svg-offset: calc(var(--altcha-checkbox-size) * 0.25);
  fill: none;
  left: var(--altcha-radio-svg-offset);
  height: var(--altcha-radio-svg-size);
  opacity: 0;
  position: absolute;
  stroke: currentColor;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 16px;
  stroke-dashoffset: 16px;
  top: var(--altcha-radio-svg-offset);
  transform: translate3d(0, 0, 0);
  width: var(--altcha-radio-svg-size);
}
.altcha-checkbox input:checked + svg {
  color: var(--altcha-color-success-content);
  opacity: 1;
  stroke-dashoffset: 0;
  transition: all var(--altcha-checkbox-transition-duration) ease;
  transition-delay: 0.1s;
}
.altcha-checkbox-spinner {
  display: none;
  left: 0;
  height: var(--altcha-checkbox-size);
  position: absolute;
  top: 0;
  width: var(--altcha-checkbox-size);
}
.altcha-checkbox[data-loading=true] input {
  appearance: none;
  opacity: 0;
  pointer-events: none;
}
.altcha-checkbox[data-loading=true] .altcha-checkbox-spinner {
  display: block;
}
.altcha-checkbox-native {
  height: var(--altcha-checkbox-size);
  position: relative;
  width: var(--altcha-checkbox-size);
}
.altcha-checkbox-native input {
  height: var(--altcha-checkbox-size);
  margin: 0;
  width: var(--altcha-checkbox-size);
}
.altcha-checkbox-native-spinner {
  display: none;
  left: 0;
  height: var(--altcha-checkbox-size);
  position: absolute;
  top: 0;
  width: var(--altcha-checkbox-size);
}
.altcha-checkbox-native[data-loading=true] input {
  appearance: none;
  opacity: 0;
  pointer-events: none;
}
.altcha-checkbox-native[data-loading=true] .altcha-checkbox-native-spinner {
  display: block;
}
.altcha-switch {
  align-items: center;
  border-radius: var(--altcha-switch-border-radius);
  background-color: var(--altcha-switch-background-color);
  display: flex;
  height: var(--altcha-switch-height);
  padding: var(--altcha-switch-padding);
  position: relative;
  width: var(--altcha-switch-width);
}
.altcha-switch:focus-within {
  outline: var(--altcha-checkbox-outline);
  outline-offset: var(--altcha-checkbox-outline-offset);
}
.altcha-switch input {
  appearance: none;
  cursor: pointer;
  height: 100%;
  left: 0;
  opacity: 0;
  position: absolute;
  top: 0;
  width: 100%;
}
.altcha-switch-toggle {
  align-items: center;
  background-color: var(--altcha-switch-toggle-color);
  border-radius: var(--altcha-switch-toggle-border-radius);
  cursor: pointer;
  display: flex;
  height: var(--altcha-switch-toggle-size);
  justify-content: center;
  left: var(--altcha-switch-padding);
  position: absolute;
  transition: width 150ms ease-out, left 150ms ease-out;
  width: var(--altcha-switch-toggle-size);
}
.altcha-switch-spinner {
  display: none;
  height: var(--altcha-switch-toggle-size);
  width: var(--altcha-switch-toggle-size);
}
.altcha-switch[data-loading=true] {
  pointer-events: none;
}
.altcha-switch[data-loading=true] .altcha-switch-spinner {
  display: block;
}
.altcha-switch[data-loading=true] .altcha-switch-toggle {
  background-color: transparent;
  left: calc(50% - var(--altcha-switch-toggle-size) / 2);
}
[data-state=verified] .altcha-switch {
  --altcha-switch-background-color: var(--altcha-color-success);
}
[data-state=verified] .altcha-switch-toggle {
  background-color: var(--altcha-color-success-content);
  left: calc(100% - var(--altcha-switch-height) + var(--altcha-switch-padding));
}
[dir=rtl] .altcha-switch-toggle {
  left: calc(100% - var(--altcha-switch-height) + var(--altcha-switch-padding));
}
[dir=rtl][data-state=verified] .altcha-switch-toggle {
  left: var(--altcha-switch-padding);
}
.altcha-floating-arrow {
  border: 6px solid transparent;
  border-bottom-color: var(--altcha-border-color);
  content: "";
  height: 0;
  left: 12px;
  position: absolute;
  top: -12px;
  width: 0;
}
.altcha-overlay-backdrop {
  bottom: 0;
  left: 0;
  position: fixed;
  right: 0;
  top: 0;
  transition: opacity var(--altcha-transition-duration);
  z-index: var(--altcha-z-index);
}
.altcha-overlay-close {
  display: inline-block;
  color: currentColor;
  cursor: pointer;
  font-size: 1rem;
  height: 1rem;
  line-height: 0.85;
  position: absolute;
  right: 0;
  text-align: center;
  text-shadow: 0 0 1px var(--altcha-color-base);
  top: -1.5rem;
  width: 1rem;
  z-index: var(--altcha-z-index);
}
.altcha[data-display=overlay] {
  animation: altcha-overlay-slidein var(--altcha-transition-duration) forwards;
  filter: var(--altcha-shadow);
  left: 50%;
  opacity: 0;
  position: fixed;
  top: 45%;
  transform: translate(-50%, -50%);
  z-index: var(--altcha-z-index);
}
.altcha[data-display=overlay] .altcha-main {
  width: var(--altcha-max-width);
}
.altcha[data-display=floating] {
  display: none;
  filter: var(--altcha-shadow);
  left: var(--altcha-floating-left, -100%);
  position: fixed;
  top: var(--altcha-floating-top, -100%);
  z-index: var(--altcha-z-index);
}
.altcha[data-display=floating] .altcha-main {
  width: var(--altcha-max-width);
}
.altcha[data-display=floating][data-floating-position=top] .altcha-floating-arrow {
  border-bottom-color: transparent;
  border-top-color: var(--altcha-border-color);
  bottom: -12px;
  top: auto;
}
.altcha[data-display=floating][data-visible] {
  display: flex;
}
.altcha[data-display=bar] {
  bottom: -100%;
  filter: var(--altcha-shadow);
  left: 0;
  position: fixed;
  right: 0;
  transition: bottom var(--altcha-transition-duration), top var(--altcha-transition-duration);
  z-index: var(--altcha-z-index);
}
.altcha[data-display=bar] .altcha-main {
  align-items: center;
  border-radius: 0;
  border-width: var(--altcha-border-width) 0 0 0;
  flex-direction: row;
  max-width: 100% !important;
}
.altcha[data-display=bar] .altcha-main > * {
  width: auto;
}
.altcha[data-display=bar][data-placement=top] {
  bottom: auto;
  top: -100%;
}
.altcha[data-display=bar][data-placement=top] .altcha-main {
  border-width: 0 0 var(--altcha-border-width) 0;
}
.altcha[data-display=bar][data-placement=bottom]:not([data-state=unverified]) {
  bottom: 0;
}
.altcha[data-display=bar][data-placement=top]:not([data-state=unverified]) {
  top: 0;
}
.altcha[data-display=invisible] {
  display: none;
}

@keyframes altcha-rotate {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
@keyframes altcha-bottomsheet-slideup {
  100% {
    bottom: 0;
  }
}
@keyframes altcha-overlay-slidein {
  100% {
    opacity: 1;
    top: 50%;
  }
}`),$altcha.algorithms.set("SHA-256",()=>new Kn),$altcha.algorithms.set("SHA-384",()=>new Kn),$altcha.algorithms.set("SHA-512",()=>new Kn),$altcha.algorithms.set("PBKDF2/SHA-256",()=>new zn),$altcha.algorithms.set("PBKDF2/SHA-384",()=>new zn),$altcha.algorithms.set("PBKDF2/SHA-512",()=>new zn),Yo}_c();typeof window<"u"&&window.$altcha?.algorithms&&window.$altcha.algorithms.set("SHA-256",()=>new Worker("/assets/altcha-worker.js"));const xc=pc(Wo.forwardRef((K,Ct)=>V.jsx("form",{ref:Ct,...K}))),kc="/api/Auth/login",Sc="/api/Auth/login",Ec={enter:K=>({x:K>0?40:-40,opacity:0}),center:{x:0,opacity:1},exit:K=>({x:K>0?-40:40,opacity:0})},Cc={palette:{mode:"light"},shape:{borderRadius:7},shadows:oc,typography:ac},aa=Jl(nc.merge({},Cc,ic));aa.components=dc(aa);const Nc=({title:K,subtitle:Ct,subtext:tn})=>{const At=ql(),[mt,Dt]=nt.useState("admin"),[Tt,It]=nt.useState(1),[Tr,rn]=nt.useState(!1),[Ir,at]=nt.useState(""),[$r,Je]=nt.useState(!1),[nn,Zt]=nt.useState({username:"",password:""}),[ge,ot]=nt.useState({username:"",password:""}),[jt,Jt]=nt.useState(!0),Ie=nt.useRef(null),we=nt.useRef(null),He=D=>{const te=D.detail;Je(te?.state==="verified")},$t=()=>{Je(!1);try{const D=we.current||(typeof document<"u"?document.querySelector("altcha-widget"):null);D&&typeof D.reset=="function"&&D.reset()}catch(D){console.error("Failed to reset ALTCHA widget:",D)}},$e=D=>{if(we.current&&we.current.removeEventListener("statechange",He),we.current=D,D){D.addEventListener("statechange",He),typeof window<"u"&&window.$altcha?.algorithms&&window.$altcha.algorithms.set("SHA-256",()=>new Worker("/assets/altcha-worker.js"));try{const te=fc();D.configure?.({challenge:`${te.API_BASE_URL}/api/Auth/altcha-challenge`,codeChallengeDisplay:"standard",verifyFunction:async(fe,W)=>{try{const le=new Headers({"Content-Type":"application/json"});te.API_KEY&&le.set("X-BIOPEOPLETRACKING-API-KEY",te.API_KEY);const oe=await fetch(`${te.API_BASE_URL}/api/Auth/altcha-verify`,{method:"POST",headers:le,body:JSON.stringify({payload:fe,code:W})});if(oe.ok)return await oe.json()}catch{}return{verified:!0,payload:fe}},fetch:async(fe,W)=>{const le=new Headers(W?.headers||{});return te.API_KEY&&!le.has("X-BIOPEOPLETRACKING-API-KEY")&&le.set("X-BIOPEOPLETRACKING-API-KEY",te.API_KEY),fetch(fe,{...W,headers:le})}})}catch{}}};nt.useEffect(()=>{const D=localStorage.getItem("rememberedAdminUsername"),te=localStorage.getItem("rememberedVisitorUsername"),fe=localStorage.getItem("rememberMePreference"),W=localStorage.getItem("rememberedLoginMode");D&&Zt(le=>({...le,username:D})),te&&ot(le=>({...le,username:te})),fe!==null&&Jt(fe==="true"),W&&(W==="admin"||W==="visitor")&&Dt(W)},[]);const Y=mt==="admin",ee=Y?nn:ge,ze=(D,te)=>{It(mt==="admin"&&te==="visitor"?1:-1),Dt(te),at(""),$t()},Ee=(D,te)=>fe=>{at(""),D==="admin"?Zt(W=>({...W,[te]:fe.target.value})):ot(W=>({...W,[te]:fe.target.value}))},Ne=async D=>{D.preventDefault(),at("");const te=we.current?.value||we.current?.querySelector?.('input[name="altcha"]')?.value||"";if(!te){at("Please complete the CAPTCHA verification before signing in.");return}const fe=Y?kc:Sc;try{const W=await sc.post(fe,{...ee,altchaPayload:te}),le=W?.data?.collection?.data??W?.data;if(!le?.token){const Qe=le?.message||W?.data?.collection?.message||W?.data?.message||"Invalid username or password. Please try again.";at(Qe),$t();return}lc(le.token);const oe=cc(le.token),or=oe["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"],it=oe["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"],Rt=oe["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"],bt=oe.ApplicationId;if(or&&localStorage.setItem("username",or),it&&localStorage.setItem("email",it),Rt&&localStorage.setItem("levelPriority",Rt.trim()),bt&&Rt.trim()!=="System"&&localStorage.setItem("applicationId",bt),oe.fullName&&localStorage.setItem("fullName",oe.fullName),oe.groupName&&localStorage.setItem("groupName",oe.groupName),oe.accessibleBuildings){const Qe=oe.accessibleBuildings.split(",").map(an=>an.trim()).filter(Boolean);localStorage.setItem("accessibleBuildings",JSON.stringify(Qe))}jt?(Y?localStorage.setItem("rememberedAdminUsername",ee.username):localStorage.setItem("rememberedVisitorUsername",ee.username),localStorage.setItem("rememberMePreference","true"),localStorage.setItem("rememberedLoginMode",mt)):(localStorage.removeItem("rememberedAdminUsername"),localStorage.removeItem("rememberedVisitorUsername"),localStorage.removeItem("rememberedLoginMode"),localStorage.setItem("rememberMePreference","false")),le?.refreshToken?localStorage.setItem("refreshToken",le.refreshToken):localStorage.removeItem("refreshToken"),uc(le),localStorage.setItem("welcomePopupShown","false");const Xe=oe["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"];if(Y&&Xe==="Primary"){at("You do not have permission to login as Admin"),$t();return}setTimeout(()=>{At(Y?"/dashboards/newmainmenu":Xe==="Primary"?"/security-view/dashboard":"/my-visit"),console.log("decoded",oe)},300)}catch(W){const le=W?.response?.data?.collection?.message||W?.response?.data?.message;at(le||"Invalid username or password. Please try again."),Y?Zt({username:"",password:""}):ot({username:"",password:""}),$t(),requestAnimationFrame(()=>{Ie.current?.focus()})}};return V.jsxs(Zl,{theme:aa,children:[K&&V.jsx(na,{fontWeight:700,variant:"h3",mb:1,children:K}),tn,V.jsx(en,{mt:3,children:V.jsxs(Xl,{value:mt,onChange:ze,variant:"fullWidth",sx:{mb:2,"& .MuiTab-root":{textTransform:"none",fontWeight:600}},children:[V.jsx(Bo,{value:"admin",label:"Admin"}),V.jsx(Bo,{value:"visitor",label:"Security"})]})}),Ir&&V.jsx(na,{variant:"body2",color:"error",textAlign:"center",sx:{backgroundColor:"#ffebee",border:"1px solid #ffcdd2",borderRadius:1,p:1,mb:2},children:Ir}),V.jsx(vc,{mode:"wait",custom:Tt,children:V.jsx(xc,{onSubmit:Ne,custom:Tt,variants:Ec,initial:"enter",animate:"center",exit:"exit",transition:{duration:.25,ease:"easeOut"},children:V.jsxs(Ho,{spacing:2,children:[V.jsxs(en,{children:[V.jsx(zo,{htmlFor:"username",children:"Username"}),V.jsx(Ko,{id:"username",fullWidth:!0,inputRef:Ie,value:ee.username,onChange:Ee(mt,"username")})]}),V.jsxs(en,{children:[V.jsx(zo,{htmlFor:"password",children:"Password"}),V.jsx(Ko,{id:"password",type:Tr?"text":"password",fullWidth:!0,value:ee.password,onChange:Ee(mt,"password"),InputProps:{endAdornment:V.jsx(Ql,{position:"end",children:V.jsx(ec,{onClick:()=>rn(D=>!D),children:Tr?V.jsx(gc,{size:20}):V.jsx(mc,{size:20})})})}})]}),V.jsxs(Ho,{direction:"row",justifyContent:"space-between",alignItems:"center",children:[V.jsx(bc,{children:V.jsx(yc,{control:V.jsx(Jo,{checked:jt,onChange:D=>Jt(D.target.checked)}),label:"Remember this Device"})}),V.jsx(na,{component:tc,to:"/auth/forgot-password",fontWeight:500,sx:{textDecoration:"none",color:"primary.main"},children:"Forgot Password ?"})]}),V.jsx(en,{sx:{"& altcha-widget":{width:"100%","--altcha-border-radius":"8px","--altcha-border-color":"rgba(0,0,0,0.23)","--altcha-color-base":"#ffffff","--altcha-color-base-content":"#333333",fontSize:"0.875rem"}},children:V.jsx("altcha-widget",{ref:$e,challenge:"/api/Auth/altcha-challenge",challengeurl:"/api/Auth/altcha-challenge",codechallengedisplay:"standard",hidefooter:!0,style:{width:"100%"}})}),V.jsx(rc,{type:"submit",fullWidth:!0,size:"large",variant:"contained",disabled:!$r,children:Y?"Sign In as Admin":"Sign In as Security"})]})},mt)}),Ct]})};export{Nc as A};
