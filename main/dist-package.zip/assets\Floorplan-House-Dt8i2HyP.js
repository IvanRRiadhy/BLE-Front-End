const o="/assets/Floorplan-House-rO_N47QK.png";export{o as F};
